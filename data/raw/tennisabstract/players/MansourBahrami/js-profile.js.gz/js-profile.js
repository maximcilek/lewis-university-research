
    var fullname = 'Mansour Bahrami';
    var lastname = 'Bahrami';
    var currentrank="";
    var peakrank=192;
    var peakfirst=19880509;
    var peaklast=19880509;
    var dob=19560426;
    var ht=178;
    var hand='R';
    var backhand='';
    var country='IRI';
    var shortlist=7;
    var careerjs=1;
    var active=0;
    var lastdate=19970404;
    var twitter='';
    var current_dubs=125;
    var peak_dubs=31;
    var peakfirst_dubs=19870706;
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='10000069';
    var atp_id='mansour-bahrami/b001';
    var dc_id='800176154';
    var wiki_id='Mansour_Bahrami';
    var ychoices=["Time Span", "Last 52", "Career", "1997", "1996", "1994", "1993", "1992", "1991", "1990", "1989", "1988", "1987", "1986", "1985", "1984", "1983", "1982", "1981", "1978", "1977", "1976", "1975", "1974", "1973"];
var tchoices=["Event", "All", "Davis Cup", "Roland Garros", "Athens", "Auckland", "Basel", "Bordeaux", "Brussels", "Cologne", "Dijon CH", "Geneva", "Graz CH", "Gstaad", "Hamburg", "Heilbronn CH", "Khartoum", "Kitzbuhel", "Knokke CH", "Lyon", "Manila", "Marseille CH", "Metz", "Nancy", "Neu Ulm CH", "Nice", "Paris Indoor", "Queen's Club", "Rennes CH", "St. Vincent", "Stuttgart Outdoor", "Tehran", "Toulouse", "Yvetot CH"];
var cchoices=["vs Country", "All", "ALG", "ARG", "AUS", "BEL", "BRA", "CHI", "CHN", "CZE", "EGY", "ESP", "FRA", "GBR", "GER", "IND", "IRL", "ISR", "ITA", "JOR", "JPN", "MAR", "NED", "NZL", "PAK", "PER", "POL", "ROU", "RSA", "RUS", "SRI", "SUI", "SWE", "THA", "TPE", "TUR", "URU", "USA"];
var rchoices=["as Rank", "All"];
var ochoices=["Yannick Noah", "Worapol Thongkamcho", "Tanakorn Srichaphan", "Mel Purcell", "Jonas Svensson", "Jan Gunnarsson", "Jakob Hlasek", "Guy Forget", "Guillermo Perez Roldan", "Yu Hui Lien", "Wojtek Fibak", "Wei Yu Su", "Tomas Smid", "Tom Nijssen", "Todd Woodbridge", "Tarik Benhabiles", "Steve Guy", "Stefan Simonsson", "Stanislav Birner", "Shuzo Matsuoka", "Serge Gramegna", "Sean Sorensen", "Rudiger Haas", "Ruben Gajardo", "Roland Stadler", "Rohan De Silva", "Roger Taylor", "Rod Frawley", "Richard Vogel", "Ramesh Krishnan", "Patrick Baur", "Omer Rashid", "Omar Laimina", "Michael Westphal", "Marcelo Ingaramo", "Marcelo Hennemann", "Marc Rosset", "Marc Flur", "Magnus Tideman", "Libor Pimek", "Kemal Anbar", "John Lloyd", "John James", "John Frawley", "Johan Carlsson", "Jiu Hua Zhang", "Jim Pugh", "Jia Ping Xia", "Jens Woehrmann", "Jean Louis Haillet", "Javier Sanchez", "Jasjit Singh", "James Mcardle", "Jaime Yzaga", "Jaime Oncins", "Ivo Werner", "Ismail El Shafei", "Hocine Younes", "Heinz Gunthardt", "Hamed Ul Haq", "Hakki Ozgenel", "Gilad Bloom", "Gianni Ocleppo", "Gavorielle Marcu", "Frew Mcmillan", "Eric Winogradsky", "Emilio Sanchez", "Emad Abou Hamdeh", "Eduardo Bengoechea", "Diego Perez", "Diego Nargiso", "Danie Visser", "Czeslaw Dobrowolski", "Claudio Pistolesi", "Claudio Panatta", "Claudio Mezzadri", "Chris Lewis Nzl", "Chih Jung Chen", "Chia Yen Tsai", "Cassio Motta", "Carl Limberger", "Broderick Dyke", "Boris Becker", "Bob Hewitt", "Ben Testerman", "Arnaud Boetsch", "Andres Vysand", "Andrei Merinov", "Andrei Chesnokov", "Andrei Cherkasov", "Anand Amritraj", "Alexander Volkov", "Alejandro Ganzabal", "Abdel Aslam Mahmoudi"];
var tdates=["19731028", "19740926", "19751026", "19760224", "19760924", "19761004", "19761115", "19770110", "19770810", "19771003", "19780317", "19780801", "19780915", "19810525", "19820920", "19821025", "19831121", "19840528", "19840917", "19841119", "19850318", "19860310", "19860811", "19860908", "19861006", "19870323", "19870615", "19870706", "19870713", "19870810", "19870914", "19871102", "19880208", "19880425", "19880523", "19880606", "19880704", "19880711", "19880808", "19881004", "19881121", "19890227", "19890417", "19890508", "19890731", "19891003", "19900122", "19900528", "19900709", "19900806", "19900910", "19900917", "19900924", "19901001", "19910121", "19910325", "19910902", "19920224", "19920608", "19920914", "19920928", "19930205", "19930326", "19940325", "19940429", "19960209", "19960405", "19970221", "19970404"];
var vranks=["6", "8", "14", "15", "16", "27", "31", "33", "38", "45", "48", "53", "54", "57", "60", "61", "67", "69", "70", "75", "78", "85", "87", "91", "98", "103", "111", "114", "121", "124", "126", "129", "131", "136", "139", "142", "145", "147", "151", "159", "160", "168", "175", "179", "185", "188", "190", "191", "193", "205", "214", "250", "255", "258", "262", "285", "310", "339", "432", "451", "472", "525", "532", "659", "687", "791", "927", "968", "1278", "1302"];
var playernews=["<b>28 Oct</b> <a href=\"http://www.tennisabstract.com/charting/19880427-M-Hamburg-R32-Boris_Becker-Mansour_Bahrami.html\" target=\"new\">The Match Charting Project: 1988 Hamburg R32: Boris Becker vs Mansour Bahrami</a>: <i>Point-by-point serve, return, and rally analysis for every shot in</i><a href=\"http://www.tennisabstract.com/charting/19880427-M-Hamburg-R32-Boris_Becker-Mansour_Bahrami.html\" target=\"new\">...</a>"];
var upcoming = "";
var matchmx = [["19960209", "Davis Cup G2 QF: THA vs IRI", "Hard", "D", "L", "", "", "", "RR", "6-2 6-4 6-4", "5", "Worapol Thongkamcho", "", "", "", "R", "28.0958247775", "", "THA", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "1996-D061-001", "", "", ""],
          ["19960209", "Davis Cup G2 QF: THA vs IRI", "Hard", "D", "W", "", "", "", "RR", "6-4 6-2", "3", "Tanakorn Srichaphan", "1278", "", "", "R", "27.7125256674", "", "THA", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "1996-D061-003", "", "", ""],
          ["19960405", "Davis Cup G2 PO: IRI vs SRI", "Clay", "D", "W", "", "", "", "RR", "6-2 6-1 7-5", "5", "Rohan De Silva", "", "", "", "U", "24.1341546886", "", "SRI", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "1996-D060-001", "", "", ""],
          ["19970221", "Davis Cup G2 QF: PAK vs IRI", "Clay", "D", "L", "", "", "", "RR", "1-6 6-4 6-2", "3", "Hamed Ul Haq", "", "", "", "U", "34.9678302533", "", "PAK", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "1997-D056-004", "", "", ""],
          ["19970221", "Davis Cup G2 QF: PAK vs IRI", "Clay", "D", "W", "", "", "", "RR", "6-3 6-4 0-6 6-4", "5", "Omer Rashid", "1302", "", "", "R", "24.7063655031", "", "PAK", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "1997-D056-001", "", "", ""],
          ["19970404", "Davis Cup G2 SF: IRI vs TPE", "Clay", "D", "W", "", "", "", "RR", "6-0 7-6(2)", "3", "Chia Yen Tsai", "687", "", "", "R", "22.0889801506", "", "TPE", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "1997-D057-004", "", "", ""],
          ["19970404", "Davis Cup G2 SF: IRI vs TPE", "Clay", "D", "W", "", "", "", "RR", "7-5 7-6(3) 3-6 6-3", "5", "Chih Jung Chen", "968", "", "", "R", "24.514715948", "", "TPE", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "1997-D057-002", "", "", ""]
          ];
