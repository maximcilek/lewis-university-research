
    var fullname = 'Mattia Bellucci';
    var lastname = 'Bellucci';
    var currentrank=1492;
    var peakrank=1452;
    var peakfirst=20181001;
    var peaklast=20181001;
    var dob=20010601;
    
    var hand='U';
    var backhand='';
    var country='ITA';
    var shortlist=3;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100208096';
    var atp_id='';
    var dc_id='';
    var wiki_id='';
    var ychoices=["Time Span", "Last 52", "Career", "2018"];
var tchoices=["Event", "All"];
var cchoices=["vs Country", "All", "ITA", "RUS"];
var rchoices=["as Rank", "All"];
var ochoices=["Kirill Kivattsev", "Giacomo Dambrosi", "Alessandro Ceppellini"];
var tdates=["20180813"];
var vranks=["911", "1045"];
playernews = [];
var upcoming = "";
var matchmx = [["20180813", "Italy F23", "Clay", "S", "L", "UNR", "", "Q", "QF", "6-7(7) 6-2 6-3", "3", "Alessandro Ceppellini", "1045", "", "", "R", "19961007", "", "ITA", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-ITA-23A-2018-028", "", "3", "3"],
          ["20180813", "Italy F23", "Clay", "S", "W", "UNR", "", "Q", "R16", "7-6(6) 7-5", "3", "Kirill Kivattsev", "911", "", "", "U", "19971010", "", "RUS", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-ITA-23A-2018-023", "", "2", "2"],
          ["20180813", "Italy F23", "Clay", "S", "W", "UNR", "", "Q", "R32", "6-4 4-6 7-6(5)", "3", "Giacomo Dambrosi", "UNR", "", "", "R", "20010820", "", "ITA", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-ITA-23A-2018-014", "", "1", "1"]
          ];
