
    var fullname = 'Matilde Paoletti';
    var lastname = 'Paoletti';
    var currentrank=776;
    var peakrank=262;
    var peakfirst=20230717;
    var peaklast=20230717;
    var dob=20030304;
    
    var hand='R';
    var backhand='';
    var country='ITA';
    var shortlist=8;
    var careerjs=1;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100253529';
    var wta_id='';
    var fc_id='';
    var wiki_id='';
    var blast_link='';
    var more_link='';
    var death_date="";
    var dob_approx="";
    var elo_rating='';
    var elo_rank='';
    var ychoices=["Time Span", "Last 52", "Career", "2025", "2024", "2023", "2022", "2021", "2020", "2019"];
var tchoices=["Event", "All", "Bari 125", "Colina 125", "Florence 125", "Gaiba 125", "Ljubljana 125", "Palermo", "Parma", "Rome", "W15 Antalya", "W15 Marrakech", "W15 Schio", "W25 Grado", "W25 Santa Margherita di Pula", "W25 Selva Gardena", "W25 Solarino", "W25 Verbier", "W35 Alaminos-Larnaca", "W35 Manchester", "W35 Santa Margherita di Pula", "W35 Trieste", "W40 Mexico City", "W50 Birmingham", "W50 Porto", "W60 Collonge-Bellerive", "W60 Cordenons", "W60 Grado", "W60 Rome", "W60+H Rome", "W75 Cordenons", "W75 Porto", "W75 Vienna"];
var cchoices=["vs Country", "All", "AND", "ARG", "AUT", "BEL", "BUL", "CAN", "COL", "CRO", "CZE", "ESP", "FRA", "GBR", "GER", "GRE", "ITA", "JPN", "MDA", "MEX", "MKD", "NED", "NOR", "POL", "POR", "ROU", "RUS", "SLO", "SRB", "SUI", "TUR", "UKR", "USA"];
var rchoices=["as Rank", "All"];
var ochoices=["Nuria Brancaccio", "Nicole Fossa Huergo", "Victoria Jimenez Kasintseva", "Veronika Erjavec", "Tereza Valentova", "Tatiana Pieri", "Sofia Rocchetti", "Selena Janicijevic", "Sara Cakarevic", "Oleksandra Oliynykova", "Nastasja Schunk", "Mia Ristic", "Maria Toma", "Lucrezia Stefanini", "Lina Gjorcheska", "Lilli Tagger", "Katharina Hobgarski", "Iva Primorac", "Irina Bara", "Hiromi Abe", "Francisca Jorge", "Emily Appleton", "Ellie Schoppe", "Deborah Chiesa", "Camilla Gennaro", "Arina Gabriela Vasilescu", "Ariana Arseneault", "Anna Lena Friedsam", "Anca Alexia Todoni", "Alice Tubello", "Alice Rame", "Alessandra Mazzola", "Victoria Rodriguez", "Taylor Townsend", "Sofia Costoulas", "Sina Herrmann", "Malene Helgo", "Maja Chwalinska", "Magdalena Frech", "Lauren Proctor", "Jule Niemeier", "Joanne Zuger", "Jennifer Ruggeri", "Gergana Topalova", "Gabriela Lee", "Emina Bektas", "Ekaterina Makarova", "Conny Perrin", "Zeynep Sonmez", "Ylena In Albon", "Vlada Koval", "Victoria Bosio", "Varvara Gracheva", "Valentina Ryser", "Tamara Korpatsch", "Susan Bandecchi", "Sinja Kraus", "Sara Lanca", "Sapfo Sakellaridi", "Paula Ormaechea", "Oceane Dodin", "Misaki Matsuda", "Marta Custic", "Marina Bassols Ribera", "Mariia Kostiuk", "Maria Masini", "Maria Andrienko", "Manca Pislak", "Kristina Milenkovic", "Katharina Gerlach", "Irina Camelia Begu", "Ilay Yoruk", "Ilaria Sposetti", "Harmony Tan", "Eva Vedder", "Emilie Lindh Gallagher", "Eleonora Alvisi", "Diletta Cherubini", "Darya Astakhova", "Dalila Jakupovic", "Claudia Coppola", "Camilla Rosatello", "Bianca Turati", "Antonia Samudio", "Anastasia Tikhonova", "Anastasia Detiuc", "Amina Anshba"];
var tdates=["20190722", "20191118", "20191125", "20200803", "20200914", "20201214", "20210118", "20210125", "20210201", "20210208", "20210308", "20210315", "20210823", "20220314", "20220523", "20220613", "20220711", "20220718", "20220725", "20220822", "20220829", "20220905", "20220926", "20221003", "20221010", "20230130", "20230206", "20230403", "20230410", "20230417", "20230508", "20230515", "20230710", "20240311", "20240422", "20240729", "20240826", "20240902", "20240909", "20240930", "20241007", "20241021", "20241118", "20250120", "20250127", "20250210", "20250217"];
var vranks=["33", "74", "77", "94", "101", "112", "114", "144", "150", "153", "163", "168", "177", "178", "181", "194", "202", "208", "209", "218", "223", "224", "227", "233", "237", "239", "240", "241", "243", "246", "247", "250", "251", "252", "259", "271", "272", "280", "281", "287", "301", "311", "323", "329", "333", "335", "337", "360", "373", "382", "384", "390", "393", "394", "395", "411", "413", "415", "433", "438", "445", "457", "460", "461", "477", "505", "524", "539", "540", "541", "576", "577", "590", "639", "647", "664", "686", "713", "717", "760", "788", "792", "802", "849", "855", "872", "873", "997", "1013", "1046", "1109", "1276", "1291", "1303", "1366"];
playernews = [];
var upcoming = "";
var matchmx = [["20250120", "W75 Porto", "Hard", "75", "L", "520", "", "", "SF", "4-6 6-4 6-1", "3", "Nastasja Schunk", "311", "", "", "U", "20030817", "", "GER", "0", "124", "0", "1", "100", "68", "35", "17", "14", "5", "11", "8", "3", "69", "34", "25", "23", "13", "5", "8", "", "", "", "", "2025-W-ITF-POR-2025-001-401"],
          ["20250120", "W75 Porto", "Hard", "75", "W", "520", "", "", "QF", "3-6 7-6(5) 7-6(2)", "3", "Francisca Jorge", "247", "", "", "U", "20000421", "", "POR", "0", "187", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2025-W-ITF-POR-2025-001-302"],
          ["20250127", "W50 Porto", "Hard", "50", "L", "453", "", "", "QF", "1-6 6-2 6-0", "3", "Anna Lena Friedsam", "445", "", "", "R", "19940201", "", "GER", "0", "100", "0", "2", "68", "49", "26", "7", "10", "9", "15", "3", "5", "69", "47", "33", "7", "11", "7", "11", "", "", "", "", "2025-W-ITF-POR-2025-002-302"],
          ["20250127", "W50 Porto", "Hard", "50", "W", "453", "", "", "R16", "6-1 6-3", "3", "Ariana Arseneault", "639", "", "", "U", "20020615", "", "CAN", "0", "64", "0", "3", "40", "28", "18", "4", "8", "2", "6", "2", "7", "60", "40", "17", "4", "8", "5", "13", "", "", "", "", "2025-W-ITF-POR-2025-002-203"],
          ["20250127", "W50 Porto", "Hard", "50", "W", "453", "", "", "R32", "3-6 6-3 7-6(4)", "3", "Ellie Schoppe", "1303", "", "", "U", "20011118", "", "USA", "0", "156", "0", "4", "122", "97", "54", "7", "15", "13", "21", "3", "5", "92", "51", "31", "10", "15", "4", "12", "", "", "", "", "2025-W-ITF-POR-2025-002-106"],
          ["20250210", "W50 Birmingham", "Hard", "50", "L", "428", "", "", "R32", "7-6(4) 6-3", "3", "Lucrezia Stefanini", "153", "", "", "R", "19980515", "", "ITA", "0", "105", "0", "2", "67", "54", "26", "8", "10", "2", "7", "2", "5", "74", "48", "32", "9", "10", "8", "12", "", "", "", "", "2025-W-ITF-GBR-2025-004-101"],
          ["20250217", "W35 Manchester", "Hard", "35", "L", "425", "", "", "R16", "7-6(4) 7-5", "3", "Emily Appleton", "394", "", "", "R", "19990901", "", "GBR", "0", "118", "0", "1", "89", "70", "46", "10", "12", "5", "7", "14", "3", "69", "40", "33", "21", "12", "3", "4", "", "", "", "", "2025-W-ITF-GBR-2025-003-202"],
          ["20250217", "W35 Manchester", "Hard", "35", "W", "425", "", "", "R32", "3-6 7-5 6-4", "3", "Hiromi Abe", "438", "", "", "U", "20000502", "", "JPN", "0", "160", "1", "3", "96", "73", "44", "13", "16", "2", "7", "2", "2", "104", "72", "44", "14", "15", "13", "18", "", "", "", "", "2025-W-ITF-GBR-2025-003-103"]
          ];
