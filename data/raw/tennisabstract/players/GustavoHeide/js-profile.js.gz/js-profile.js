
    var fullname = 'Gustavo Heide';
    var lastname = 'Heide';
    var currentrank=1658;
    var peakrank=1658;
    var peakfirst=20181126;
    var peaklast=20181126;
    var dob=20020228;
    
    var hand='U';
    var backhand='';
    var country='BRA';
    var shortlist=2;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100347809';
    var atp_id='';
    var dc_id='';
    var wiki_id='';
    var ychoices=["Time Span", "Last 52", "Career", "2018"];
var tchoices=["Event", "All"];
var cchoices=["vs Country", "All", "BRA", "SWE"];
var rchoices=["as Rank", "All"];
var ochoices=["Joao Giannella", "Christian Lindell"];
var tdates=["20181112"];
var vranks=["532"];
playernews = [];
var upcoming = "";
var matchmx = [["20181112", "Brazil F9", "Clay", "S", "L", "UNR", "", "Q", "R16", "7-5 6-7(1) 6-2", "3", "Christian Lindell", "532", "3", "", "R", "19911120", "", "SWE", "1", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-BRA-09A-2018-022", "", "2", "2"],
          ["20181112", "Brazil F9", "Clay", "S", "W", "UNR", "", "Q", "R32", "6-2 6-2", "3", "Joao Giannella", "UNR", "", "", "R", "20000405", "", "BRA", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-BRA-09A-2018-011", "", "1", "1"]
          ];
