
    var fullname = 'Yuliana Monroy';
    var lastname = 'Monroy';
    var currentrank=1429;
    var peakrank=619;
    var peakfirst=20231009;
    var peaklast=20231009;
    var dob=19980920;
    
    var hand='U';
    var backhand='';
    var country='COL';
    var shortlist=40;
    var careerjs=1;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100241563';
    var wta_id='23264/title/yuliana-monroy';
    var fc_id='';
    var wiki_id='';
    var blast_link='';
    var more_link='';
    var death_date="";
    var dob_approx="";
    var elo_rating='';
    var elo_rank='';
    var ychoices=["Time Span", "Last 52", "Career", "2025", "2024", "2023", "2022", "2021", "2019", "2016", "2015", "2014", "2013"];
var tchoices=["Event", "All", "BJK Cup G1 RR: ARG vs COL", "BJK Cup Qualifiers", "Barranquilla 125", "Bogota", "Cali 125", "W15 Bogota", "W15 Bucaramanga", "W15 Bucaramanga (MOVED from 03 Oct)", "W15 Cancun", "W15 Cundinamarca", "W15 Huamantla", "W15 Ibague", "W15 Lima", "W15 Santo Domingo ", "W25 Anapoima", "W25 Cancun", "W25 Cucuta", "W25 Guayaquil", "W25 Ibague (MOVED from 10 Oct)", "W25 Lujan", "W25 Medellin", "W25 Mendoza", "W25 Mogi das Cruzes", "W25 Mosquera", "W25 Punta Cana", "W25 Salinas", "W25 Santo Domingo", "W25 Sopo", "W35 Anapoima", "W35 Arequipa", "W35 Buenos Aires", "W35 Mosquera", "W35 Punta Cana", "W35 Santo Domingo", "W35 Santo Domingo ", "W35 Sopo", "W40 Anapoima", "W40 Mexico City", "W50 Arequipa", "W60 Barranquilla", "W60 Feira De Santana", "W60 Vacaria", "Barranquilla 10K", "Bogota 10K", "Cali $10K", "Medellin $10K", "Medellin $50K", "Medellin 50K", "Pereira $10K", "Pereira 10K"];
var cchoices=["vs Country", "All", "ARG", "AUS", "BEL", "BOL", "BRA", "BUL", "CAN", "CHI", "COL", "CRO", "CZE", "ECU", "ESP", "FRA", "GBR", "GEO", "GER", "GRE", "GRN", "GUA", "HKG", "HUN", "IND", "ITA", "JPN", "MDA", "MEX", "MLT", "MNE", "NED", "PAR", "ROU", "RUS", "SRB", "SUI", "SVK", "UKR", "UNK", "URU", "USA"];
var rchoices=["as Rank", "All"];
var ochoices=["Maria Camila Torres Murcia", "Nicole Fossa Huergo", "Jazmin Ortenzi", "Ana Sofia Sanchez", "Melany Solange Krywoj", "Susan Bandecchi", "Fernanda Labrana", "Mell Elizabeth Reasco Gonzalez", "Jenna Defalco", "Cadence Brace", "Tiziana Rossini", "Sabastiani Leon", "Roosh Wijesundera", "Laura Pigossi", "Victoria Rodriguez", "Valentina Mediorreal Arias", "Valentina Ballesteros Aldana", "Taylor Gruber", "Sofia Omati Albieri", "Sofia Costoulas", "Selena Janicijevic", "Savanna Ly Nguyen", "Sahaja Yamalapalli", "Rasheeda Mcadoo", "Noelia Zeballos Melgar", "Nicole Poj", "Monika Wojcik", "Maya Joint", "Martina Okalova", "Martina Capurro Taborda", "Marine Partaud", "Maria Paulina Perez Garcia", "Maria Gabriela Rivera Corado", "Maria Fernanda Martinez Hernandez", "Maria Fernanda Herazo Gonzalez", "Malkia Menguene", "Malaika Rapolu", "Luciana Moyano", "Lena Rueffer", "Lea Ma", "Kayla Cross", "Kayla Brianne Moore", "Kaede Usui", "Juliette Sanchez Perez", "Juliana Rodriguez", "Joanne Zuger", "Jessica Failla", "Jada Robinson", "Isabel Adrover Gallego", "Irina Bara", "Hong Yi Cody Wong", "Gala Arangio", "Francesca Jones", "Esther Vyrlan", "Emiliana Arango", "Eleni Kordolaimi", "Elaine Genovese", "Diana Sofia Lizarazo", "Dasha Plekhanova", "Daria Kudashova", "Carolina Bohrer Martins", "Carolina Alves", "Carole Monnet", "Bronte Murgett", "Ashmitha Easwaramurthi", "Anna Sinclair Rogers", "Alicia Herrero Linana", "Yu Chen", "Stacey Fung", "Natalija Stevanovic", "Minami Akiyama", "Mariapaz Ospina", "Marian Gomez Pezuela Cano", "Maria Jose Portillo Ramirez", "Madison Sieg", "Madison Appel", "Lia Karatancheva", "Lara Arruabarrena", "Kyle Mcphillips", "Kelly Loana Vargas Gonzalez", "Jessica Hinojosa Gomez", "Eleonore Tchakarova", "Christina Rosca", "Caroline Lampl", "Arantxa Sanchez", "Andrea Koch Benvenuto", "Ana M Becerra", "Amelia Bissett", "Alica Rusova", "Akilah James", "Vladica Babic", "Vilma Y Gomez", "Victoria Bosio", "Vera Aleshcheva", "Vanda Lukacs", "Valeriya Strakhova", "Valerie Quiceno", "Thaisa Grana Pedretti", "Tereza Mrdeza", "Teja Tirunelveli", "Sofia Shapatava", "Sofia Sewing", "Sofia Cardenas Galvis", "Sofia Camila Rojas", "Noelia Zeballos", "Noel Saidenova", "Mia Popovic", "Mariana Correa", "Maria Victoria Marchesini", "Marcela Zacarias", "Maraia Paula Manrique", "Man Ying Maggie Ng", "Madison Westby", "Madison Bourguignon", "Luisa Meyer Auf Der Heide", "Laura D Arciniegas", "Lara Escauriza", "Laetitia Pulchartova", "Kelly Williford", "Julieta Lara Estable", "Julia Riera", "Jennifer Rosa Dourado", "Javiera Verdugo", "Isabel Veronica Boada", "Eva Vedder", "Emily Appleton", "Ekaterine Gorgodze", "Diana Monsalve", "Daniela Carrillo", "Carla Lucero", "Camila Osorio", "Camila Giangreco Campiz", "Ariana Arseneault", "Anna Katalina Alzate Esmurzaeva", "Angie Carolina Yepes Medina", "Ana Candiotto", "Alexa Pitt", "Alexa Guarachi", "Abigail Rencheli"];
var tdates=["20131014", "20131125", "20131202", "20140331", "20141020", "20141124", "20141201", "20150406", "20150413", "20151123", "20160815", "20160822", "20190422", "20190513", "20190520", "20190527", "20190708", "20190715", "20190812", "20190819", "20191021", "20191028", "20210405", "20210503", "20210510", "20210906", "20210913", "20210927", "20211004", "20211011", "20211115", "20211122", "20211129", "20211206", "20211213", "20220207", "20220214", "20220221", "20220228", "20220314", "20220321", "20220404", "20220606", "20220613", "20220711", "20220718", "20220808", "20220815", "20220822", "20221017", "20221024", "20221031", "20221107", "20221114", "20230130", "20230206", "20230213", "20230220", "20230313", "20230320", "20230327", "20230415", "20230417", "20230424", "20230619", "20230626", "20230710", "20230731", "20230814", "20230925", "20231002", "20231204", "20231211", "20240115", "20240122", "20240304", "20240311", "20240401", "20240422", "20240429", "20240506", "20240520", "20240527", "20240603", "20240610", "20240812", "20240819", "20240902", "20240909", "20241014", "20241021", "20241104", "20241118", "20241125", "20250331", "20250410"];
var vranks=["78", "120", "167", "168", "182", "188", "191", "199", "214", "232", "242", "259", "268", "277", "302", "306", "312", "315", "316", "345", "356", "364", "375", "378", "380", "389", "392", "409", "433", "438", "443", "453", "461", "463", "465", "491", "516", "527", "532", "534", "543", "545", "557", "563", "590", "621", "632", "635", "656", "672", "696", "715", "716", "722", "729", "732", "748", "750", "762", "776", "798", "804", "848", "887", "926", "933", "935", "938", "939", "941", "956", "963", "966", "977", "979", "984", "995", "1003", "1010", "1014", "1027", "1031", "1038", "1055", "1059", "1070", "1086", "1091", "1107", "1121", "1125", "1144", "1159", "1182", "1185", "1187", "1204", "1206", "1233", "1246", "1305", "1328", "1367", "1371", "1378", "1423", "1446", "1459", "1462"];
playernews = [];
var upcoming = "";
var matchmx = [["20240115", "W35 Buenos Aires", "Clay", "35", "L", "681", "", "", "R64", "6-7(2) 6-3 6-0", "3", "Jazmin Ortenzi", "762", "", "", "R", "20011120", "", "ARG", "0", "", "", "", "", "", "", "2024-W-ITF-ARG-01A-2024-131"],
          ["20240122", "W35 Buenos Aires", "Clay", "35", "L", "681", "", "", "R64", "6-2 6-2", "3", "Jazmin Ortenzi", "762", "", "", "R", "20011120", "", "ARG", "0", "", "", "", "", "", "", "2024-W-ITF-ARG-02A-2024-115"],
          ["20240304", "W35 Santo Domingo", "Hard", "35", "L", "697", "", "LL", "R32", "6-2 6-0", "3", "Susan Bandecchi", "378", "", "", "R", "19980701", "", "SUI", "0", "", "", "", "", "", "", "2024-W-ITF-DOM-2024-001-216"],
          ["20240304", "W35 Santo Domingo", "Hard", "35", "L", "697", "4", "", "Q2", "6-0 6-4", "3", "Jada Robinson", "1010", "15", "", "U", "19990129", "", "USA", "0", "", "", "", "", "", "", "2024-W-ITF-DOM-2024-001-814"],
          ["20240304", "W35 Santo Domingo", "Hard", "35", "W", "697", "4", "", "Q1", "5-7 6-4 10-8", "3", "Taylor Gruber", "", "", "", "U", "19990615", "", "USA", "0", "", "", "", "", "", "", "2024-W-ITF-DOM-2024-001-717"],
          ["20240311", "W35 Santo Domingo", "Hard", "35", "L", "697", "", "", "R64", "4-6 6-2 6-3", "3", "Susan Bandecchi", "378", "", "", "R", "19980701", "", "SUI", "0", "", "", "", "", "", "", "2024-W-ITF-DOM-2024-002-127"],
          ["20240401", "Bogota", "Clay", "I", "L", "765", "", "WC", "R32", "6-1 6-2", "3", "Francesca Jones", "214", "", "", "R", "20000919", "", "GBR", "0", "70", "0", "2", "65", "54", "22", "3", "8", "5", "12", "0", "4", "38", "24", "16", "8", "7", "2", "4", "", "", "", "", "2024-894-283"],
          ["20240422", "W35 Mosquera", "Clay", "35", "L", "757", "", "", "R32", "6-1 6-3", "3", "Cadence Brace", "491", "6", "", "R", "20050225", "", "CAN", "0", "", "", "", "", "", "", "2024-W-ITF-COL-2024-002-113"],
          ["20240429", "W35 Anapoima", "Clay", "35", "L", "757", "", "", "QF", "6-2 6-0", "3", "Carolina Alves", "345", "3", "", "U", "19960423", "", "BRA", "0", "", "", "", "", "", "", "2024-W-ITF-COL-2024-001-303"],
          ["20240429", "W35 Anapoima", "Clay", "35", "W", "757", "", "", "R16", "6-1 6-1", "3", "Diana Sofia Lizarazo", "", "", "WC", "U", "20060920", "", "COL", "0", "", "", "", "", "", "", "2024-W-ITF-COL-2024-001-205"],
          ["20240429", "W35 Anapoima", "Clay", "35", "W", "757", "", "", "R32", "6-3 6-3", "3", "Nicole Fossa Huergo", "563", "8", "", "U", "19950526", "", "ITA", "0", "", "", "", "", "", "", "2024-W-ITF-COL-2024-001-109"],
          ["20240506", "W35 Sopo", "Clay", "35", "L", "805", "", "", "R32", "6-1 6-0", "3", "Nicole Fossa Huergo", "534", "6", "", "U", "19950526", "", "ITA", "0", "", "", "", "", "", "", "2024-W-ITF-COL-2024-003-108"],
          ["20240520", "W35 Santo Domingo ", "Hard", "35", "L", "748", "", "", "R32", "6-0 6-2", "3", "Jessica Failla", "461", "5", "", "U", "19970705", "", "USA", "0", "", "", "", "", "", "", "2024-W-ITF-DOM-2024-003-204"],
          ["20240520", "W35 Santo Domingo ", "Hard", "35", "W", "748", "", "", "R64", "6-2 6-1", "3", "Nicole Poj", "", "", "Q", "U", "20010509", "", "ARG", "0", "", "", "", "", "", "", "2024-W-ITF-DOM-2024-003-107"],
          ["20240527", "W35 Santo Domingo ", "Hard", "35", "L", "747", "", "", "R32", "6-3 6-1", "3", "Hong Yi Cody Wong", "543", "6", "", "U", "20020314", "", "HKG", "0", "", "", "", "", "", "", "2024-W-ITF-DOM-2024-004-204"],
          ["20240527", "W35 Santo Domingo ", "Hard", "35", "W", "747", "", "", "R64", "6-3 7-6(4)", "3", "Bronte Murgett", "1038", "", "", "U", "19990414", "", "GBR", "0", "", "", "", "", "", "", "2024-W-ITF-DOM-2024-004-107"],
          ["20240603", "W15 Santo Domingo ", "Hard", "15", "L", "747", "4", "", "R32", "3-6 6-4 10-8", "3", "Maria Fernanda Martinez Hernandez", "1367", "", "", "U", "20041220", "", "MEX", "0", "", "", "", "", "", "", "2024-W-ITF-DOM-2024-005-112"],
          ["20240610", "W15 Santo Domingo ", "Hard", "15", "L", "721", "1", "", "R32", "6-2 4-6 7-5", "3", "Esther Vyrlan", "1182", "", "", "U", "20060519", "", "USA", "0", "", "", "", "", "", "", "2024-W-ITF-DOM-2024-006-101"],
          ["20240812", "W35 Arequipa", "Clay", "35", "L", "811", "", "", "R32", "5-7 7-5 6-2", "3", "Fernanda Labrana", "656", "", "", "R", "19990313", "", "CHI", "0", "", "", "", "", "", "", "2024-W-ITF-PER-2024-001-103"],
          ["20240819", "W50 Arequipa", "Clay", "50", "L", "820", "", "", "R32", "6-7(4) 6-4 7-6(5)", "3", "Fernanda Labrana", "696", "", "", "R", "19990313", "", "CHI", "0", "", "", "", "", "", "", "2024-W-ITF-PER-2024-002-106"],
          ["20240902", "W35 Punta Cana", "Clay", "35", "L", "809", "", "", "R16", "6-4 2-6 6-3", "3", "Valentina Mediorreal Arias", "1204", "", "Q", "U", "20070302", "", "COL", "0", "", "", "", "", "", "", "2024-W-ITF-DOM-2024-009-202"],
          ["20240902", "W35 Punta Cana", "Clay", "35", "W", "809", "", "", "R32", "2-6 6-2 6-4", "3", "Kayla Cross", "463", "6", "", "L", "20050321", "", "CAN", "0", "", "", "", "", "", "", "2024-W-ITF-DOM-2024-009-104"],
          ["20240909", "W35 Punta Cana", "Clay", "35", "L", "805", "", "", "R16", "6-2 6-0", "3", "Sahaja Yamalapalli", "302", "1", "", "U", "20001029", "", "IND", "0", "", "", "", "", "", "", "2024-W-ITF-DOM-2024-010-201"],
          ["20240909", "W35 Punta Cana", "Clay", "35", "W", "805", "", "", "R32", "6-3 6-2", "3", "Malkia Menguene", "1031", "", "Q", "R", "20000808", "", "USA", "0", "", "", "", "", "", "", "2024-W-ITF-DOM-2024-010-102"],
          ["20241014", "W15 Huamantla", "Hard", "15", "L", "777", "2", "WC", "QF", "6-3 6-4", "3", "Sabastiani Leon", "966", "5", "", "R", "19920323", "", "MEX", "0", "", "", "", "", "", "", "2024-W-ITF-MEX-2024-005-304"],
          ["20241014", "W15 Huamantla", "Hard", "15", "W", "777", "2", "WC", "R16", "6-3 6-4", "3", "Kayla Brianne Moore", "", "", "", "U", "", "", "USA", "0", "", "", "", "", "", "", "2024-W-ITF-MEX-2024-005-208"],
          ["20241014", "W15 Huamantla", "Hard", "15", "W", "777", "2", "WC", "R32", "6-1 6-0", "3", "Valentina Ballesteros Aldana", "", "", "Q", "U", "", "", "COL", "0", "", "", "", "", "", "", "2024-W-ITF-MEX-2024-005-116"],
          ["20241021", "W15 Huamantla", "Hard", "15", "L", "778", "1", "", "F", "7-6(3) 6-2", "3", "Malaika Rapolu", "", "", "", "U", "20030418", "", "USA", "0", "", "", "", "", "", "", "2024-W-ITF-MEX-2024-006-501"],
          ["20241021", "W15 Huamantla", "Hard", "15", "W", "778", "1", "", "QF", "6-1 6-4", "3", "Kaede Usui", "", "", "", "U", "", "", "USA", "0", "", "", "", "", "", "", "2024-W-ITF-MEX-2024-006-301"],
          ["20241021", "W15 Huamantla", "Hard", "15", "W", "778", "1", "", "R16", "6-2 6-3", "3", "Tiziana Rossini", "", "", "", "U", "", "", "ARG", "0", "", "", "", "", "", "", "2024-W-ITF-MEX-2024-006-201"],
          ["20241021", "W15 Huamantla", "Hard", "15", "W", "778", "1", "", "R32", "6-1 6-0", "3", "Juliette Sanchez Perez", "", "", "Q", "U", "", "", "MEX", "0", "", "", "", "", "", "", "2024-W-ITF-MEX-2024-006-101"],
          ["20241021", "W15 Huamantla", "Hard", "15", "W", "778", "1", "", "SF", "6-3 6-2", "3", "Isabel Adrover Gallego", "", "", "", "U", "20010623", "", "ESP", "0", "", "", "", "", "", "", "2024-W-ITF-MEX-2024-006-401"],
          ["20241104", "Cali 125", "Clay", "C", "L", "697", "", "", "Q2", "6-1 6-3", "3", "Alicia Herrero Linana", "732", "", "", "R", "19981229", "", "ESP", "0", "80", "0", "4", "58", "46", "19", "1", "8", "6", "14", "1", "1", "46", "32", "19", "5", "8", "1", "5", "", "", "", "", "2024-1110-267"],
          ["20241104", "Cali 125", "Clay", "C", "W", "697", "", "", "Q1", "6-3 0-0 RET", "3", "Melany Solange Krywoj", "545", "7", "", "R", "19980227", "", "ARG", "0", "48", "0", "0", "29", "18", "11", "5", "5", "1", "3", "0", "4", "25", "14", "9", "1", "4", "1", "4", "", "", "", "", "2024-1110-260"],
          ["20241118", "W35 Santo Domingo ", "Hard", "35", "L", "678", "", "", "R32", "6-1 6-1", "3", "Daria Kudashova", "380", "9", "", "U", "20030328", "", "RUS", "0", "", "", "", "", "", "", "2024-W-ITF-DOM-2024-011-207"],
          ["20241118", "W35 Santo Domingo ", "Hard", "35", "W", "678", "", "", "R64", "6-1 6-2", "3", "Maria Camila Torres Murcia", "1055", "", "", "L", "20021110", "", "COL", "0", "", "", "", "", "", "", "2024-W-ITF-DOM-2024-011-114"],
          ["20241125", "W35 Santo Domingo ", "Hard", "35", "L", "679", "", "", "R32", "6-2 6-4", "3", "Ana Sofia Sanchez", "356", "6", "", "L", "19940413", "", "MEX", "0", "", "", "", "", "", "", "2024-W-ITF-DOM-2024-012-204"],
          ["20241125", "W35 Santo Domingo ", "Hard", "35", "W", "679", "", "", "R64", "6-1 6-3", "3", "Monika Wojcik", "", "", "Q", "U", "20051025", "", "USA", "0", "", "", "", "", "", "", "2024-W-ITF-DOM-2024-012-107"],
          ["20250331", "Bogota", "Clay", "I", "L", "733", "", "WC", "Q1", "7-5 6-3", "3", "Irina Bara", "242", "6", "", "R", "19950318", "", "ROU", "0", "112", "1", "5", "63", "40", "18", "6", "11", "6", "14", "0", "12", "70", "41", "26", "8", "10", "6", "11", "", "", "", "", "2025-894-253"],
          ["20250410", "BJK Cup Qualifiers", "", "D", "L", "734", "", "", "RR", "6-1 6-0", "3", "Maya Joint", "78", "", "", "R", "20060416", "", "AUS", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "20250412-W-BJK_Cup_Qualifiers-RR-Yuliana_Monroy-Maya_Joint", "", "", "2025-W-FC-2025-QUA-121"]
          ];
