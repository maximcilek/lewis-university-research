
    var fullname = 'Max Houkes';
    var lastname = 'Houkes';
    var currentrank=1297;
    var peakrank=1286;
    var peakfirst=20181015;
    var peaklast=20181015;
    var dob=20000703;
    
    var hand='U';
    var backhand='';
    var country='NED';
    var shortlist=8;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100325711';
    var atp_id='';
    var dc_id='';
    var wiki_id='';
    var ychoices=["Time Span", "Last 52", "Career", "2018"];
var tchoices=["Event", "All"];
var cchoices=["vs Country", "All", "ARG", "GER", "KAZ", "NED", "RUS", "SLO"];
var rchoices=["as Rank", "All"];
var ochoices=["Mick Veldheer", "Roman Hassanov", "Nik Razborsek", "Niels Lootsma", "Mariano Kestelboim", "Christoph Negritu", "Alexander Boborykin"];
var tdates=["20180507", "20180813", "20180820", "20180827", "20180917"];
var vranks=["537", "644", "669", "890", "906", "915", "1023", "1393"];
playernews = [];
var upcoming = "";
var matchmx = [["20180507", "Turkey F18", "Clay", "S", "L", "UNR", "", "", "R32", "6-4 5-7 6-4", "3", "Alexander Boborykin", "1393", "", "WC", "U", "19960603", "", "RUS", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-TUR-18A-2018-009", "", "1", "1"],
          ["20180813", "Netherlands F4", "Clay", "S", "L", "UNR", "", "", "QF", "7-5 6-4", "3", "Niels Lootsma", "1023", "", "", "U", "19940815", "", "NED", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-NED-04A-2018-026", "", "3", "3"],
          ["20180813", "Netherlands F4", "Clay", "S", "W", "UNR", "", "", "R16", "6-3 4-6 6-2", "3", "Christoph Negritu", "644", "7", "", "R", "19940321", "", "GER", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-NED-04A-2018-020", "", "2", "2"],
          ["20180813", "Netherlands F4", "Clay", "S", "W", "UNR", "", "", "R32", "7-5 3-6 6-4", "3", "Mick Veldheer", "906", "", "", "L", "19960405", "", "NED", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-NED-04A-2018-007", "", "1", "1"],
          ["20180820", "Netherlands F5", "Clay", "S", "L", "UNR", "", "", "R16", "6-3 6-4", "3", "Mariano Kestelboim", "537", "5", "", "R", "19960206", "", "ARG", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-NED-05A-2018-018", "", "2", "2"],
          ["20180820", "Netherlands F5", "Clay", "S", "W", "UNR", "", "", "R32", "6-4 3-6 6-4", "3", "Mick Veldheer", "890", "", "", "L", "19960405", "", "NED", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-NED-05A-2018-003", "", "1", "1"],
          ["20180827", "Netherlands F6", "Clay", "S", "L", "1467", "", "WC", "R32", "6-3 6-4", "3", "Nik Razborsek", "669", "", "", "L", "19931004", "", "SLO", "1", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-NED-06A-2018-005", "", "1", "1"],
          ["20180917", "Kazakhstan F7", "Clay", "S", "L", "1357", "", "", "R32", "7-5 3-6 7-6(4)", "3", "Roman Hassanov", "915", "", "", "R", "19960907", "", "KAZ", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-KAZ-07A-2018-002", "", "1", "1"]
          ];
