
    var fullname = 'Sandra Reynolds';
    var lastname = 'Reynolds';
    var currentrank="";
    var peakrank="UNR";
    var peakfirst="";
    var peaklast="";
    var dob=19390304;
    
    var hand='R';
    var backhand='';
    var country='RSA';
    var shortlist=89;
    var careerjs=1;
    var active=0;
    var lastdate=19620831;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='';
    var wta_id='';
    var fc_id='';
    var wiki_id='Sandra_Reynolds';
    var blast_link='https://www.tennisforum.com/threads/biographies-of-female-tennis-players.497314/post-25512258';
    var more_link='';
    var death_date="";
    var dob_approx="";
    var ychoices=["Time Span", "Last 52", "Career", "1962", "1961", "1960", "1959", "1958", "1957", "1956", "1955", "1954"];
var tchoices=["Event", "All", "Wimbledon", "Adelaide", "Athens", "Australian Championships", "Bad Neuenahr", "Baden", "Beckenham", "Beckenham GB vs Commonwealth", "Berlin", "Birmingham Priory", "Bloemfontein", "Brisbane", "Bristol", "Brumana", "Budapest", "Cape Town", "Cape Town Exho", "Catania", "Cheltenham", "Chicago", "Cologne", "Croydon", "Denver", "Dublin", "Durban Test RSA vs USA", "Dusseldorf", "East London 2", "Gstaad", "Hamburg", "Haverford", "Hilversum", "Hurlingham", "Istanbul", "Johannesburg", "Johannesburg Test RSA vs USA", "Kitzbuhel", "London ENG vs RSA", "Manchester", "Manchester-On-Sea", "Melbourne", "Munich", "Naples", "Nottingham", "Paddington", "Palermo", "Perth", "Port Elizabeth", "Port Elizabeth Exho", "Port Elizabeth GBR vs RSA", "Port Elizabeth Test RSA vs USA", "Queen's Club", "Reggio Calabria", "Roland Garros", "Rome", "South Orange", "Surbiton", "Sydney", "Turin", "US National Championships", "Venice", "Wiesbaden", "Wimbledon Plate"];
var cchoices=["vs Country", "All", "AUS", "AUT", "BEL", "BRA", "CAN", "CUB", "DEN", "ESP", "FRA", "FRG", "GBR", "GER", "GRE", "HUN", "IRL", "ITA", "MEX", "NED", "NOR", "NZL", "PUR", "RSA", "SWE", "TCH", "TUR", "USA"];
var rchoices=["as Rank", "All"];
var ochoices=["Renee Schuurman", "Ann Jones", "Yola Ramirez", "Maria Bueno", "Jan Lehane", "Heather Nicholls", "Lesley Turner", "Bernice Carr", "Margaret Hellyer", "Jean Forbes", "Edda Buding", "Angela Mortimer", "Silvana Lazzarino", "Margaret Hunt", "Lea Pericoli", "Dorothy Knode", "Christine Truman", "Valerie Forbes", "Shirley Bloomer", "Sally Moore", "Mary Carter Reitano", "Lynne Nette", "Janet Hopps", "Darlene Hard", "Zsuzsa Kormoczy", "Vera Sukova", "Susan Butt", "Sheila Armstrong", "Ruia Morrison", "Robyn Ebbern", "Rita Bentley", "Renata Ostermann", "Patricia Ward Hales", "Mimi Wheeler", "Merrill Hammill", "Maria Ayala", "Margot Parker", "Margot Dittmeyer", "Margaret Court", "Louise Brough", "Linda Vail", "Karol Fageros", "Justina Bricka", "Jill Langley", "Jan Shearer", "Honor Durose", "Francoise Durr", "Doreen Van Tonder", "Deidre Catt", "Daphne Seeney", "Daniele Bouteleux", "Chiara Ramorino", "Charleen Rigby", "Barbara Green", "Anne Shilcock", "Yvonne Wilkinson", "Xantipes Vassiliadis", "Wendy Hall", "Viola White", "Vera Roberts", "Susan Verster", "Susan Partridge", "Sue Behlmar", "Sonja Pachta", "Solveig Gustafsson", "Sheila Waddington", "Sheila Boden", "Sevim Barulay", "Sandra Hesse", "Sally Holdsworth", "Ruth Smith", "Ruth Jeffery", "Rosie Reyes", "Rosemary Walsh", "Robin Lesh", "Pia Balling", "Peggy Van Heerden", "Pauline Edwards", "Patsy Blake", "Pat Ingram", "Pat Hird", "Pat Brown", "P Kamp", "Olga Garcia Rangel", "Nicla Migliori", "Nell Hopman", "Nancy Richey", "Mrs R Cooper", "Mrs N Watkins", "Mrs M Smitt", "Mrs M J Marshall", "Mrs K M Ernest", "Michele Bourbonnais", "Mia Van Tonder", "Mercedes Solsona", "Maureen Mccalman", "Maura Veronese", "Mary Hawton", "Mary Eyre", "Marlene Gerson", "Marilen Knobling", "Marie Burke", "Margaret Varner", "Margaret Carter", "Mandy Einstein", "Madonna Schacht", "Lynette Bowden", "Lucille Van Der Westhuizen", "Lorraine Coghlan", "Lorna Cornell", "Lily Adair", "Kaye Dening", "Karin Herich", "Karen Susman", "June Kroeger", "June Fitzpatrick", "Josette Billaz", "Josefine Rohrbach", "Joan Tooth", "Joan Harvey", "Joan Cross Johnson", "Jill Blackman", "Jill Bignell", "Jenny Trewby", "Jenny Staley Hoad", "Jenny Ridderhof", "Jeanne Arth", "Jane Albert", "J Adendorff", "Henriette Siarry", "Heidi Haas", "Gwyn Thomas", "Gwendy Love", "Ginette Bucaille", "Gill Worrall", "Geraldine Barniville", "Georgie Woodgate", "Frances Maclennan", "Florence De La Courtie", "Fay Grant", "Eva Duldig", "Estelle Van Tonder", "Erika Vollmer", "Elizabeth Starkie", "E Wallace", "E Tudor", "Dorelle Roux", "Doreen Spiers", "Dora Kilian", "Donna Floyd", "Christiane Mercelis", "Carolyn Liguori", "Caroline Leather", "Carola Alber", "Carmen Coronado", "Brigitte Eigenberger", "Bodil Ulrich", "Beverly Baker Fleitz", "Beverley Rae", "Betty Holstein", "Beryl Bartlett", "Bep Van Buuren", "Bea Walter", "Barbara Knapp", "Barbara Hall", "Barbara Browning", "Barbara Benigni", "Audrey Treyvellan", "Annette Van Zyl", "Annalisa Bossi", "Andrea Winkler", "Althea Gibson", "Alice Fehrenbach", " Kovacs"];
var tdates=["19541025", "19550331", "19551017", "19560322", "19560430", "19560507", "19560514", "19560528", "19560604", "19560611", "19560625", "19560702", "19560711", "19561010", "19561229", "19570105", "19570411", "19570506", "19570521", "19570610", "19570617", "19570624", "19570708", "19570722", "19570803", "19570814", "19571014", "19571226", "19571228", "19580315", "19580322", "19580327", "19580506", "19580512", "19580520", "19580602", "19580609", "19580623", "19580630", "19581022", "19581106", "19581119", "19581204", "19590103", "19590116", "19590319", "19590416", "19590423", "19590427", "19590504", "19590514", "19590519", "19590601", "19590608", "19590622", "19590706", "19590713", "19590721", "19590727", "19590802", "19590820", "19590824", "19590831", "19590906", "19600103", "19600311", "19600319", "19600326", "19600406", "19600426", "19600502", "19600517", "19600530", "19600604", "19600606", "19600620", "19600707", "19600710", "19600718", "19600801", "19600808", "19600815", "19601010", "19601219", "19601229", "19610201", "19610323", "19610408", "19610507", "19610518", "19610529", "19610605", "19610612", "19610626", "19610710", "19610717", "19610727", "19610803", "19610807", "19620108", "19620516", "19620521", "19620604", "19620611", "19620625", "19620712", "19620716", "19620723", "19620730", "19620807", "19620813", "19620831"];
var vranks=[];
playernews = [];
var upcoming = "";
var matchmx = [["19620831", "US National Championships", "Grass", "G", "L", "", "8", "", "QF", "6-3 6-3", "3", "Margaret Court", "", "1", "", "R", "19420716", "175", "AUS", "0", "", "", "", "", "", "", "", "1962-1187-089"],
          ["19620831", "US National Championships", "Grass", "G", "W", "", "8", "", "R16", "6-3 6-3", "3", "Jane Albert", "", "", "", "R", "19460602", "", "USA", "0", "", "", "", "", "", "", "", "1962-1187-082"],
          ["19620831", "US National Championships", "Grass", "G", "W", "", "8", "", "R32", "6-3 6-2", "3", "Pia Balling", "", "", "", "U", "19400620", "165", "DEN", "0", "", "", "", "", "", "", "", "1962-1187-067"],
          ["19620831", "US National Championships", "Grass", "G", "W", "", "8", "", "R64", "6-2 6-0", "3", "Mandy Einstein", "", "", "", "U", "", "", "USA", "0", "", "", "", "", "", "", "", "1962-1187-037"],
          ["19620813", "Manchester-On-Sea", "Grass", "W", "L", "", "", "", "SF", "6-4 6-2", "3", "Maria Bueno", "", "", "", "R", "19391011", "170", "BRA", "0", "", "", "", "", "", "", "", "1962-1166-026"],
          ["19620813", "Manchester-On-Sea", "Grass", "W", "W", "", "", "", "QF", "7-5 6-1", "3", "Darlene Hard", "", "", "", "R", "19360106", "170", "USA", "0", "", "", "", "", "", "", "", "1962-1166-023"],
          ["19620813", "Manchester-On-Sea", "Grass", "W", "W", "", "", "", "R16", "6-2 6-3", "3", "Sue Behlmar", "", "", "", "U", "19420102", "", "USA", "0", "", "", "", "", "", "", "", "1962-1166-018"],
          ["19620813", "Manchester-On-Sea", "Grass", "W", "W", "", "", "", "R32", "6-1 6-0", "3", "Ruth Jeffery", "", "", "", "R", "19340925", "", "USA", "0", "", "", "", "", "", "", "", "1962-1166-009"],
          ["19620807", "Kitzbuhel", "Clay", "W", "W", "", "", "", "F", "4-6 6-4 8-6", "3", "Lesley Turner", "", "", "", "R", "19420816", "", "AUS", "0", "", "", "", "", "", "", "", "1962-1161-010"],
          ["19620807", "Kitzbuhel", "Clay", "W", "W", "", "", "", "SF", "6-1 6-3", "3", "Jan Lehane", "", "", "", "R", "19410709", "", "AUS", "0", "", "", "", "", "", "", "", "1962-1161-008"],
          ["19620807", "Kitzbuhel", "Clay", "W", "W", "", "", "", "QF", "6-0 6-1", "3", "Sonja Pachta", "", "", "", "R", "19410425", "", "AUT", "0", "", "", "", "", "", "", "1962-1161-020"],
          ["19620807", "Kitzbuhel", "Clay", "W", "W", "", "", "", "R16", "6-2 6-2", "3", "Andrea Winkler", "", "", "", "U", "19400917", "", "AUT", "0", "", "", "", "", "", "", "1962-1161-013"],
          ["19620807", "Kitzbuhel", "Clay", "W", "W", "", "", "", "R32", "6-3 6-1", "3", " Kovacs", "", "", "", "U", "", "", "HUN", "0", "", "", "", "", "", "", "1962-1161-011"],
          ["19620730", "Hamburg", "Clay", "W", "W", "", "", "", "F", "4-6 6-3 7-5", "3", "Ann Jones", "", "", "", "L", "19381007", "", "GBR", "0", "", "", "", "", "", "", "", "1962-1151-038"],
          ["19620730", "Hamburg", "Clay", "W", "W", "", "", "", "SF", "6-3 6-2", "3", "Angela Mortimer", "", "", "", "R", "19320421", "", "GBR", "0", "", "", "", "", "", "", "", "1962-1151-036"],
          ["19620730", "Hamburg", "Clay", "W", "W", "", "", "", "QF", "6-2 6-3", "3", "Edda Buding", "", "", "", "R", "19361113", "", "FRG", "0", "", "", "", "", "", "", "", "1962-1151-032"],
          ["19620730", "Hamburg", "Clay", "W", "W", "", "", "", "R16", "6-1 6-3", "3", "Madonna Schacht", "", "", "", "R", "", "", "AUS", "0", "", "", "", "", "", "", "", "1962-1151-024"],
          ["19620730", "Hamburg", "Clay", "W", "W", "", "1", "", "R32", "6-0 6-2", "3", "Carola Alber", "", "", "", "U", "", "", "GER", "0", "", "", "", "", "", "", "", "1962-1151-008"],
          ["19620723", "Hilversum", "Clay", "W", "L", "", "", "", "F", "6-1 4-6 6-2", "3", "Maria Bueno", "", "", "", "R", "19391011", "170", "BRA", "0", "", "", "", "", "", "", "", "1962-1140-015"],
          ["19620723", "Hilversum", "Clay", "W", "W", "", "", "", "SF", "6-0 6-1", "3", "Marlene Gerson", "", "", "", "U", "19400621", "", "RSA", "0", "", "", "", "", "", "", "", "1962-1140-014"],
          ["19620723", "Hilversum", "Clay", "W", "W", "", "", "", "QF", "6-1 6-2", "3", "Jill Blackman", "", "", "", "U", "19420724", "", "AUS", "0", "", "", "", "", "", "", "1962-1140-040"],
          ["19620723", "Hilversum", "Clay", "W", "W", "", "", "", "R16", "6-0 6-2", "3", "Jill Bignell", "", "", "", "U", "", "", "NZL", "0", "", "", "", "", "", "", "1962-1140-036"],
          ["19620723", "Hilversum", "Clay", "W", "W", "", "2", "", "R32", "6-1 6-2", "3", "Bep Van Buuren", "", "", "", "U", "", "", "NED", "0", "", "", "", "", "", "", "1962-1140-028"],
          ["19620716", "Gstaad", "Clay", "W", "W", "", "", "", "F", "7-9 6-4 8-6", "3", "Lesley Turner", "", "", "", "R", "19420816", "", "AUS", "0", "", "", "", "", "", "", "", "1962-1136-005"],
          ["19620716", "Gstaad", "Clay", "W", "W", "", "", "", "SF", "6-4 6-2", "3", "Francoise Durr", "", "", "", "R", "19421225", "162", "FRA", "0", "", "", "", "", "", "", "", "1962-1136-003"],
          ["19620712", "Dusseldorf", "Clay", "W", "L", "", "", "", "SF", "6-3 6-3", "3", "Lesley Turner", "", "", "", "R", "19420816", "", "AUS", "0", "", "", "", "", "", "", "", "1962-1127-001"],
          ["19620625", "Wimbledon", "Grass", "G", "L", "", "", "", "R32", "6-4 6-4", "3", "Ann Jones", "", "5", "", "L", "19381007", "", "GBR", "0", "", "", "", "", "", "", "", "1962-1112-134"],
          ["19620625", "Wimbledon", "Grass", "G", "W", "", "", "", "R64", "6-2 1-6 8-6", "3", "Margaret Hellyer", "", "", "", "U", "19370729", "", "AUS", "0", "", "", "", "", "", "", "", "1962-1112-105"],
          ["19620611", "Bristol", "Grass", "W", "L", "", "", "", "SF", "9-7 3-6 7-5", "3", "Margaret Court", "", "", "", "R", "19420716", "175", "AUS", "0", "", "", "", "", "", "", "", "1962-1102-026"],
          ["19620611", "Bristol", "Grass", "W", "W", "", "", "", "QF", "8-6 6-2", "3", "Justina Bricka", "", "", "", "L", "19430214", "", "USA", "0", "", "", "", "", "", "", "", "1962-1102-024"],
          ["19620611", "Bristol", "Grass", "W", "W", "", "", "", "R16", "6-3 6-1", "3", "Eva Duldig", "", "", "", "R", "", "", "NED", "0", "", "", "", "", "", "", "", "1962-1102-017"],
          ["19620604", "Cheltenham", "Grass", "W", "L", "", "", "", "SF", "6-4 6-0", "3", "Ann Jones", "", "", "", "L", "19381007", "", "GBR", "0", "", "", "", "", "", "", "", "1962-1097-011"],
          ["19620604", "Cheltenham", "Grass", "W", "W", "", "", "", "QF", "6-2 6-1", "3", "Carmen Coronado", "", "", "", "U", "19400616", "", "ESP", "0", "", "", "", "", "", "", "", "1962-1097-007"],
          ["19620604", "Cheltenham", "Grass", "W", "W", "", "", "", "R16", "6-1 6-1", "3", "Caroline Leather", "", "", "", "U", "", "", "GBR", "0", "", "", "", "", "", "", "", "1962-1097-001"],
          ["19620521", "Roland Garros", "Clay", "G", "L", "", "5", "", "QF", "8-6 6-3", "3", "Lesley Turner", "", "13", "", "R", "19420816", "", "AUS", "0", "", "", "", "", "", "", "", "1962-1087-087"],
          ["19620521", "Roland Garros", "Clay", "G", "W", "", "5", "", "R16", "7-5 6-3", "3", "Francoise Durr", "", "", "", "R", "19421225", "162", "FRA", "0", "", "", "", "", "", "", "", "1962-1087-081"],
          ["19620521", "Roland Garros", "Clay", "G", "W", "", "5", "", "R32", "W/O", "3", "Christiane Mercelis", "", "", "", "R", "19311005", "", "BEL", "0", "", "", "", "", "", "", "", "1962-1087-070"],
          ["19620521", "Roland Garros", "Clay", "G", "W", "", "5", "", "R64", "6-1 6-2", "3", "Frances Maclennan", "", "", "", "U", "19431220", "", "GBR", "0", "", "", "", "", "", "", "", "1962-1087-048"],
          ["19620521", "Roland Garros", "Clay", "G", "W", "", "5", "", "R128", "6-1 6-0", "3", "Ginette Bucaille", "", "", "", "U", "19260125", "", "FRA", "0", "", "", "", "", "", "", "", "1962-1087-022"],
          ["19620516", "Baden", "Clay", "W", "L", "", "", "", "SF", "6-4 8-6", "3", "Maria Bueno", "", "", "", "R", "19391011", "170", "BRA", "0", "", "", "", "", "", "", "", "1962-1082-006"],
          ["19620516", "Baden", "Clay", "W", "W", "", "", "", "QF", "6-4 2-6 6-4", "3", "Edda Buding", "", "", "", "R", "19361113", "", "FRG", "0", "", "", "", "", "", "", "", "1962-1082-004"],
          ["19620108", "Cape Town", "Hard", "W", "L", "", "", "", "F", "1-6 6-1 6-3", "3", "Ann Jones", "", "", "", "L", "19381007", "", "GBR", "0", "", "", "", "", "", "", "", "1962-1004-013"],
          ["19620108", "Cape Town", "Hard", "W", "W", "", "", "", "SF", "6-1 6-1", "3", "Renee Schuurman", "", "", "", "R", "19391026", "", "RSA", "0", "", "", "", "", "", "", "", "1962-1004-012"],
          ["19620108", "Cape Town", "Hard", "W", "W", "", "", "", "R16", "6-1 6-1", "3", "Sandra Hesse", "", "", "", "U", "", "", "RSA", "0", "", "", "", "", "", "", "", "1962-1004-007"],
          ["19610807", "Hamburg", "Clay", "W", "W", "", "1", "", "F", "5-7 7-5 6-1", "3", "Yola Ramirez", "", "3", "", "R", "19350301", "", "MEX", "0", "", "", "", "", "", "", "", "1961-1141-037"],
          ["19610807", "Hamburg", "Clay", "W", "W", "", "1", "", "SF", "6-2 6-3", "3", "Zsuzsa Kormoczy", "", "4", "", "R", "19240825", "", "HUN", "0", "", "", "", "", "", "", "", "1961-1141-035"],
          ["19610807", "Hamburg", "Clay", "W", "W", "", "1", "", "QF", "6-2 6-1", "3", "Renata Ostermann", "", "", "", "U", "19370614", "", "FRG", "0", "", "", "", "", "", "", "", "1961-1141-031"],
          ["19610807", "Hamburg", "Clay", "W", "W", "", "1", "", "R16", "6-4 6-2", "3", "Marilen Knobling", "", "", "", "U", "", "", "GER", "0", "", "", "", "", "", "", "", "1961-1141-023"],
          ["19610807", "Hamburg", "Clay", "W", "W", "", "1", "", "R32", "W/O", "3", "Bodil Ulrich", "", "", "", "U", "", "", "NOR", "0", "", "", "", "", "", "", "", "1961-1141-007"],
          ["19610803", "Bad Neuenahr", "Clay", "W", "W", "", "", "", "F", "6-3 6-1", "3", "Renee Schuurman", "", "", "", "R", "19391026", "", "RSA", "0", "", "", "", "", "", "", "", "1961-1139-003"],
          ["19610803", "Bad Neuenahr", "Clay", "W", "W", "", "", "", "SF", "7-5 6-2", "3", "Yola Ramirez", "", "", "", "R", "19350301", "", "MEX", "0", "", "", "", "", "", "", "", "1961-1139-002"],
          ["19610727", "Munich", "Clay", "W", "L", "", "", "", "F", "7-5 9-7", "3", "Yola Ramirez", "", "", "", "R", "19350301", "", "MEX", "0", "", "", "", "", "", "", "", "1961-1131-003"],
          ["19610727", "Munich", "Clay", "W", "W", "", "", "", "SF", "7-5 10-8", "3", "Margot Dittmeyer", "", "", "", "U", "19350807", "", "FRG", "0", "", "", "", "", "", "", "", "1961-1131-001"],
          ["19610717", "Gstaad", "Clay", "W", "W", "", "", "", "F", "7-5 6-3", "3", "Yola Ramirez", "", "", "", "R", "19350301", "", "MEX", "0", "", "", "", "", "", "", "", "1961-1123-006"],
          ["19610717", "Gstaad", "Clay", "W", "W", "", "", "", "SF", "6-2 3-6 6-1", "3", "Mimi Wheeler", "", "", "", "U", "19390227", "155", "USA", "0", "", "", "", "", "", "", "", "1961-1123-004"],
          ["19610710", "Venice", "Clay", "W", "W", "", "", "", "F", "4-6 7-5 6-3", "3", "Yola Ramirez", "", "", "", "R", "19350301", "", "MEX", "0", "", "", "", "", "", "", "", "1961-1119-003"],
          ["19610710", "Venice", "Clay", "W", "W", "", "", "", "SF", "6-1 6-1", "3", "Lea Pericoli", "", "", "", "U", "19350322", "", "ITA", "0", "", "", "", "", "", "", "", "1961-1119-001"],
          ["19610626", "Wimbledon", "Grass", "G", "L", "", "1", "", "SF", "11-9 6-3", "3", "Angela Mortimer", "", "7", "", "R", "19320421", "", "GBR", "0", "", "", "", "", "", "", "", "1961-1107-094"],
          ["19610626", "Wimbledon", "Grass", "G", "W", "", "1", "", "QF", "4-6 6-3 6-0", "3", "Yola Ramirez", "", "5", "", "R", "19350301", "", "MEX", "0", "", "", "", "", "", "", "", "1961-1107-092"],
          ["19610626", "Wimbledon", "Grass", "G", "W", "", "1", "", "R16", "6-1 6-3", "3", "Florence De La Courtie", "", "", "", "R", "19321113", "", "FRA", "0", "", "", "", "", "", "", "", "1961-1107-088"],
          ["19610626", "Wimbledon", "Grass", "G", "W", "", "1", "", "R32", "6-3 6-2", "3", "Susan Butt", "", "", "Q", "U", "19380319", "", "CAN", "0", "", "", "", "", "", "", "", "1961-1107-080"],
          ["19610626", "Wimbledon", "Grass", "G", "W", "", "1", "", "R64", "6-3 6-2", "3", "Lorna Cornell", "", "", "", "U", "19330103", "", "GBR", "0", "", "", "", "", "", "", "", "1961-1107-064"],
          ["19610612", "Bristol", "Grass", "W", "W", "", "", "", "F", "7-5 10-8", "3", "Deidre Catt", "", "", "", "R", "19400704", "151", "GBR", "0", "", "", "", "", "", "", "", "1961-1102-026"],
          ["19610612", "Bristol", "Grass", "W", "W", "", "", "", "SF", "7-5 7-5", "3", "Jan Lehane", "", "", "", "R", "19410709", "", "AUS", "0", "", "", "", "", "", "", "", "1961-1102-024"],
          ["19610612", "Bristol", "Grass", "W", "W", "", "", "", "QF", "6-4 14-12", "3", "Elizabeth Starkie", "", "", "", "U", "19380831", "", "GBR", "0", "", "", "", "", "", "", "", "1961-1102-020"],
          ["19610612", "Bristol", "Grass", "W", "W", "", "", "", "R16", "W/O", "3", "Mary Eyre", "", "", "", "U", "", "", "GBR", "0", "", "", "", "", "", "", "", "1961-1102-012"],
          ["19610612", "Bristol", "Grass", "W", "W", "", "", "", "R32", "6-0 6-0", "3", "Wendy Hall", "", "", "", "U", "19441111", "", "GBR", "0", "", "", "", "", "", "", "", "1961-1102-001"],
          ["19610605", "Manchester", "Grass", "W", "W", "", "", "", "F", "6-4 6-3", "3", "Lesley Turner", "", "", "", "R", "19420816", "", "AUS", "0", "", "", "", "", "", "", "", "1961-1096-045"],
          ["19610605", "Manchester", "Grass", "W", "W", "", "", "", "SF", "6-3 7-5", "3", "Jan Lehane", "", "", "", "R", "19410709", "", "AUS", "0", "", "", "", "", "", "", "", "1961-1096-043"],
          ["19610605", "Manchester", "Grass", "W", "W", "", "", "", "QF", "6-2 5-7 7-5", "3", "Edda Buding", "", "", "", "R", "19361113", "", "FRG", "0", "", "", "", "", "", "", "", "1961-1096-039"],
          ["19610605", "Manchester", "Grass", "W", "W", "", "", "", "R16", "6-4 6-2", "3", "Robyn Ebbern", "", "", "", "R", "19440702", "", "AUS", "0", "", "", "", "", "", "", "", "1961-1096-031"],
          ["19610605", "Manchester", "Grass", "W", "W", "", "", "", "R32", "6-2 6-3", "3", "Honor Durose", "", "", "", "U", "", "", "GBR", "0", "", "", "", "", "", "", "", "1961-1096-015"],
          ["19610529", "Cheltenham", "Grass", "W", "L", "", "", "", "F", "5-7 6-2 8-6", "3", "Renee Schuurman", "", "", "", "R", "19391026", "", "RSA", "0", "", "", "", "", "", "", "", "1961-1093-007"],
          ["19610529", "Cheltenham", "Grass", "W", "W", "", "", "", "SF", "6-1 6-2", "3", "Jenny Ridderhof", "", "", "", "U", "19361024", "", "NED", "0", "", "", "", "", "", "", "", "1961-1093-005"],
          ["19610529", "Cheltenham", "Grass", "W", "W", "", "", "", "QF", "6-1 6-2", "3", "Mrs M J Marshall", "", "", "", "U", "", "", "GBR", "0", "", "", "", "", "", "", "", "1961-1093-001"],
          ["19610518", "Roland Garros", "Clay", "G", "L", "", "7", "", "R16", "7-5 3-6 7-5", "3", "Zsuzsa Kormoczy", "", "10", "", "R", "19240825", "", "HUN", "0", "", "", "", "", "", "", "", "1961-1086-060"],
          ["19610518", "Roland Garros", "Clay", "G", "W", "", "7", "", "R32", "6-1 6-2", "3", "Susan Butt", "", "", "", "U", "19380319", "", "CAN", "0", "", "", "", "", "", "", "", "1961-1086-045"],
          ["19610518", "Roland Garros", "Clay", "G", "W", "", "7", "", "R64", "6-3 6-1", "3", "Daniele Bouteleux", "", "", "", "U", "19401120", "", "FRA", "0", "", "", "", "", "", "", "", "1961-1086-015"],
          ["19610507", "Turin", "Clay", "W", "L", "", "2", "", "SF", "3-6 6-3 7-5", "3", "Lesley Turner", "", "", "", "R", "19420816", "", "AUS", "0", "", "", "", "", "", "", "", "1961-1078-038"],
          ["19610507", "Turin", "Clay", "W", "W", "", "2", "", "QF", "6-4 6-2", "3", "Jan Lehane", "", "7", "", "R", "19410709", "", "AUS", "0", "", "", "", "", "", "", "", "1961-1078-035"],
          ["19610507", "Turin", "Clay", "W", "W", "", "2", "", "R16", "6-3 6-4", "3", "Robyn Ebbern", "", "", "", "R", "19440702", "", "AUS", "0", "", "", "", "", "", "", "", "1961-1078-029"],
          ["19610507", "Turin", "Clay", "W", "W", "", "2", "", "R32", "6-1 6-2", "3", "Xantipes Vassiliadis", "", "", "", "U", "", "", "GRE", "0", "", "", "", "", "", "", "", "1961-1078-017"],
          ["19610408", "Port Elizabeth GBR vs RSA", "Hard", "W", "W", "", "", "", "RR", "7-5 6-4", "3", "Jan Lehane", "", "", "", "R", "19410709", "", "AUS", "0", "", "", "", "", "", "", "", "1961-1062-002"],
          ["19610323", "Johannesburg", "Hard", "W", "W", "", "", "", "F", "6-4 7-5", "3", "Lynne Nette", "", "", "", "R", "19420526", "", "AUS", "0", "", "", "", "", "", "", "", "1961-1052-029"],
          ["19610323", "Johannesburg", "Hard", "W", "W", "", "", "", "SF", "6-2 6-3", "3", "Valerie Forbes", "", "", "", "U", "19370215", "", "RSA", "0", "", "", "", "", "", "", "", "1961-1052-027"],
          ["19610323", "Johannesburg", "Hard", "W", "W", "", "", "", "QF", "6-1 3-6 6-3", "3", "Margaret Hunt", "", "", "", "U", "19420425", "", "RSA", "0", "", "", "", "", "", "", "", "1961-1052-023"],
          ["19610323", "Johannesburg", "Hard", "W", "W", "", "", "", "R16", "UNK", "3", "Charleen Rigby", "", "", "", "U", "", "", "RSA", "0", "", "", "", "", "", "", "", "1961-1052-015"],
          ["19610201", "Cape Town", "Hard", "W", "W", "", "", "", "F", "6-2 6-4", "3", "Lynne Nette", "", "", "", "R", "19420526", "", "AUS", "0", "", "", "", "", "", "", "", "1961-1019-003"],
          ["19610201", "Cape Town", "Hard", "W", "W", "", "", "", "SF", "8-6 6-2", "3", "Jean Forbes", "", "", "", "U", "19390923", "", "RSA", "0", "", "", "", "", "", "", "", "1961-1019-001"]
          ];
