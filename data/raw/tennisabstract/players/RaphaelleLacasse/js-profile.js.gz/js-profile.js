
    var fullname = 'Raphaelle Lacasse';
    var lastname = 'Lacasse';
    var currentrank=676;
    var peakrank=646;
    var peakfirst=20251124;
    var peaklast=20251124;
    var dob=20000816;
    
    var hand='R';
    var backhand='';
    var country='CAN';
    var shortlist=22;
    var careerjs=1;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100236861';
    var wta_id='';
    var fc_id='';
    var wiki_id='';
    var blast_link='';
    var more_link='';
    var death_date="";
    var dob_approx="";
    var elo_rating='';
    var elo_rank='';
    var ychoices=["Time Span", "Last 52", "Career", "2025", "2024", "2021", "2019", "2018"];
var tchoices=["Event", "All", "Montreal", "W15 Banja Luka", "W15 Buenos Aires", "W15 Cancun", "W15 Lima", "W15 Monastir", "W15 Montreal", "W15 Santo Domingo ", "W15 Sharm El Sheikh", "W15 Sibenik", "W15 Tabarka", "W15 Trois-Rivieres", "W25 Guayaquil", "W35 Boca Raton FL", "W35 Edmonton", "W35 Punta Cana", "W35 Quebec City", "W35 Santo Domingo", "W35 Santo Domingo ", "W35 Southaven MS", "W50 Arequipa", "W50 Saskatoon", "W60 Saguenay", "W60 Toronto", "W75+ H Toronto", "W75+H Calgary", "W75+H Saguenay", "Bogota $15K", "Cucuta $15K", "Guayaquil $15K", "Hammamet $15K", "Hammamet 15K", "Mexico City $15K"];
var cchoices=["vs Country", "All", "ARG", "AUS", "BEL", "BOL", "BRA", "CAN", "COL", "CZE", "DEN", "DOM", "ECU", "EGY", "ESP", "FRA", "GBR", "GEO", "GER", "GUA", "HUN", "IND", "ITA", "JPN", "KOR", "MEX", "NED", "PER", "POL", "RSA", "RUS", "SUI", "SVK", "SWE", "UKR", "USA"];
var rchoices=["as Rank", "All"];
var ochoices=["Jasmijn Gimbrere", "Ana Karen Guadiana Campos", "Victoria Allen", "Valentina Mediorreal Arias", "Urszula Radwanska", "Teah Chavez", "Sujin Lee", "Sofia Camila Rojas", "Sara Daavettila", "Salma Ewing", "Riley Crowder", "Prathyusha Rachapudi", "Patricia Cano", "Olivia Gadecki", "Nelise Verster", "Naoko Eto", "Mayu Crossley", "Marcella Cruz", "Malaika Rapolu", "Kristina Paskauskas", "Kayla Day", "Katya Ramirez", "Kaede Usui", "Julia Konishi Camargo Silva", "Isabelle Boulais", "Hiroko Kuwata", "Haruna Arakawa", "Clara Vlasselaer", "Carolina Kuhl", "Camille Kiss", "Cadence Brace", "Ashley Lahey", "Arina Bulatova", "Anna Sinclair Rogers", "Anna Shkutova", "Ana Carmen Zamburek", "Alahya De Jesus", "Gabriela Ce", "Constance Sibille", "Zora Hudson", "Zoe Howard", "Yasmina El Sayed", "Viktoria Morvayova", "Vanessa Ong", "Thaisa Grana Pedretti", "Taylor Ng", "Tatiana Pieri", "Tara Moore", "Tara Malik", "Solymar Colling", "Solana Sierra", "Shelby Prince", "Shatoo Mohamad", "Salome Sierra", "Sabrina Rittberger", "Olga Helmi", "Noelia Zeballos", "Nino Natsvlishvili", "Nicole Gadient", "Nermeen Shawky", "Melisa Morales", "Mayar Sherif", "Mary Closs", "Martina Capurro Taborda", "Marne Dercksen", "Mariia Antoniuk", "Maribella Zamarripa", "Maria Gabriela Rivera Corado", "Maria Del Rosario Vazquez", "Mao Mushika", "Mana Ayukawa", "Maja Radenkovic", "Lian Tran", "Larissa Ravanini De Souza", "Katya Townsend", "Katarina Kuzmova", "Joselyn Margarita Treyes Albarracan", "Joanne Zuger", "Jessica Plazas", "Jenna Defalco", "Isabella Bolivar Garces", "Irene Burillo Escorihuela", "Guillermina Naya", "Federica Prati", "Fanny Stollar", "Eva Vedder", "Emira Stafford", "Emiliana Arango", "Elizabeth Mandlik", "Eliz Maloney", "Christina Mchale", "Chieh Yu Hsu", "Chi Chi Scholl", "Catalina Pella", "Camille Townsend", "Camila Soares", "Brittany Collens", "Brenda Sarahi Baez", "Bibiane Schoofs", "Barbora Palicova", "Audrey Ann Blakely", "Aubane Droguet", "Antonia Schmidt", "Anoushka Wooller", "Anika Jaskova", "Angelica Raggi", "Anastasia Kuprina", "Amira Badawi", "Amber Washington", "Allura Zamarripa", "Alisa Axyanova"];
var tdates=["20180618", "20180625", "20180806", "20180813", "20181029", "20181105", "20181203", "20190311", "20190318", "20190325", "20190520", "20190527", "20190603", "20190610", "20190617", "20190624", "20190708", "20190715", "20190812", "20190819", "20190909", "20190916", "20191021", "20191028", "20191111", "20191118", "20210215", "20210222", "20210301", "20210308", "20210315", "20210322", "20210329", "20210517", "20210524", "20210531", "20210614", "20210621", "20210628", "20210809", "20240610", "20240819", "20240909", "20241007", "20241014", "20241021", "20241028", "20241118", "20241125", "20250303", "20250310", "20250428", "20250505", "20250519", "20250526", "20250804", "20250811", "20250901", "20251013"];
var vranks=["104", "122", "156", "305", "321", "387", "406", "423", "425", "437", "457", "465", "471", "505", "506", "511", "512", "514", "520", "534", "555", "566", "575", "576", "577", "579", "603", "617", "623", "628", "633", "634", "671", "721", "827", "830", "831", "848", "882", "897", "911", "919", "981", "1076", "1079", "1091", "1101", "1122", "1129", "1131", "1136", "1140", "1150", "1202", "1231", "1256", "1259", "1294", "1301", "1331", "1377"];
playernews = [];
var upcoming = "";
var matchmx = [["20250303", "W15 Trois-Rivieres", "Hard", "15", "L", "1257", "", "", "R32", "6-3 6-7(0) 7-6(7)", "3", "Malaika Rapolu", "534", "", "", "U", "20030418", "", "USA", "0", "181", "5", "8", "123", "81", "48", "25", "17", "7", "13", "3", "5", "107", "60", "41", "25", "16", "2", "6", "", "", "", "", "2025-W-ITF-CAN-2025-001-113"],
          ["20250310", "W15 Montreal", "Hard", "15", "L", "1257", "", "", "R16", "6-1 6-2", "3", "Sara Daavettila", "471", "", "", "U", "19971217", "", "USA", "0", "70", "2", "6", "51", "29", "17", "6", "8", "7", "12", "0", "6", "47", "34", "25", "7", "7", "3", "3", "", "", "", "", "2025-W-ITF-CAN-2025-002-208"],
          ["20250310", "W15 Montreal", "Hard", "15", "W", "1257", "", "", "R32", "6-4 6-3", "3", "Kaede Usui", "1294", "", "", "U", "", "", "USA", "0", "108", "4", "1", "76", "59", "38", "6", "10", "4", "7", "0", "3", "64", "44", "22", "9", "9", "5", "10", "", "", "", "", "2025-W-ITF-CAN-2025-002-115"],
          ["20250428", "W35 Boca Raton FL", "Clay", "35", "L", "1213", "", "", "R32", "6-0 6-2", "3", "Mayu Crossley", "511", "", "", "R", "20060615", "", "JPN", "0", "61", "0", "3", "35", "15", "7", "7", "7", "2", "7", "0", "0", "38", "26", "22", "6", "7", "0", "0", "", "", "", "", "2025-W-ITF-USA-2025-013-107"],
          ["20250505", "W35 Boca Raton FL", "Clay", "35", "L", "1212", "", "", "R16", "6-1 7-5", "3", "Kayla Day", "387", "", "", "L", "19990928", "173", "USA", "0", "101", "2", "2", "59", "37", "20", "9", "10", "5", "11", "3", "5", "57", "36", "23", "12", "9", "1", "3", "", "", "", "", "2025-W-ITF-USA-2025-016-203"],
          ["20250505", "W35 Boca Raton FL", "Clay", "35", "W", "1212", "", "", "R32", "6-4 6-0", "3", "Riley Crowder", "", "", "", "U", "", "", "USA", "0", "74", "0", "3", "47", "34", "25", "6", "8", "1", "2", "0", "5", "45", "24", "11", "9", "8", "4", "9", "", "", "", "", "2025-W-ITF-USA-2025-016-106"],
          ["20250519", "W35 Santo Domingo", "Clay", "35", "L", "1077", "", "", "R16", "7-6(3) 6-1", "3", "Haruna Arakawa", "514", "", "", "U", "19991027", "", "JPN", "0", "106", "1", "4", "56", "34", "15", "8", "9", "2", "8", "0", "2", "71", "52", "32", "7", "10", "6", "10", "", "", "", "", "2025-W-ITF-DOM-2025-003-303"],
          ["20250519", "W35 Santo Domingo", "Clay", "35", "W", "1077", "", "", "R32", "4-6 6-4 6-2", "3", "Julia Konishi Camargo Silva", "831", "", "", "U", "20000126", "", "BRA", "0", "157", "1", "12", "93", "59", "33", "16", "14", "5", "11", "1", "7", "107", "56", "29", "21", "14", "9", "17", "", "", "", "", "2025-W-ITF-DOM-2025-003-206"],
          ["20250519", "W35 Santo Domingo", "Clay", "35", "W", "1077", "", "", "R64", "6-3 6-0", "3", "Naoko Eto", "", "", "", "R", "19841217", "", "JPN", "0", "95", "1", "10", "56", "29", "22", "14", "8", "4", "5", "0", "4", "56", "34", "16", "8", "7", "6", "11", "", "", "", "", "2025-W-ITF-DOM-2025-003-111"],
          ["20250526", "W35 Santo Domingo", "Clay", "35", "L", "1082", "", "", "R32", "6-3 6-4", "3", "Cadence Brace", "305", "", "", "R", "20050225", "", "CAN", "0", "115", "0", "5", "61", "37", "19", "9", "10", "1", "7", "1", "2", "70", "46", "26", "13", "9", "3", "6", "", "", "", "", "2025-W-ITF-DOM-2025-004-216"],
          ["20250526", "W35 Santo Domingo", "Clay", "35", "W", "1082", "", "", "R64", "6-1 6-4", "3", "Prathyusha Rachapudi", "", "", "", "R", "", "", "IND", "0", "85", "3", "4", "50", "30", "19", "8", "8", "5", "8", "0", "11", "54", "19", "8", "12", "9", "1", "8", "", "", "", "", "2025-W-ITF-DOM-2025-004-131"],
          ["20250804", "W35 Southaven MS", "Hard", "35", "L", "953", "", "", "R32", "6-2 6-4", "3", "Ashley Lahey", "671", "", "", "U", "19991026", "", "USA", "0", "106", "1", "7", "71", "45", "21", "10", "9", "8", "14", "1", "4", "56", "36", "24", "8", "9", "3", "6", "", "", "", "", "2025-W-ITF-USA-2025-035-110"],
          ["20250811", "W50 Saskatoon", "Hard", "50", "L", "953", "", "", "QF", "6-4 4-6 7-5", "3", "Salma Ewing", "830", "", "", "R", "20000828", "", "USA", "0", "190", "4", "6", "97", "62", "39", "19", "16", "2", "7", "1", "4", "105", "61", "44", "20", "16", "10", "14", "", "", "", "", "2025-W-ITF-CAN-2025-003-301"],
          ["20250811", "W50 Saskatoon", "Hard", "50", "W", "953", "", "", "R16", "6-5 RET", "3", "Olivia Gadecki", "122", "", "", "R", "20020424", "", "AUS", "0", "67", "0", "2", "44", "28", "16", "5", "5", "8", "11", "0", "2", "37", "23", "8", "8", "6", "2", "6", "", "", "", "", "2025-W-ITF-CAN-2025-003-201"],
          ["20250811", "W50 Saskatoon", "Hard", "50", "W", "953", "", "", "R32", "6-2 6-2", "3", "Hiroko Kuwata", "603", "", "", "R", "19901218", "", "JPN", "0", "73", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2025-W-ITF-CAN-2025-003-102"],
          ["20250901", "W15 Monastir", "Hard", "15", "L", "829", "", "", "QF", "6-1 4-6 6-4", "3", "Arina Bulatova", "457", "", "", "U", "20060418", "", "RUS", "0", "158", "4", "11", "82", "45", "28", "15", "13", "3", "9", "0", "15", "98", "61", "43", "13", "14", "6", "10", "", "", "", "", "2025-W-ITF-TUN-2025-037-301"],
          ["20250901", "W15 Monastir", "Hard", "15", "W", "829", "", "", "R16", "6-4 6-4", "3", "Anna Shkutova", "", "", "", "U", "", "", "RUS", "0", "112", "5", "6", "58", "30", "18", "12", "10", "1", "5", "0", "4", "76", "52", "24", "12", "10", "4", "10", "", "", "", "", "2025-W-ITF-TUN-2025-037-202"],
          ["20250901", "W15 Monastir", "Hard", "15", "W", "829", "", "", "R32", "6-4 7-6(2)", "3", "Nelise Verster", "", "", "", "L", "19960604", "", "RSA", "0", "130", "8", "5", "63", "40", "32", "11", "11", "4", "7", "1", "3", "86", "51", "32", "14", "11", "10", "14", "", "", "", "", "2025-W-ITF-TUN-2025-037-104"],
          ["20251013", "W35 Quebec City", "Hard", "35", "L", "811", "", "", "SF", "6-1 6-1", "3", "Victoria Allen", "617", "", "", "U", "20010226", "", "GBR", "0", "64", "2", "2", "53", "37", "17", "5", "7", "7", "12", "3", "0", "38", "27", "21", "9", "7", "4", "4", "", "", "", "", "2025-W-ITF-CAN-2025-009-401"],
          ["20251013", "W35 Quebec City", "Hard", "35", "W", "811", "", "", "QF", "3-6 6-2 7-6(4)", "3", "Teah Chavez", "", "", "", "U", "20051217", "", "CAN", "0", "148", "5", "4", "107", "68", "45", "21", "14", "6", "9", "2", "1", "100", "75", "49", "11", "15", "7", "11", "", "", "", "", "2025-W-ITF-CAN-2025-009-302"],
          ["20251013", "W35 Quebec City", "Hard", "35", "W", "811", "", "", "R16", "7-6(3) 6-7(3) 6-4", "3", "Clara Vlasselaer", "633", "", "", "U", "20010303", "", "BEL", "0", "187", "11", "3", "117", "79", "57", "25", "17", "3", "4", "10", "8", "122", "69", "53", "28", "17", "2", "4", "", "", "", "", "2025-W-ITF-CAN-2025-009-204"],
          ["20251013", "W35 Quebec City", "Hard", "35", "W", "811", "", "", "R32", "6-3 6-4", "3", "Carolina Kuhl", "520", "", "", "U", "20050404", "", "GER", "0", "75", "10", "1", "54", "40", "37", "7", "10", "3", "3", "1", "0", "50", "32", "23", "9", "9", "2", "4", "", "", "", "", "2025-W-ITF-CAN-2025-009-108"]
          ];
