
    var fullname = 'Federico Agustin Gomez';
    var lastname = 'Gomez';
    var currentrank=1729;
    var peakrank=1702;
    var peakfirst=20141027;
    var peaklast=20141027;
    var dob=19961126;
    
    var hand='R';
    var backhand='';
    var country='ARG';
    var shortlist=2;
    var careerjs=0;
    var active=0;
    var lastdate=20140908;
    var twitter='';
    var ychoices=["Time Span", "Last 52", "Career", "2014"];
var tchoices=["Event", "All"];
var cchoices=["vs Country", "All", "ARG", "URU"];
var rchoices=["as Rank", "All"];
var ochoices=["Rodrigo Arus", "Nicolas Kicker"];
var tdates=["20140908"];
var vranks=["341", "1224"];
playernews = [];
var upcoming = "";
var matchmx = [["20140908", "Argentina F17", "Clay", "S", "L", "UNR", "", "Q", "R16", "6-3 6-2", "3", "Nicolas Kicker", "341", "1", "", "U", "19920816", "", "ARG", "1", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2014-M-FU-ARG-17A-2014-017", "", "2", "2"],
          ["20140908", "Argentina F17", "Clay", "S", "W", "UNR", "", "Q", "R32", "6-4 7-5", "3", "Rodrigo Arus", "1224", "", "", "U", "19950220", "", "URU", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2014-M-FU-ARG-17A-2014-002", "", "1", "1"]
          ];
