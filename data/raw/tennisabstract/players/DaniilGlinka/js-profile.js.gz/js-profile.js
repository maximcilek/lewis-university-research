
    var fullname = 'Daniil Glinka';
    var lastname = 'Glinka';
    var currentrank=1843;
    var peakrank=1720;
    var peakfirst=20181105;
    var peaklast=20181105;
    var dob=20000512;
    
    var hand='U';
    var backhand='';
    var country='EST';
    var shortlist=5;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs=1057;
    var peak_dubs=1057;
    var peakfirst_dubs=20181119;
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100203909';
    var atp_id='';
    var dc_id='';
    var wiki_id='';
    var ychoices=["Time Span", "Last 52", "Career", "2018", "2017"];
var tchoices=["Event", "All"];
var cchoices=["vs Country", "All", "BLR", "CZE", "EST", "RUS", "UKR"];
var rchoices=["as Rank", "All"];
var ochoices=["Matvey Khomentovskiy", "Marek Gengel", "Marat Deviatiarov", "Karl Kiur Saar", "Aleksei Khomich"];
var tdates=["20171023", "20180716", "20181001", "20181029"];
var vranks=["620", "704", "1061", "1230", "1445"];
playernews = [];
var upcoming = "";
var matchmx = [["20171023", "Estonia F2", "Carpet", "S", "L", "", "", "WC", "R32", "3-6 6-3 6-2", "3", "Marat Deviatiarov", "620", "", "", "R", "23.5126625599", "", "UKR", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2017-M-FU-EST-02A-2017-013", "", "1", "1"],
          ["20180716", "Estonia F1", "Clay", "S", "L", "UNR", "", "WC", "R32", "7-6(3) 6-2", "3", "Matvey Khomentovskiy", "1061", "", "", "R", "19940825", "", "RUS", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-EST-01A-2018-006", "", "1", "1"],
          ["20181001", "Egypt F21", "Hard", "S", "L", "UNR", "", "", "R16", "7-6(4) 6-4", "3", "Marek Gengel", "704", "", "", "R", "19950917", "", "CZE", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-EGY-21A-2018-019", "", "2", "2"],
          ["20181001", "Egypt F21", "Hard", "S", "W", "UNR", "", "", "R32", "7-5 6-4", "3", "Aleksei Khomich", "1445", "", "", "U", "19970110", "", "BLR", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-EGY-21A-2018-006", "", "1", "1"],
          ["20181029", "Estonia F2", "Carpet", "S", "L", "1822", "", "WC", "R32", "6-3 6-4", "3", "Karl Kiur Saar", "1230", "", "", "U", "19960421", "", "EST", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-EST-02A-2018-007", "", "1", "1"]
          ];
