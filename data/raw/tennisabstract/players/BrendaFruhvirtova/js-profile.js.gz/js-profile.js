
    var fullname = 'Brenda Fruhvirtova';
    var lastname = 'Fruhvirtova';
    var currentrank=1261;
    var peakrank=87;
    var peakfirst=20240729;
    var peaklast=20240729;
    var dob=20070402;
    
    var hand='R';
    var backhand='2';
    var country='CZE';
    var shortlist=12;
    var careerjs=1;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='sirobi';
    var photog_credit='si.robi';
    var photog_link='https://www.flickr.com/photos/sirobi';
    var itf_id='';
    var wta_id='';
    var fc_id='';
    var wiki_id='Brenda_Fruhvirtova';
    var blast_link='';
    var more_link='';
    var death_date="";
    var dob_approx="";
    var elo_rating='';
    var elo_rank='';
    var ychoices=["Time Span", "Last 52", "Career", "2026", "2025", "2024", "2023", "2022"];
var tchoices=["Event", "All", "Australian Open", "Wimbledon", "US Open", "Angers 125", "Auckland", "Buenos Aires 125", "Colina 125", "Guadalajara", "Madrid", "Makarska 125", "Miami", "Montevideo 125", "Ostrava", "Roland Garros", "Rome", "W15 Antalya", "W15 Viserba", "W25 Antalya", "W25 Braunschweig", "W25 Danderyd", "W25 Klosters", "W25 Le Havre", "W25 Leipzig", "W25 Mogyorod", "W25 Monastir", "W25 Santa Margherita di Pula", "W25 Tucuman", "W40 Bengaluru", "W40 Guadalajara", "W40 Heraklion", "W40 Oldenzaal", "W50 Heraklion", "W60 Amstelveen", "W60 Hechingen", "W60 San Sebastian", "W75 Hechingen", "W75 Ismaning", "W75 Trnava"];
var cchoices=["vs Country", "All", "ARG", "AUS", "AUT", "BDI", "BEL", "BLR", "BRA", "BUL", "CAN", "CHI", "CHN", "CRO", "CZE", "DEN", "EGY", "ESP", "EST", "FRA", "GBR", "GER", "GRE", "HUN", "INA", "IND", "ITA", "JPN", "KAZ", "LAT", "LIE", "NED", "NOR", "NZL", "POL", "ROU", "RUS", "SLO", "SRB", "SUI", "SVK", "THA", "TPE", "UKR", "USA", "UZB"];
var rchoices=["as Rank", "All", "Top 100", "Top 200", "101+", "201+"];
var ochoices=["Oceane Dodin", "Xiyu Wang", "Fabienne Gettwart", "Ekaterina Makarova", "Sara Errani", "Sapfo Sakellaridi", "Maria Lourdes Carle", "Anouk Koevermans", "Ysaline Bonaventure", "Viktoria Hruncakova", "Varvara Lepchenko", "Taylor Townsend", "Tatiana Pieri", "Talia Gibson", "Sorana Cirstea", "Simona Waltert", "Sijia Wei", "Robin Montgomery", "Radka Zelnickova", "Petra Hule", "Paula Badosa", "Natalija Stevanovic", "Mirra Andreeva", "Mara Guth", "Maja Chwalinska", "Laura Samson", "Katie Boulter", "Katharina Hobgarski", "Julia Stamatova", "Julia Middendorf", "Jule Niemeier", "Jessica Bouzas Maneiro", "Himeno Sakatsume", "Fiona Ferro", "Elyse Tse", "Coco Gauff", "Camilla Gennaro", "Barbara Dessolis", "Aryna Sabalenka", "Arantxa Rus", "Anna Snigireva", "Anna Blinkova", "Aneta Laboutkova", "Ana Bogdan", "Allegra Fiorani", "Ziva Falkner", "Yue Yuan", "Ya Hsuan Lee", "Veronica Miroshnichenko", "Valeriya Strakhova", "Suzan Lamens", "Sofya Lansere", "Sofia Costoulas", "Sinja Kraus", "Sara Bejlek", "Sada Nahimana", "Priska Madelyn Nugroho", "Peangtarn Plipuech", "Paula Ormaechea", "Oleksandra Oliynykova", "Moyuka Uchijima", "Miriana Tona", "Michaela Laki", "Lian Tran", "Leyre Romero Gormaz", "Leylah Fernandez", "Lara Salden", "Kathinka Von Deichmann", "Katherine Sebov", "Kaia Kanepi", "Isabella Shinikova", "Irina Bara", "Guillermina Naya", "Gergana Topalova", "Gabriela Lee", "Eva Vedder", "Emma Fulvia Wiesenfeld", "Ella Seidel", "Elena Rybakina", "Darya Astakhova", "Daria Snigur", "Daniela Vismane", "Dalila Jakupovic", "Antonia Ruzic", "Annelin Bakker", "Anna Kalinskaya", "Anna Gabric", "Anna Bondar", "Ankita Raina", "Aneta Kladivova", "Anastasiya Soboleva", "Amy Zhu", "Alisa Oktiabreva", "Alice Robbe", "Aliaksandra Sasnovich", "Ylena In Albon", "Yasmine Mansouri", "Weronika Falkowska", "Victoria Muntean", "Tayisiya Morderger", "Sofia Nami Samavati", "Sloane Stephens", "Rina Saigo", "Nuria Brancaccio", "Noma Noha Akugue", "Nina Potocnik", "Nigina Abduraimova", "Nicoleta Catalina Dascalu", "Mona Barthel", "Miriam Bianca Bulgaru", "Michaela Bayerlova", "Mayar Sherif", "Martina Caregaro", "Madison Bourguignon", "Luisa Meyer Auf Der Heide", "Lucia Peyre", "Lucia Cortez Llorca", "Leonie Kung", "Katharina Gerlach", "Kateryna Baindl", "Julia Riera", "Jessika Ponchet", "Jessica Pieri", "Irene Lavino", "Helena Buchwald", "Gloria Ceschi", "Ganna Poznikhirenko", "Gabriella Price", "Emily Seibold", "Emilie Elde", "Elsa Jacquemot", "Elina Avanesyan", "Carolina Alves", "Barbora Palicova", "Barbara Gatica", "Anna Turati", "Ane Mintegi Del Olmo", "Anastasia Zhilina", "Alexandra Cadantu Ignatik"];
var tdates=["20220117", "20220131", "20220207", "20220221", "20220307", "20220314", "20220321", "20220620", "20220808", "20220815", "20220822", "20220912", "20220926", "20221017", "20221107", "20221114", "20221121", "20230102", "20230116", "20230306", "20230320", "20230424", "20230529", "20230703", "20230710", "20230731", "20230807", "20230828", "20231023", "20231030", "20231106", "20231120", "20240101", "20240115", "20240318", "20240422", "20240506", "20240527", "20240603", "20240701", "20240729", "20240826", "20241104", "20241202", "20250113", "20250908", "20251006", "20251124", "20251215", "20251222", "20260201"];
var vranks=["2", "3", "4", "23", "30", "32", "38", "40", "47", "48", "57", "58", "59", "61", "62", "63", "73", "93", "100", "101", "105", "106", "107", "111", "113", "126", "132", "138", "141", "143", "147", "157", "159", "171", "172", "173", "176", "177", "180", "183", "184", "186", "190", "193", "199", "204", "206", "210", "215", "224", "228", "230", "232", "233", "235", "236", "240", "241", "242", "243", "264", "273", "280", "281", "288", "293", "303", "304", "305", "307", "309", "310", "311", "312", "314", "328", "338", "342", "353", "375", "387", "398", "400", "403", "407", "410", "417", "421", "425", "429", "434", "436", "438", "443", "460", "461", "462", "483", "484", "486", "497", "505", "509", "518", "527", "541", "547", "553", "556", "569", "574", "611", "625", "670", "674", "696", "705", "707", "714", "719", "726", "750", "818", "825", "831", "874", "876", "920", "923", "1010", "1019", "1039", "1040", "1185", "1222", "1244"];
playernews = [];
var upcoming = "";
var matchmx = [["20250113", "Australian Open", "Hard", "G", "L", "196", "", "", "Q3", "6-3 6-4", "3", "Maja Chwalinska", "126", "20", "", "L", "20011011", "", "POL", "0", "94", "1", "1", "69", "43", "20", "13", "9", "5", "10", "1", "1", "58", "41", "26", "7", "10", "0", "3", "", "", "", "", "2025-580-799"],
          ["20250113", "Australian Open", "Hard", "G", "W", "196", "", "", "Q1", "6-4 6-2", "3", "Ysaline Bonaventure", "920", "", "", "L", "19940829", "178", "BEL", "0", "62", "4", "1", "48", "28", "22", "14", "9", "0", "0", "5", "5", "59", "35", "25", "7", "9", "3", "6", "", "", "", "", "2025-580-713"],
          ["20250113", "Australian Open", "Hard", "G", "W", "196", "", "", "Q2", "6-0 6-2", "3", "Sara Errani", "107", "4", "", "R", "19870429", "164", "ITA", "0", "60", "6", "2", "59", "40", "28", "8", "7", "4", "5", "0", "1", "42", "31", "12", "2", "7", "5", "11", "", "", "", "", "2025-580-770"],
          ["20250908", "W15 Viserba", "Clay", "15", "L", "822", "", "", "QF", "6-4 4-6 7-6(4)", "3", "Camilla Gennaro", "707", "", "", "U", "20030930", "", "ITA", "0", "157", "1", "10", "108", "62", "37", "20", "16", "5", "11", "0", "4", "99", "50", "31", "23", "16", "5", "11", "", "", "", "", "2025-W-ITF-ITA-2025-020-302"],
          ["20250908", "W15 Viserba", "Clay", "15", "W", "822", "", "", "R16", "7-5 6-3", "3", "Barbara Dessolis", "1222", "", "", "R", "20010921", "", "ITA", "0", "102", "1", "6", "58", "25", "15", "15", "10", "2", "7", "0", "6", "79", "53", "26", "7", "11", "4", "12", "", "", "", "", "2025-W-ITF-ITA-2025-020-203"],
          ["20250908", "W15 Viserba", "Clay", "15", "W", "822", "", "", "R32", "6-0 6-0", "3", "Allegra Fiorani", "", "", "", "U", "", "", "ITA", "0", "54", "0", "3", "37", "19", "15", "12", "6", "5", "5", "0", "6", "39", "20", "10", "2", "6", "5", "11", "", "", "", "", "2025-W-ITF-ITA-2025-020-105"],
          ["20251006", "W50 Heraklion", "Clay", "50", "L", "810", "", "", "R32", "2-6 6-2 4-0", "3", "Laura Samson", "273", "", "", "R", "20080310", "", "CZE", "0", "96", "0", "8", "57", "27", "18", "9", "10", "3", "8", "1", "3", "65", "37", "20", "17", "10", "7", "10", "", "", "", "", "2025-W-ITF-GRE-2025-008-209"],
          ["20251006", "W50 Heraklion", "Clay", "50", "W", "810", "", "", "R64", "7-5 6-1", "3", "Fabienne Gettwart", "1010", "", "", "U", "19960103", "", "GER", "0", "99", "0", "11", "72", "43", "27", "10", "10", "6", "11", "0", "6", "64", "38", "18", "5", "9", "5", "13", "", "", "", "", "2025-W-ITF-GRE-2025-008-118"],
          ["20251124", "W75 Trnava", "Hard", "75", "L", "809", "", "", "R32", "6-3 6-2", "3", "Radka Zelnickova", "486", "", "", "R", "20030613", "", "SVK", "0", "58", "1", "4", "44", "32", "17", "6", "8", "0", "4", "11", "0", "44", "28", "21", "14", "9", "4", "5", "", "", "", "", "2025-W-ITF-SVK-2025-006-114"],
          ["20251215", "W15 Antalya", "Clay", "15", "L", "810", "", "", "R32", "7-5 6-1", "3", "Julia Stamatova", "874", "", "", "L", "19930604", "", "BUL", "0", "85", "2", "6", "48", "24", "12", "13", "9", "0", "4", "0", "3", "68", "43", "32", "12", "10", "4", "5", "", "", "", "", "2025-W-ITF-TUR-2025-041-115"],
          ["20251222", "W15 Antalya", "Clay", "15", "L", "809", "", "", "R32", "6-4 6-1", "3", "Anna Snigireva", "1040", "", "", "U", "20071222", "", "RUS", "0", "61", "0", "3", "46", "33", "14", "3", "8", "1", "7", "3", "2", "50", "30", "23", "7", "9", "3", "6", "", "", "", "", "2025-W-ITF-TUR-2025-042-104"],
          ["20260201", "Ostrava", "Hard", "I", "L", "1311", "", "WC", "R32", "6-1 6-1", "3", "Fiona Ferro", "281", "", "Q", "R", "19970312", "170", "FRA", "0", "60", "0", "2", "42", "28", "11", "2", "7", "2", "9", "1", "3", "44", "25", "15", "10", "7", "2", "4", "", "", "", "", "2026-1154-275"]
          ];
