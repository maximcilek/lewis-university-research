
    var fullname = 'Julia Garcia Ruiz';
    var lastname = 'Garcia Ruiz';
    var currentrank=881;
    var peakrank=763;
    var peakfirst=20250721;
    var peaklast=20250804;
    var dob=20030805;
    
    var hand='L';
    var backhand='2';
    var country='MEX';
    var shortlist=4;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='';
    var wta_id='';
    var fc_id='';
    var wiki_id='';
    var blast_link='';
    var more_link='';
    var death_date="";
    var dob_approx="";
    var elo_rating='';
    var elo_rank='';
    var ychoices=["Time Span", "Last 52", "Career", "2025", "2024"];
var tchoices=["Event", "All", "Guadalajara 125", "Monterrey"];
var cchoices=["vs Country", "All", "CAN", "SRB", "SVK", "UKR"];
var rchoices=["as Rank", "All"];
var ochoices=["Natalija Stevanovic", "Kayla Cross", "Kateryna Bondarenko", "Anna Karolina Schmiedlova"];
var tdates=["20240819", "20240902", "20250818"];
var vranks=["87", "256", "281", "325"];
playernews = [];
var upcoming = "";
var matchmx = [["20250818", "Monterrey", "Hard", "P", "L", "776", "", "WC", "Q1", "6-3 6-3", "3", "Kayla Cross", "256", "6", "", "L", "20050321", "", "CAN", "0", "83", "1", "7", "57", "30", "16", "13", "9", "0", "4", "12", "8", "67", "35", "27", "15", "9", "4", "5", "", "", "", "", "2025-1039-260"],
          ["20240902", "Guadalajara 125", "Hard", "C", "L", "924", "", "WC", "R32", "4-6 6-2 6-0", "3", "Anna Karolina Schmiedlova", "87", "1", "", "R", "19940913", "176", "SVK", "0", "120", "0", "6", "69", "38", "18", "11", "12", "2", "10", "2", "3", "87", "62", "40", "9", "12", "9", "13", "", "", "", "", "2024-2098-285"],
          ["20240819", "Monterrey", "Hard", "P", "L", "1203", "", "WC", "Q2", "6-2 6-1", "3", "Kateryna Bondarenko", "325", "", "", "R", "19860808", "175", "UKR", "0", "58", "1", "2", "37", "25", "14", "3", "7", "1", "5", "2", "2", "43", "24", "20", "14", "8", "2", "2", "", "", "", "", "2024-1039-268"],
          ["20240819", "Monterrey", "Hard", "P", "W", "1203", "", "WC", "Q1", "6-4 4-0 RET", "3", "Natalija Stevanovic", "281", "7", "", "R", "19940725", "", "SRB", "0", "95", "3", "2", "48", "28", "19", "11", "7", "2", "3", "0", "5", "53", "32", "18", "6", "7", "1", "5", "", "", "", "", "2024-1039-262"]
          ];
