
    var fullname = 'Evialina Laskevich';
    var lastname = 'Laskevich';
    var currentrank=725;
    var peakrank=319;
    var peakfirst=20241216;
    var peaklast=20241230;
    var dob=20041110;
    
    var hand='U';
    var backhand='';
    var country='BLR';
    var shortlist=16;
    var careerjs=1;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100312829';
    var wta_id='';
    var fc_id='';
    var wiki_id='';
    var blast_link='';
    var more_link='';
    var death_date="";
    var dob_approx="";
    var elo_rating='';
    var elo_rank='';
    var ychoices=["Time Span", "Last 52", "Career", "2026", "2025", "2024", "2023", "2022", "2021", "2019"];
var tchoices=["Event", "All", "Porto 125", "W100 Dubai", "W100 Edmond OK", "W100 Figueira da Foz", "W100 Macon GA", "W15 Antalya", "W15 Gonesse", "W15 Kursumlijska Banja", "W15 Le Havre", "W15 Monastir", "W15 Pescara", "W15 Sharm ElSheikh", "W15 Shymkent", "W15 Villena", "W25 Antalya", "W25 Bistrita", "W25 Brasov", "W25 Darmstadt", "W25 Faro", "W25 Horb", "W25 Kursumlijska Banja", "W25 Limassol", "W25 Loule", "W25 Madrid", "W25 Malmo", "W25 Minsk", "W25 Ortisei", "W25 Otocec", "W25 Trieste", "W25 Vrnjacka Banja", "W35 Huzhou", "W35 Las Vegas NV", "W35 Luzhou", "W35 Monastir", "W35 Qian Daohu", "W35 San Rafael CA", "W35 Sharm ElSheikh", "W40 Oldenzaal", "W50 Fuzhou", "W50 Guiyang", "W50 Lopota", "W50 Montemor-o-Novo", "W50 Porto", "W50 Shenzhen", "W50 Taizhou", "W60 Hechingen", "W60 Vrnjacka Banja", "W75 Altenkirchen", "W75 Leszno", "W75 Porto", "W75 Templeton CA"];
var cchoices=["vs Country", "All", "ARG", "AUS", "AUT", "BEL", "BIH", "BLR", "BRA", "BUL", "CAN", "CHN", "CRO", "CZE", "DEN", "EGY", "ESP", "FRA", "GBR", "GER", "GRE", "HKG", "ISR", "ITA", "JPN", "KAZ", "KOR", "LAT", "MDA", "MEX", "NED", "PER", "POL", "POR", "ROU", "RUS", "SLO", "SRB", "SRI", "SUI", "SVK", "SWE", "THA", "TPE", "UKR", "USA"];
var rchoices=["as Rank", "All"];
var ochoices=["Meiling Wang", "Hong Yi Cody Wong", "Daria Kudashova", "Aoi Ito", "Anastasia Gasanova", "Alexandra Shubladze", "Nicole Gadient", "Diana Marcinkevica", "Adithya Karunaratne", "Zhibek Kulambayeva", "Yufei Ren", "Yu Yun Li", "Ying Zhang", "Yidi Yang", "Xiaodi You", "Wushuang Zheng", "Vivian Wolff", "Victoria Rodriguez", "Valeria Savinykh", "Tyra Caterina Grant", "Thasaporn Naklo", "Tessa Johanna Brockmann", "Tereza Valentova", "Tamara Korpatsch", "Suana Tucakovic", "Sofia Costoulas", "Sijia Wei", "Sarah Beth Grey", "Ruirui Zou", "Ruien Zhang", "Radka Zelnickova", "Noelia Bouzo Zanotti", "Noa Liauw A Fong", "Mingge Xu", "Michaela Laki", "Mary Stoiana", "Mariam Atia", "Maria Garcia", "Marcelina Podlinska", "Luana Plaza", "Lizette Cabrera", "Lina Glushko", "Kylie Mckenzie", "Kristiana Sidorova", "Kira Pavlova", "Katrina Scott", "Johanne Christine Svendsen", "Johanna Silva", "Jing Jing Lu", "Jia Jing Lu", "Isabelle Boulais", "Helena Buchwald", "Harmony Tan", "Gabriela Andrea Knutson", "Franziska Sziedat", "Francisca Jorge", "Ellie Schoppe", "Elena Pridankina", "Elena Milovanovic", "Ekaterina Yashina", "Ekaterina Shalimova", "Destanee Aiava", "Daria Snigur", "Dana Guzman", "Dalila Spiteri", "Chia Yi Tsao", "Boyoung Jeong", "Aruzhan Sagandikova", "Arlinda Rushiti", "Angelina Voloshchuk", "Amandine Hesse", "Aliona Falei", "Ziva Falkner", "Viktoria Morvayova", "Tina Nadine Smith", "Tiffany William", "Sina Herrmann", "Sarafina Hansen", "Polina Iatcenko", "Pia Praefke", "Nina Alibalic", "Natalija Senic", "Michele Adamczewska", "Matilda Mutavdzic", "Masa Tanaskovic", "Mara Guth", "Maja Radenkovic", "Lucia Peyre", "Leonie Kung", "Lavinia Tanasie", "Karolina Kozakova", "Jovana Grujic", "Jessie Aney", "Jessica Bouzas Maneiro", "Jessica Bertoldo", "Iva Sepa", "Georgia Kalamaris", "Georgia Andreea Craciun", "Fatma Idrizovic", "Fabienne Gettwart", "Elena Korokozidi", "Ela Platenikova", "Dimitra Pavlou", "Diana Martynov", "Claudia Hoste Ferrer", "Antonia Ruzic", "Andreea Prisacariu", "Anastasiia Gureva", "Anastasia Sukhotina", "Yuliya Hatouka", "Vlada Koval", "Viktoriia Dema", "Tatiana Pieri", "Silvia Ambrosio", "Sandra Samir", "Rosa Vicens Mas", "Raquel Gonzalez Vilar", "Oana Georgeta Simion", "Mila Masic", "Mia Ristic", "Meta Marenk", "Melania Delai", "Martina Spigarelli", "Marie Mettraux", "Maria Mikhailova", "Manca Pislak", "Lilli Tagger", "Katyarina Paulenka", "Katarina Kuzmova", "Jennifer Ruggeri", "Jana Kolodynska", "Iryna Shymanovich", "Inez Maria Kotlikova", "Gozal Ainitdinova", "Gaia Squarcialupi", "Funa Kozaki", "Eunhye Lee", "Emily Seibold", "Ekaterina Makarova", "Ekaterina Kazionova", "Dia Evtimova", "Dea Herdzelas", "Darya Shauha", "Daria Lodikova", "Cristina Dinu", "Chao Yi Wang", "Bojana Klincov", "Ashley Lahey", "Anja Wildgruber", "Anhzelika Isaeva", "Angelina Mihajlovic", "Alina Silich", "Alice Gillan", "Alexandra Vasilyeva", "Alexandra Perper", "Alexandra Melnikova"];
var tdates=["20190603", "20191111", "20210208", "20210405", "20210412", "20220207", "20220228", "20220307", "20220509", "20220801", "20220808", "20220815", "20220829", "20220919", "20220926", "20221121", "20230130", "20230206", "20230313", "20230320", "20230417", "20230424", "20230501", "20230508", "20230515", "20230605", "20230717", "20230724", "20230731", "20230814", "20230821", "20230828", "20231016", "20231023", "20231120", "20240129", "20240205", "20240318", "20240325", "20240408", "20240415", "20240422", "20240429", "20240527", "20240715", "20240722", "20240909", "20240916", "20241014", "20241021", "20241202", "20250127", "20250203", "20250210", "20250609", "20250616", "20250707", "20250714", "20250922", "20250929", "20251006", "20251013", "20260216"];
var vranks=["125", "157", "177", "186", "195", "204", "205", "207", "214", "243", "254", "262", "264", "269", "280", "281", "282", "298", "299", "302", "306", "310", "319", "332", "339", "340", "344", "345", "348", "356", "363", "364", "365", "366", "372", "373", "384", "386", "391", "415", "419", "421", "425", "431", "444", "445", "458", "469", "472", "478", "488", "489", "496", "497", "514", "515", "529", "538", "541", "544", "547", "552", "565", "573", "574", "577", "581", "585", "593", "596", "600", "616", "626", "636", "646", "647", "648", "650", "660", "663", "665", "666", "670", "674", "700", "702", "714", "715", "721", "734", "748", "760", "762", "767", "778", "809", "818", "824", "838", "865", "866", "883", "885", "893", "894", "899", "906", "913", "915", "945", "953", "965", "968", "970", "990", "995", "1025", "1032", "1038", "1154", "1157", "1159", "1166", "1170", "1177", "1192", "1195", "1202", "1213", "1237", "1267", "1278", "1289", "1362", "1404"];
playernews = [];
var upcoming = "";
var matchmx = [["20250127", "W50 Porto", "Hard", "50", "L", "322", "", "", "R32", "6-2 6-1", "3", "Tyra Caterina Grant", "488", "", "", "R", "20080312", "", "ITA", "0", "62", "0", "3", "51", "39", "18", "5", "7", "7", "12", "1", "3", "48", "35", "29", "5", "8", "5", "6", "", "", "", "", "2025-W-ITF-POR-2025-002-103"],
          ["20250203", "W75 Leszno", "Hard", "75", "L", "323", "", "", "R32", "7-5 3-6 6-3", "3", "Amandine Hesse", "280", "", "", "R", "19930116", "164", "FRA", "0", "143", "2", "1", "112", "86", "44", "11", "15", "10", "18", "3", "11", "90", "41", "30", "16", "15", "4", "11", "", "", "", "", "2025-W-ITF-POL-2025-001-107"],
          ["20250210", "W75 Altenkirchen", "Carpet", "75", "L", "325", "", "", "R32", "7-6(6) 5-3 RET", "3", "Tamara Korpatsch", "186", "", "", "R", "19950512", "170", "GER", "0", "117", "0", "1", "74", "54", "27", "7", "11", "4", "11", "1", "6", "65", "31", "19", "13", "10", "2", "8", "", "", "", "", "2025-W-ITF-GER-2025-001-104"],
          ["20250609", "W35 Luzhou", "Hard", "35", "L", "482", "", "", "R16", "6-4 6-4", "3", "Yidi Yang", "421", "", "", "U", "19991221", "", "CHN", "0", "116", "1", "0", "64", "51", "27", "8", "10", "4", "8", "1", "5", "78", "44", "29", "19", "10", "13", "15", "", "", "", "", "2025-W-ITF-CHN-2025-012-207"],
          ["20250609", "W35 Luzhou", "Hard", "35", "W", "482", "", "", "R32", "7-6(4) 6-2", "3", "Hong Yi Cody Wong", "364", "", "", "U", "20020314", "", "HKG", "0", "98", "1", "1", "68", "48", "30", "13", "10", "4", "7", "2", "3", "70", "45", "26", "11", "10", "6", "11", "", "", "", "", "2025-W-ITF-CHN-2025-012-113"],
          ["20250616", "W50 Taizhou", "Hard", "50", "L", "486", "", "", "R32", "6-2 6-3", "3", "Meiling Wang", "445", "", "", "U", "20000222", "", "CHN", "0", "70", "0", "2", "53", "37", "19", "6", "8", "2", "7", "3", "5", "59", "41", "29", "6", "9", "2", "4", "", "20250616-W-ITF_Taizhou-R32-Meiling_Wang-Evialina_Laskevich", "", "", "2025-W-ITF-CHN-2025-016-102"],
          ["20250707", "W35 Monastir", "Hard", "35", "L", "470", "", "", "R32", "3-6 6-4 6-0", "3", "Anastasia Gasanova", "264", "", "", "R", "19990515", "", "RUS", "0", "170", "0", "2", "77", "66", "27", "4", "13", "3", "13", "0", "11", "77", "45", "24", "13", "12", "2", "9", "", "", "", "", "2025-W-ITF-TUN-2025-029-116"],
          ["20250714", "Porto 125", "Hard", "C", "L", "470", "", "", "Q1", "6-4 7-6(4)", "3", "Aliona Falei", "306", "7", "", "U", "20040329", "", "BLR", "0", "115", "0", "1", "70", "51", "24", "9", "11", "3", "9", "2", "11", "70", "45", "30", "9", "11", "4", "9", "", "", "", "", "2025-1135-264"],
          ["20250922", "W75 Templeton CA", "Hard", "75", "L", "665", "", "", "R32", "6-4 7-6(3)", "3", "Katrina Scott", "573", "", "", "R", "20040611", "180", "USA", "0", "129", "0", "1", "72", "55", "27", "6", "11", "3", "9", "2", "1", "73", "54", "30", "7", "11", "0", "5", "", "", "", "", "2025-W-ITF-USA-2025-042-114"],
          ["20250929", "W35 San Rafael CA", "Hard", "35", "L", "665", "", "", "R16", "6-2 6-1", "3", "Johanne Christine Svendsen", "", "", "", "R", "20040515", "", "DEN", "0", "68", "0", "1", "37", "28", "13", "1", "7", "3", "8", "1", "1", "43", "28", "23", "9", "8", "0", "1", "", "", "", "", "2025-W-ITF-USA-2025-041-205"],
          ["20250929", "W35 San Rafael CA", "Hard", "35", "W", "665", "", "", "R32", "4-6 6-4 7-6(4)", "3", "Victoria Rodriguez", "366", "", "", "U", "19950422", "170", "MEX", "0", "215", "0", "0", "112", "79", "45", "16", "16", "12", "19", "0", "0", "131", "104", "53", "13", "16", "17", "24", "", "", "", "", "2025-W-ITF-USA-2025-041-109"],
          ["20251006", "W100 Edmond OK", "Hard", "100", "L", "650", "", "", "R32", "6-3 6-3", "3", "Mary Stoiana", "302", "", "", "U", "20030506", "", "USA", "0", "94", "1", "1", "62", "39", "22", "11", "9", "2", "6", "0", "2", "57", "40", "27", "10", "9", "1", "2", "", "", "", "", "2025-W-ITF-USA-2025-045-106"],
          ["20251013", "W100 Macon GA", "Hard", "100", "L", "611", "", "", "R16", "6-3 6-4", "3", "Anastasia Gasanova", "207", "", "", "R", "19990515", "", "RUS", "0", "107", "1", "3", "63", "47", "18", "9", "10", "2", "9", "0", "3", "48", "38", "20", "6", "9", "2", "6", "", "", "", "", "2025-W-ITF-USA-2025-047-204"],
          ["20251013", "W100 Macon GA", "Hard", "100", "W", "611", "", "", "R32", "6-4 1-6 7-6(5)", "3", "Ellie Schoppe", "593", "", "", "U", "20011118", "", "USA", "0", "168", "0", "5", "91", "70", "41", "7", "14", "7", "14", "0", "9", "105", "43", "21", "31", "15", "5", "11", "", "", "", "", "2025-W-ITF-USA-2025-047-107"],
          ["20260216", "W35 Las Vegas NV", "Hard", "35", "L", "750", "", "", "R16", "7-6(0) 6-3", "3", "Vivian Wolff", "319", "", "", "R", "19981008", "", "GER", "0", "133", "0", "4", "71", "48", "20", "12", "11", "4", "10", "0", "5", "78", "56", "34", "8", "10", "9", "13", "", "", "", "", "2026-W-ITF-USA-2026-006-201"],
          ["20260216", "W35 Las Vegas NV", "Hard", "35", "W", "750", "", "", "R32", "6-3 6-4", "3", "Dana Guzman", "581", "", "", "U", "20030322", "", "PER", "0", "109", "0", "2", "55", "45", "26", "5", "9", "2", "5", "0", "0", "55", "47", "21", "4", "10", "1", "7", "", "", "", "", "2026-W-ITF-USA-2026-006-102"]
          ];
