
    var fullname = 'Valentin Royer';
    var lastname = 'Royer';
    var currentrank=1658;
    var peakrank=1639;
    var peakfirst=20181015;
    var peaklast=20181015;
    var dob=20010529;
    
    var hand='U';
    var backhand='';
    var country='FRA';
    var shortlist=2;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='';
    var atp_id='';
    var dc_id='';
    var wiki_id='';
    var ychoices=["Time Span", "Last 52", "Career", "2018"];
var tchoices=["Event", "All"];
var cchoices=["vs Country", "All", "BIH", "FRA"];
var rchoices=["as Rank", "All"];
var ochoices=["Elmar Ejupovic", "Antoine Cornut Chauvinc"];
var tdates=["20181001"];
var vranks=["417", "532"];
playernews = [];
var upcoming = "";
var matchmx = [["20181001", "France F20", "Hard", "S", "L", "UNR", "", "Q", "R16", "6-3 7-5", "3", "Antoine Cornut Chauvinc", "532", "", "", "U", "20000707", "", "FRA", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-FRA-20A-2018-019", "", "2", "2"],
          ["20181001", "France F20", "Hard", "S", "W", "UNR", "", "Q", "R32", "4-6 6-4 7-6(4)", "3", "Elmar Ejupovic", "417", "", "", "R", "19930201", "", "BIH", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-FRA-20A-2018-005", "", "1", "1"]
          ];
