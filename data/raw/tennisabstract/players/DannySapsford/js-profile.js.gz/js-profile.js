
    var fullname = 'Danny Sapsford';
    var lastname = 'Sapsford';
    var currentrank="";
    var peakrank=170;
    var peakfirst=19960415;
    var peaklast=19960415;
    var dob=19690403;
    var ht=173;
    var hand='R';
    var country='GBR';
    var shortlist=11;
    var careerjs=1;
    var active=0;
    var lastdate=19990621;
    var ychoices=["Time Span", "Last 52", "Career", "1999", "1998", "1997", "1996", "1995", "1994", "1992", "1991", "1990"];
var tchoices=["Event", "All", "Davis Cup", "Adelaide CH", "Aruba CH", "Azores CH", "Beijing", "Bombay CH", "Bordeaux", "Bournemouth", "Bristol CH", "Bromma CH", "Bronx CH", "Copenhagen", "Dubai", "Dublin CH", "Edinburgh CH", "Eilat CH", "Guam CH", "Heilbronn CH", "Hong Kong", "Hong Kong CH", "Istanbul CH", "Jakarta CH", "Jerusalem CH", "Kuala Lumpur", "Lyon", "Manchester CH", "Neumunster CH", "New Delhi", "Newcastle CH", "Nottingham", "Olbia CH", "Perth CH", "Portoroz CH", "Queen's Club", "Reunion Island CH", "Rogaska CH", "Rotterdam", "Segovia CH", "Shanghai", "Singapore CH", "St. Petersburg", "Surbiton CH", "Telford CH", "Tokyo", "Tokyo Indoor", "Tokyo Outdoor", "US Open", "Wimbledon"];
var cchoices=["vs Country", "All", "ARG", "AUS", "AUT", "BEL", "BUL", "CAN", "CZE", "DEN", "ESP", "FRA", "GBR", "GER", "ISR", "ITA", "JPN", "MEX", "NED", "POL", "POR", "ROU", "RSA", "RUS", "SVK", "SWE", "TPE", "USA", "UZB", "VEN", "ZIM"];
var rchoices=["as Rank", "All"];
var ochoices=["Chris Wilkinson", "Mark Petchey", "Eyal Erlich", "Yevgeny Kafelnikov", "Tim Henman", "Stefano Pescosolido", "Kevin Ullyett", "Gianluca Pozzi", "David Nainkin", "Byron Black", "Arne Thoms", "Alejandro Hernandez", "Yu Hui Lien", "Wojtek Kowalski", "Wayne Ferreira", "Wayne Arthurs", "Wally Masur", "Tomas Nydahl", "Tom Spinks", "Todd Woodbridge", "Todd Martin", "Thomas Johansson", "Stefan Edberg", "Satoshi Iwabuchi", "Peter Tramacchi", "Pete Sampras", "Paul Kilderry", "Patrik Langvardt", "Patrik Fredriksson", "Oscar Ortiz", "Oscar Burrieza", "Orlin Stanoytchev", "Olivier Delaitre", "Oleg Ogorodov", "Nuno Marques", "Noam Behr", "Nicolas Pereira", "Nicklas Kroon", "Neil Borwick", "Miles Maclagan", "Michael Joyce", "Michael Chang", "Martin Zumpft", "Martin Lee", "Martin Laurendeau", "Mark Kaplan", "Mariano Puerta", "Lars Rehmann", "Lars Jonsson", "Lars Burgsmuller", "Lars Anders Wahlgren", "Kenneth Carlsen", "Kelly Jones", "Julian Alonso", "Juan Albert Viloca Puig", "Jonathan Canter", "Jiri Novak", "Jim Pugh", "Jerome Golmard", "Jeff Tarango", "Jean Philippe Fleurian", "Jean Baptiste Perlant", "Jan Siemerink", "Jan Kroslak", "James Sekulov", "Jacobo Diaz", "Ignacio Truyol", "Hendrik Dreekmann", "Guillaume Raoux", "Greg Rusedski", "Grant Doyle", "George Cosac", "Galo Blanco", "Frederik Fetterlein", "Frederic Vitoux", "Francisco Clavet", "Florin Segarceanu", "Fernon Wibier", "Emilio Sanchez", "Eduardo Medica", "Doug Flach", "Denis Van Uffelen", "Daniele Musa", "Daniel Nestor", "Clinton Marsh", "Christo Van Rensburg", "Christian Vinck", "Christian Saceanu", "Chris Haggard", "Carsten Arriens", "Bryan Shelton", "Boris Becker", "Boaz Merenstein", "Ben Ellwood", "Andrew Richardson", "Andrew Ilie", "Andrei Olhovskiy", "Andrei Cherkasov", "Amos Mansdorf", "Alex Antonitsch", "Alberto Berasategui", "Albert Costa"];
var matchmx = [["19980413", "Tokyo", "Hard", "A", "L", "231", "", "", "R64", "7-5 0-1 RET", "3", "Satoshi Iwabuchi", "600", "", "WC", "L", "19751007", "175", "JPN", "0", "15", "1", "0", "43", "31", "19", "7", "7", "0", "2", "0", "4", "43", "26", "17", "10", "7", "2", "3"],
          ["19980601", "Surbiton CH", "Grass", "C", "L", "UNR", "", "WC", "R32", "3-6 6-1 6-2", "3", "Alejandro Hernandez", "UNR", "", "", "R", "19771001", "180", "MEX", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""],
          ["19980622", "Wimbledon", "Grass", "G", "L", "247", "", "WC", "R128", "7-6(6) 6-2 6-3", "5", "Jerome Golmard", "86", "", "", "L", "19730909", "188", "FRA", "0", "106", "7", "3", "96", "48", "39", "23", "14", "3", "6", "8", "2", "99", "62", "52", "24", "15", "1", "1"],
          ["19980706", "Bristol CH", "Grass", "C", "L", "294", "", "", "R16", "6-3 6-2", "3", "Denis Van Uffelen", "393", "", "Q", "R", "19710705", "", "BEL", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""],
          ["19980706", "Bristol CH", "Grass", "C", "W", "294", "", "", "R32", "7-5 3-6 7-5", "3", "Chris Wilkinson", "152", "1", "", "R", "19700105", "180", "GBR", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""],
          ["19980713", "Manchester CH", "Grass", "C", "L", "282", "", "", "R32", "7-6 6-3", "3", "Oscar Burrieza", "151", "1", "", "R", "19750722", "170", "ESP", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""],
          ["19980720", "Newcastle CH", "Clay", "C", "L", "316", "", "WC", "R32", "6-4 7-5", "3", "Eduardo Medica", "202", "", "Q", "R", "19760210", "180", "ARG", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""],
          ["19981019", "Lyon", "Carpet", "A", "L", "596", "", "Q", "R32", "6-2 3-6 6-4", "3", "Wayne Ferreira", "29", "", "", "R", "19710915", "185", "RSA", "0", "105", "3", "3", "90", "46", "31", "23", "14", "6", "9", "6", "6", "96", "51", "38", "23", "13", "3", "4"],
          ["19990621", "Wimbledon", "Grass", "G", "L", "595", "", "Q", "R32", "6-3 6-4 7-5", "5", "Pete Sampras", "1", "1", "", "R", "19710812", "185", "USA", "0", "103", "1", "3", "99", "46", "31", "27", "15", "6", "9", "23", "2", "105", "78", "74", "13", "16", "0", "0"],
          ["19990621", "Wimbledon", "Grass", "G", "W", "595", "", "Q", "R128", "6-2 6-2 7-5", "5", "Julian Alonso", "176", "", "", "R", "19770802", "185", "ESP", "0", "90", "5", "2", "84", "61", "50", "12", "14", "2", "2", "9", "8", "110", "57", "43", "20", "14", "8", "13"],
          ["19990621", "Wimbledon", "Grass", "G", "W", "595", "", "Q", "R64", "6-3 3-6 6-4 6-2", "5", "Galo Blanco", "101", "", "", "R", "19761008", "173", "ESP", "0", "160", "8", "2", "117", "56", "44", "31", "18", "5", "9", "13", "9", "178", "77", "56", "41", "18", "15", "22"]
          ];
