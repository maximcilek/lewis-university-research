
    var fullname = 'Rinky Hijikata';
    var lastname = 'Hijikata';
    var currentrank=1745;
    var peakrank=1673;
    var peakfirst=20180430;
    var peaklast=20180430;
    var dob=20010223;
    
    var hand='U';
    var backhand='';
    var country='AUS';
    var shortlist=3;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs=1405;
    var peak_dubs=1382;
    var peakfirst_dubs=20180806;
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100236257';
    var atp_id='';
    var dc_id='';
    var wiki_id='';
    var ychoices=["Time Span", "Last 52", "Career", "2018"];
var tchoices=["Event", "All"];
var cchoices=["vs Country", "All", "AUS"];
var rchoices=["as Rank", "All"];
var ochoices=["Scott Puodziunas", "Max Purcell", "Matthew Dellavedova"];
var tdates=["20180319", "20180326"];
var vranks=["271", "925", "1393"];
playernews = [];
var upcoming = "";
var matchmx = [["20180319", "Australia F3", "Clay", "S", "L", "UNR", "", "", "R32", "2-6 6-3 6-3", "3", "Matthew Dellavedova", "1393", "", "", "U", "20000530", "", "AUS", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-AUS-03A-2018-011", "", "1", "1"],
          ["20180326", "Australia F4", "Clay", "S", "L", "UNR", "", "", "R16", "6-3 6-3", "3", "Max Purcell", "271", "3", "", "U", "19980403", "", "AUS", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "0", "2018-M-FU-AUS-04A-2018-022", "", "2", "2"],
          ["20180326", "Australia F4", "Clay", "S", "W", "UNR", "", "", "R32", "6-7(3) 7-6(3) 6-2", "3", "Scott Puodziunas", "925", "", "", "U", "19891109", "", "AUS", "1", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-AUS-04A-2018-011", "", "1", "1"]
          ];
