
    var fullname = 'Federico Arnaboldi';
    var lastname = 'Arnaboldi';
    var currentrank="UNR";
    var peakrank="UNR";
    var peakfirst="";
    var peaklast="";
    var dob=20000618;
    
    var hand='U';
    var backhand='';
    var country='ITA';
    var shortlist=3;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100202773';
    var atp_id='';
    var dc_id='';
    var wiki_id='';
    var ychoices=["Time Span", "Last 52", "Career", "2018", "2016"];
var tchoices=["Event", "All", "Como CH", "Como Challenger"];
var cchoices=["vs Country", "All", "BRA", "ITA"];
var rchoices=["as Rank", "All"];
var ochoices=["Wilson Leite", "Julian Ocleppo", "Andrea Vavassori"];
var tdates=["20160829", "20180625", "20180827"];
var vranks=["638", "751", "1133"];
playernews = [];
var upcoming = "";
var matchmx = [["20160829", "Como CH", "Clay", "C", "L", "", "", "WC", "Q1", "5-7 7-6(4) 6-2", "3", "Andrea Vavassori", "638", "", "WC", "U", "21.3196440794", "", "ITA", "0", "141", "3", "9", "105", "51", "36", "18", "16", "11", "19", "11", "9", "115", "57", "38", "28", "16", "10", "17", "", "", "", "", "2016-3473-255", "", "", ""],
          ["20180625", "Italy F16", "Clay", "S", "L", "UNR", "", "Q", "R32", "6-3 6-7(5) 6-0", "3", "Wilson Leite", "751", "", "", "R", "19911106", "178", "BRA", "1", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-ITA-16A-2018-003", "", "1", "1"],
          ["20180827", "Como Challenger", "Clay", "C", "L", "UNR", "", "WC", "Q1", "6-2 2-6 7-5", "3", "Julian Ocleppo", "1133", "", "WC", "R", "19970801", "", "ITA", "", "120", "7", "10", "99", "50", "35", "24", "14", "7", "11", "2", "4", "80", "51", "34", "17", "14", "1", "4", "2", "", "", "", "2018-3473-228", "", "", ""]
          ];
