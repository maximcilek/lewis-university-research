
    var fullname = 'Daniel De Jonge';
    var lastname = 'De Jonge';
    var currentrank=1553;
    var peakrank=1539;
    var peakfirst=20181112;
    var peaklast=20181112;
    var dob=19990817;
    
    var hand='U';
    var backhand='';
    var country='NED';
    var shortlist=6;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100248153';
    var atp_id='';
    var dc_id='';
    var wiki_id='';
    var ychoices=["Time Span", "Last 52", "Career", "2018"];
var tchoices=["Event", "All"];
var cchoices=["vs Country", "All", "ARG", "FRA", "ITA", "NED", "SUI", "USA"];
var rchoices=["as Rank", "All"];
var ochoices=["Yann Marti", "Ronan Joncour", "Luca Prevosto", "Juan Bautista Otegui", "Jeremy Sonkin", "Botic Van De Zandschulp"];
var tdates=["20180618", "20180702", "20180827", "20181029"];
var vranks=["516", "787", "952", "953", "1053", "1172"];
playernews = [];
var upcoming = "";
var matchmx = [["20180618", "Belgium F1", "Clay", "S", "L", "UNR", "", "", "R32", "6-2 2-6 6-1", "3", "Yann Marti", "1053", "", "Q", "R", "19880607", "173", "SUI", "1", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-BEL-01A-2018-014", "", "1", "1"],
          ["20180702", "Netherlands F2", "Clay", "S", "L", "UNR", "", "", "R32", "7-5 7-5", "3", "Botic Van De Zandschulp", "516", "5", "", "U", "19951004", "", "NED", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-NED-02A-2018-008", "", "1", "1"],
          ["20180827", "Belgium F10", "Clay", "S", "L", "UNR", "", "Q", "R32", "6-3 5-7 6-4", "3", "Juan Bautista Otegui", "953", "", "", "R", "19990223", "", "ARG", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-BEL-10A-2018-010", "", "1", "1"],
          ["20181029", "Tunisia F38", "Hard", "S", "L", "UNR", "", "LL", "QF", "6-1 6-4", "3", "Ronan Joncour", "1172", "", "", "L", "19970127", "", "FRA", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-TUN-38A-2018-027", "", "3", "3"],
          ["20181029", "Tunisia F38", "Hard", "S", "W", "UNR", "", "LL", "R16", "6-1 6-3", "3", "Jeremy Sonkin", "952", "", "", "U", "19850711", "", "USA", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-TUN-38A-2018-021", "", "2", "2"],
          ["20181029", "Tunisia F38", "Hard", "S", "W", "UNR", "", "LL", "R32", "6-4 4-6 7-6(4)", "3", "Luca Prevosto", "787", "", "", "R", "19980909", "", "ITA", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-TUN-38A-2018-009", "", "1", "1"]
          ];
