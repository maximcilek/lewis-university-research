
    var fullname = 'Fitriadi M Rifqi';
    var lastname = 'M Rifqi';
    var currentrank=1533;
    var peakrank=1306;
    var peakfirst=20180226;
    var peaklast=20180226;
    var dob=19990123;
    
    var hand='U';
    var backhand='';
    var country='INA';
    var shortlist=9;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100266671';
    var atp_id='';
    var dc_id='';
    var wiki_id='';
    var ychoices=["Time Span", "Last 52", "Career", "2018", "2017", "2016"];
var tchoices=["Event", "All"];
var cchoices=["vs Country", "All", "AUS", "CAN", "FRA", "GBR", "IND", "JPN", "SUI", "TPE", "USA"];
var rchoices=["as Rank", "All"];
var ochoices=["Shintaro Imai", "Robert Quentin", "Michael Look", "Jui Chen Hung", "Jonathan Gray", "Jayesh Pungliya", "Arnav Mohanty", "Aria Harajchi", "Alejandro Tabilo"];
var tdates=["20161212", "20170403", "20171120", "20180723", "20180806"];
var vranks=["375", "603", "803", "944", "997", "1060", "1101", "1120"];
playernews = [];
var upcoming = "";
var matchmx = [["20161212", "Indonesia F6", "Hard", "S", "L", "", "", "WC", "R32", "6-1 6-2", "3", "Jui Chen Hung", "1120", "", "", "R", "26.7843942505", "", "TPE", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2016-M-FU-INA-06A-2016-011", "", "1", "1"],
          ["20170403", "Indonesia F5", "Hard", "S", "L", "", "", "WC", "QF", "6-0 6-0", "3", "Jonathan Gray", "1101", "", "Q", "U", "19.9835728953", "", "GBR", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "1", "2017-M-FU-INA-05A-2017-027", "", "3", "3"],
          ["20170403", "Indonesia F5", "Hard", "S", "W", "", "", "WC", "R16", "6-4 6-2", "3", "Alejandro Tabilo", "603", "7", "", "L", "19.8357289528", "", "CAN", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "0", "2017-M-FU-INA-05A-2017-021", "", "2", "2"],
          ["20170403", "Indonesia F5", "Hard", "S", "W", "", "", "WC", "R32", "6-2 6-4", "3", "Aria Harajchi", "997", "", "", "U", "21.015742642", "", "SUI", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2017-M-FU-INA-05A-2017-010", "", "1", "1"],
          ["20171120", "Indonesia F7", "Hard", "S", "L", "1438", "", "WC", "R16", "6-2 6-3", "3", "Shintaro Imai", "375", "3", "", "U", "24.2026009582", "", "JPN", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2017-M-FU-INA-07B-2017-022", "", "2", "2"],
          ["20171120", "Indonesia F7", "Hard", "S", "W", "1438", "", "WC", "R32", "6-4 6-3", "3", "Arnav Mohanty", "", "", "", "U", "23.227926078", "", "USA", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2017-M-FU-INA-07B-2017-011", "", "1", "1"],
          ["20180723", "Indonesia F1", "Hard", "S", "L", "1604", "", "WC", "R16", "6-1 6-1", "3", "Robert Quentin", "944", "", "", "R", "19940824", "", "FRA", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-INA-01B-2018-020", "", "2", "2"],
          ["20180723", "Indonesia F1", "Hard", "S", "W", "1604", "", "WC", "R32", "6-7(5) 6-3 6-4", "3", "Jayesh Pungliya", "1060", "", "", "U", "19960922", "", "IND", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-INA-01B-2018-007", "", "1", "1"],
          ["20180806", "Indonesia F3", "Hard", "S", "L", "1450", "", "WC", "R32", "7-5 6-3", "3", "Michael Look", "803", "", "", "R", "19871124", "", "AUS", "1", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-INA-02A-2018-007", "", "1", "1"]
          ];
