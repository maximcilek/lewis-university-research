
    var fullname = 'Zoe Hives';
    var lastname = 'Hives';
    var currentrank=954;
    var peakrank=140;
    var peakfirst=20191014;
    var peaklast=20191014;
    var dob=19961024;
    
    var hand='R';
    var backhand='';
    var country='AUS';
    var shortlist=3;
    var careerjs=1;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank=634;
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100161851';
    var wta_id='20124/title/zoe-hives';
    var fc_id='';
    var wiki_id='';
    var blast_link='';
    var more_link='';
    var death_date="";
    var dob_approx="";
    var ychoices=["Time Span", "Last 52", "Career", "2023", "2022", "2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012"];
var tchoices=["Event", "All", "Australian Open", "Wimbledon", "US Open", "Bogota", "Brisbane", "Contrexeville 125", "Hiroshima", "Hobart", "Rabat", "Sydney", "United Cup", "W100 Grodzisk Mazowiecki", "W100 Ilkley", "W25 Bendigo", "W25 Canberra", "W25 Chiang Rai", "W25 Essen", "W25 Nottingham", "W60 Ashland KY", "W60 Berkeley CA", "W60 Brescia", "W60 Burnie", "W60 Canberra", "W60 Concord MA", "W60 Darwin", "W60 La Bisbal D'Emporda", "W60 Landisville PA", "W60 Launceston", "W60 Lexington KY", "W60 Madrid", "W60+H Rome", "W80 Charlottesville VA", "W80 Dothan AL", "Baja $25K", "Bangkok $10K", "Bangkok $25K", "Bendigo $60K", "Bendigo 50K", "Brisbane $25K", "Burnie $60K", "Cairns $25K", "Cairns 15K", "Canberra $25K", "Canberra $60K", "Clare 15K", "Darwin $60K", "Dunakeszi $25K", "Essen $25K", "Evansville IN $10K", "Fort Worth TX $10K", "Glen Iris 15K", "Launceston $25K", "Melbourne 15K", "Middelburg $25K", "Mildura 15K", "Mornington $25K", "Mornington 15K", "Penrith $25K", "Perth $25K", "Playford $25K", "Salisbury 10K", "Singapore $25K", "Toowoomba $25K", "Toowoomba 15K", "Torino $25K"];
var cchoices=["vs Country", "All", "AND", "AUS", "AUT", "BEL", "BLR", "BRA", "BUL", "CAN", "CHN", "CRO", "CZE", "ESP", "FRA", "GBR", "GEO", "GER", "GRE", "HUN", "IND", "ISR", "ITA", "JPN", "KAZ", "KOR", "LAT", "NED", "NOR", "POL", "ROU", "RUS", "SAM", "SUI", "SVK", "SWE", "THA", "TPE", "TUR", "UKR", "USA"];
var rchoices=["as Rank", "All"];
var ochoices=["Tammi Patterson", "Priscilla Hon", "Zali Morris", "Ylona Georgiana Ghioroaie", "Xinyun Han", "Victoria Jimenez Kasintseva", "Sowjanya Bavisetti", "Sachia Vickery", "Nikola Bartunkova", "Marta Huqi Gonzalez Encinas", "Maria Sakkari", "Lizette Cabrera", "Lena Rueffer", "Katie Swan", "Jing Jing Lu", "Ji Hee Choi", "Harmony Tan", "Gabriella Taylor", "Gabriela Lee", "Emina Bektas", "Asia Muhammad", "Angelica Blake", "Anchisa Chanta", "Alison Bai", "Alexandra Bozovic", "Zuzana Zlochova", "Yuqi Sheng", "Viktorija Rajicic", "Ulrikke Eikeri", "Patty Schnyder", "Olivia Tjandramulia", "Naiktha Bains", "Mai Minokoshi", "Maddison Inglis", "Kimberly Birrell", "Katy Dunne", "Junri Namigata", "Julia Glushko", "Jaimee Fourlis", "Hiroko Kuwata", "Dabin Kim", "Anastasia Potapova", "Alize Lim", "Abbie Myers", "Yuuki Tanaka", "Yukun Zhang", "Yuki Kristina Chiang", "Ysaline Bonaventure", "Yanina Wickmayer", "Ya Hsuan Lee", "Whitney Osuigwe", "Veronica Miroshnichenko", "Valentini Grammatikopoulou", "Usue Maitane Arconada", "Tereza Smitkova", "Tereza Mrdeza", "Storm Sanders", "Steffi Carruthers", "Stefanie Voegele", "Shuko Aoyama", "Sherazad Reix", "Sesil Karatantcheva", "Sandra Zaniewska", "Sally Peers", "Romy Koelzer", "Robin Anderson", "Reka Zadori", "Rebecca Peterson", "Plobrung Plipuech", "Pia Konig", "Paula Cristina Goncalves", "Olivia Rogowska", "Olga Govortsova", "Nozomi Fujioka", "Nicole Collie", "Naomi Totka", "Nao Hibino", "Nagi Hanatani", "Na Lae Han", "Momoko Kobori", "Miyu Kato", "Miyabi Inoue", "Misaki Doi", "Mina Hodzic", "Miharu Imanishi", "Michaela Honcova", "Mary Ann Balint", "Marta Kostyuk", "Marie Bouzkova", "Maria Mateas", "Mana Ayukawa", "Lourdes Dominguez Lino", "Lesley Pattinama Kerkhove", "Laura Pous Tio", "Kristina N Smith", "Kaylah Mcphee", "Kayla Day", "Katie Boulter", "Kai Lin Zhang", "Julia Grabher", "Julia Goerges", "Johanna Larsson", "Jodie Burrage", "Jessika Ponchet", "Jennifer Elie", "Jaqueline Cristian", "Ivana Popovic", "Isabelle Wallace", "Irina Ramialison", "Haruka Kaji", "Harriet Dart", "Hanna Chang", "Gergana Topalova", "Georgina Garcia Perez", "Frances Altick", "Erika Sema", "Emily Arbuthnott", "Ellie Halbauer", "Ellen Perez", "Elitsa Kostova", "Elena Rybakina", "Ekaterine Gorgodze", "Diana Marcinkevica", "Destanee Aiava", "Deborah Chiesa", "Cori Gauff", "Ching Wen Hsu", "Caroline Garcia", "Caroline Dolehide", "Camilla Scala", "Bunyawi Thamchaiwat", "Bianca Andreescu", "Bethanie Mattek Sands", "Belinda Bencic", "Basak Eraydin", "Barbora Krejcikova", "Ayaka Okuno", "Astra Sharma", "Arina Rodionova", "Anna Danilina", "Anna Blinkova", "Angelique Svinos", "Angelina Gabueva", "Anastasia Evgenyevna Nefedova", "Alexandra Cadantu Ignatik", "Akiko Omae", "Akari Inoue"];
var tdates=["20120910", "20131028", "20140106", "20140331", "20140407", "20141006", "20141013", "20150223", "20150309", "20150323", "20150330", "20150518", "20150525", "20150601", "20150706", "20150713", "20150720", "20150803", "20160111", "20160118", "20170220", "20170320", "20170327", "20170508", "20170605", "20170619", "20170703", "20170710", "20170918", "20170925", "20171002", "20171009", "20171030", "20171106", "20180101", "20180129", "20180205", "20180319", "20180326", "20180604", "20180611", "20180917", "20180924", "20181001", "20181008", "20181022", "20181029", "20181231", "20190107", "20190114", "20190121", "20190128", "20190318", "20190325", "20190408", "20190415", "20190422", "20190429", "20190513", "20190527", "20190603", "20190617", "20190701", "20190715", "20190722", "20190729", "20190805", "20190812", "20190826", "20190909", "20190923", "20220117", "20220207", "20220228", "20220328", "20220530", "20220613", "20220627", "20220704", "20220711", "20220725", "20220801", "20230102", "20230116"];
var vranks=["5", "19", "55", "72", "73", "75", "84", "93", "99", "107", "115", "122", "142", "144", "145", "149", "150", "151", "156", "161", "162", "165", "168", "171", "173", "174", "175", "178", "183", "184", "188", "189", "190", "199", "202", "206", "207", "209", "212", "214", "223", "227", "229", "233", "236", "238", "239", "240", "243", "245", "249", "250", "256", "257", "268", "271", "273", "280", "283", "284", "285", "304", "311", "312", "313", "318", "320", "322", "323", "326", "327", "331", "332", "336", "337", "338", "340", "344", "348", "351", "352", "363", "368", "370", "371", "372", "379", "385", "390", "392", "394", "399", "415", "420", "429", "431", "433", "435", "441", "445", "447", "448", "452", "478", "498", "502", "507", "512", "523", "543", "547", "570", "576", "586", "594", "612", "614", "637", "639", "643", "679", "711", "744", "745", "771", "777", "783", "816", "822", "823", "843", "902", "906", "940", "977", "996", "998", "1024", "1027", "1084", "1141", "1153", "1158", "1167", "1212", "1215", "1451"];
playernews = [];
var upcoming = "";
var matchmx = [["20230102", "United Cup", "Hard", "I", "L", "772", "", "", "RR", "6-4 6-3", "3", "Katie Swan", "145", "", "", "R", "19990324", "170", "GBR", "0", "86", "2", "8", "63", "39", "19", "8", "10", "2", "8", "3", "4", "49", "34", "23", "6", "9", "2", "5", "", "20221229-W-United_Cup-RR-Zoe_Hives-Katie_Swan.html", "", "", "2023-9900-229"],
          ["20230116", "Australian Open", "Hard", "G", "L", "775", "", "", "Q2", "6-1 6-1", "3", "Victoria Jimenez Kasintseva", "184", "", "", "L", "20050809", "", "AND", "0", "63", "0", "5", "45", "27", "13", "6", "7", "2", "7", "1", "2", "38", "21", "17", "12", "7", "2", "2", "", "", "", "", "2023-580-792"],
          ["20230116", "Australian Open", "Hard", "G", "W", "775", "", "", "Q1", "6-2 5-7 6-1", "3", "Harmony Tan", "142", "", "", "R", "19970911", "", "FRA", "0", "133", "4", "6", "98", "58", "39", "17", "14", "6", "9", "3", "6", "86", "56", "37", "11", "13", "6", "12", "", "", "", "", "2023-580-757"]
          ];
