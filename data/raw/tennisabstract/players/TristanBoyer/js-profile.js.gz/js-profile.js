
    var fullname = 'Tristan Boyer';
    var lastname = 'Boyer';
    var currentrank=1912;
    var peakrank=1877;
    var peakfirst=20180924;
    var peaklast=20180924;
    var dob=20010421;
    
    var hand='R';
    var backhand='';
    var country='USA';
    var shortlist=7;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100233989';
    var atp_id='';
    var dc_id='';
    var wiki_id='';
    var ychoices=["Time Span", "Last 52", "Career", "2018", "2017"];
var tchoices=["Event", "All", "Indian Wells Masters"];
var cchoices=["vs Country", "All", "BEL", "BRA", "ITA", "MDA", "USA"];
var rchoices=["as Rank", "All"];
var ochoices=["Zeke Clark", "Ruben Bemelmans", "Orlando Luz", "Mousheg Hovhannisyan", "Marco Bortolotti", "Isaiah Strode", "Alexander Cozbinov"];
var tdates=["20170911", "20180305", "20180312", "20180430", "20180507", "20180723"];
var vranks=["113", "612", "663", "968", "1004", "1165"];
playernews = [];
var upcoming = "";
var matchmx = [["20170911", "USA F30", "Hard", "S", "L", "", "", "Q", "R32", "4-6 6-0 6-3", "3", "Alexander Cozbinov", "", "", "Q", "R", "22.3737166324", "", "MDA", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2017-M-FU-USA-30A-2017-002", "", "1", "1"],
          ["20180305", "Indian Wells Masters", "Hard", "M", "L", "UNR", "", "WC", "Q1", "6-1 7-6(3)", "3", "Ruben Bemelmans", "113", "12", "", "L", "19880114", "", "BEL", "1", "85", "0", "2", "77", "58", "29", "9", "10", "5", "9", "2", "1", "50", "27", "23", "14", "9", "0", "1", "2", "", "", "", "2018-M006-108", "", "", ""],
          ["20180312", "USA F7", "Hard", "S", "L", "UNR", "", "", "R32", "6-2 7-6(0)", "3", "Isaiah Strode", "968", "", "Q", "R", "19970915", "", "USA", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "0", "2018-M-FU-USA-07A-2018-007", "", "1", "1"],
          ["20180430", "Egypt F16", "Clay", "S", "L", "UNR", "", "", "R32", "6-1 4-6 6-1", "3", "Marco Bortolotti", "612", "5", "", "R", "19910121", "", "ITA", "1", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-EGY-16A-2018-004", "", "1", "1"],
          ["20180507", "Egypt F17", "Clay", "S", "L", "UNR", "", "WC", "R32", "4-6 6-0 6-4", "3", "Orlando Luz", "663", "", "", "R", "19980208", "", "BRA", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-EGY-17A-2018-009", "", "1", "1"],
          ["20180723", "USA F20", "Hard", "S", "L", "UNR", "", "", "R16", "7-6(5) 6-2", "3", "Zeke Clark", "1165", "", "", "R", "19980719", "", "USA", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-USA-20A-2018-023", "", "2", "2"],
          ["20180723", "USA F20", "Hard", "S", "W", "UNR", "", "", "R32", "6-2 6-1", "3", "Mousheg Hovhannisyan", "1004", "", "", "U", "19911004", "", "USA", "1", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-USA-20A-2018-014", "", "1", "1"]
          ];
