
    var fullname = 'Peter Doohan';
    var lastname = 'Doohan';
    var currentrank="";
    var peakrank=43;
    var peakfirst=19870803;
    var peaklast=19870803;
    var dob=19610502;
    var ht=190;
    var hand='R';
    var country='AUS';
    var shortlist=2;
    var careerjs=1;
    var active=0;
    var lastdate=19920210;
    var ychoices=["Time Span", "Last 52", "Career", "1992", "1991", "1990", "1989", "1988", "1987", "1986", "1985", "1984", "1983", "1982", "1981", "1980", "1979"];
var tchoices=["Event", "All", "Adelaide", "Auckland", "Australian Open", "Bastad", "Brisbane", "Bristol", "Chicago", "Cincinnati", "Cleveland", "Delray Beach", "Forest Hills", "Fort Myers", "Geneva", "Hilversum", "Indian Wells", "Indianapolis", "Key Biscayne", "La Quinta", "Livingston", "Los Angeles", "Manchester", "Melbourne", "Memphis", "Montreal Toronto", "Newport", "Queen's Club", "Rio De Janeiro", "Roland Garros", "Stratton Mountain", "Sydney Indoor", "Sydney Outdoor", "Tel Aviv", "US Open", "Washington", "Wellington", "Wembley", "Wimbledon"];
var cchoices=["vs Country", "All", "AUS", "AUT", "BRA", "CAN", "CHI", "CRO", "CZE", "FRA", "GBR", "GER", "IND", "ISR", "ITA", "JAM", "JPN", "NED", "NGR", "NZL", "PAR", "RSA", "RUS", "SUI", "SVK", "SWE", "USA", "YUG"];
var rchoices=["as Rank", "All", "Top 50", "Top 100", "Top 200", "51+", "101+", "201+"];
var ochoices=["Brad Drewett", "Brad Gilbert", "Miloslav Mecir", "Boris Becker", "Tim Wilkison", "Steve Shaw", "Mark Edmondson", "Lloyd Bourne", "Leif Shiras", "Kevin Curren", "Jonathan Canter", "John Fitzgerald", "John Alexander", "Jakob Hlasek", "Henri Leconte", "Darren Cahill", "Dale Collings", "Chris Lewis NZL", "Bruce Derlin", "Brian Teacher", "Anders Jarryd", "Amos Mansdorf", "Wally Masur", "Vijay Amritraj", "Tony Mmoh", "Tomm Warneke", "Tom Gullikson", "Todd Nelson", "Tim Pawsat", "Tim Mayotte", "Steve Guy", "Stefan Edberg", "Stanislav Birner", "Slobodan Zivojinovic", "Simon Youl", "Shuzo Matsuoka", "Roscoe Tanner", "Roland Stadler", "Roger Knapp", "Rodney Harmon", "Rod Frawley", "Robert Seguso", "Richard Matuszewski", "Richard Fromberg", "Ricardo Acuna", "Peter Lundgren", "Peter Elter", "Pete Sampras", "Paul Mcnamee", "Paul Chamberlin", "Patrice Kuchna", "Pat Cash", "Nduka Odizor", "Mike Myburg", "Mike Bauer", "Michael Stich", "Michael Robertson", "Mark Kratzmann", "Marcel Freeman", "Luiz Mattar", "Larry Stefanki", "Ken Flach", "John Sobel", "John Sadri", "John Mcenroe", "John Frawley", "Johan Kriek", "Joey Rive", "Joao Soares", "Jimmy Connors", "Jimmy Brown", "Jeff Tarango", "Jeff Borowiak", "Jan Gunnarsson", "James Turner", "Ivan Lendl", "Huub Van Boeckel", "Gianluca Pozzi", "Francisco Gonzalez", "Eddie Edwards", "Doug Burke", "Desmond Tyson", "Danny Saltz", "Craig A Miller", "Cliff Letcher", "Christo Van Rensburg", "Christo Steyn", "Chris Pridham", "Chip Hooper", "Bud Schultz", "Bruno Oresar", "Bruce Kleege", "Bob Green", "Billy Nealon", "Bill Scanlon", "Barry Moir", "Andy Andrews", "Andrew Sznajder", "Andrei Chesnokov", "Alex Antonitsch"];
var matchmx = [["19910114", "Australian Open", "Hard", "G", "L", "331", "", "WC", "R128", "6-4 7-6(5) 7-5", "5", "Richard Fromberg", "28", "", "", "R", "19700428", "196", "AUS", "0", "133", "7", "8", "114", "75", "49", "20", "17", "3", "7", "17", "0", "93", "56", "46", "23", "17", "2", "4"],
          ["19920210", "Memphis", "Hard", "A", "L", "UNR", "", "WC", "R64", "6-2 6-4", "3", "Kevin Curren", "68", "", "", "R", "19580302", "185", "USA", "0", "59", "1", "4", "51", "34", "19", "10", "9", "2", "5", "12", "1", "44", "25", "23", "13", "9", "0", "0"]
          ];
