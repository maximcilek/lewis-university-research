
    var fullname = 'Alice Ferlito';
    var lastname = 'Ferlito';
    var currentrank=1131;
    var peakrank=1084;
    var peakfirst=20250908;
    var peaklast=20250908;
    
    
    var hand='U';
    var backhand='';
    var country='ESP';
    var shortlist=22;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='';
    var wta_id='';
    var fc_id='800516446';
    var wiki_id='';
    var blast_link='';
    var more_link='';
    var death_date="";
    var dob_approx="";
    var elo_rating='';
    var elo_rank='';
    var ychoices=["Time Span", "Last 52", "Career", "2025", "2024", "2023", "2022"];
var tchoices=["Event", "All", "W100 Vitoria-Gasteiz", "W15 Jackson TN", "W15 Logrono", "W15 Nules", "W15 San Diego CA", "W25 Madrid", "W35 Hilton Head Island SC", "W35 Segovia", "W35 Vigo", "W50 Ourense", "W50 Palma del Rio"];
var cchoices=["vs Country", "All", "BEL", "BLR", "BUL", "ESP", "FRA", "IND", "POC", "RSA", "SVK", "UKR", "UNK", "USA"];
var rchoices=["as Rank", "All"];
var ochoices=["Raquel Gonzalez Vilar", "Nahia Berecoechea", "Yuliya Hatouka", "Yasmine Mansouri", "Radka Zelnickova", "Noelia Bouzo Zanotti", "Margaux Maquet", "Makenna Jones", "Madhurima Sawant", "Judith Perello Saavedra", "Ellie Schoppe", "Claudia Ferrer Perez", "Chanel Simmonds", "Carol Young Suh Lee", "Candela Fajardo Aranda", "Viktoriia Dema", "Victoria Gomez", "Lucia Conde Zalona", "Yu Chen", "Victoria Lazarova"];
var tdates=["20221114", "20230605", "20230717", "20231016", "20240527", "20240624", "20240722", "20240819", "20241021", "20250804", "20250811", "20250818"];
var vranks=["349", "362", "432", "520", "539", "609", "801", "969", "1007", "1013", "1028", "1159", "1197", "1199", "1349"];
playernews = [];
var upcoming = "";
var matchmx = [["20250818", "W15 Logrono", "Hard", "15", "L", "1390", "", "", "R32", "6-3 6-4", "3", "Claudia Ferrer Perez", "1159", "", "", "U", "20060714", "", "ESP", "0", "99", "0", "1", "52", "30", "13", "10", "9", "2", "7", "7", "3", "66", "36", "25", "13", "10", "7", "10", "", "", "", "", "2025-W-ITF-ESP-2025-026-102"],
          ["20250811", "W35 Vigo", "Hard", "35", "L", "", "", "", "QF", "6-3 6-3", "3", "Carol Young Suh Lee", "349", "", "", "U", "20011221", "", "POC", "0", "90", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2025-W-ITF-ESP-2025-028-304"],
          ["20250811", "W35 Vigo", "Hard", "35", "W", "", "", "", "R16", "6-3 6-4", "3", "Nahia Berecoechea", "520", "", "", "R", "20040423", "", "FRA", "0", "97", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "4", "2", "2", "0", "1", "0", "0", "", "", "", "", "2025-W-ITF-ESP-2025-028-208"],
          ["20250811", "W35 Vigo", "Hard", "35", "W", "", "", "", "R32", "6-2 5-7 6-1", "3", "Yasmine Mansouri", "362", "", "", "R", "20010515", "", "FRA", "0", "121", "1", "2", "84", "52", "33", "19", "13", "5", "8", "2", "15", "94", "53", "34", "15", "14", "6", "13", "", "", "", "", "2025-W-ITF-ESP-2025-028-116"],
          ["20250804", "W50 Ourense", "Hard", "50", "L", "", "", "", "R32", "6-2 6-3", "3", "Noelia Bouzo Zanotti", "801", "", "", "R", "19990906", "", "ESP", "0", "79", "1", "0", "45", "23", "11", "7", "9", "2", "8", "1", "6", "59", "39", "24", "7", "8", "1", "4", "", "", "", "", "2025-W-ITF-ESP-2025-032-115"],
          ["20241021", "W35 Hilton Head Island SC", "Hard", "35", "L", "", "", "Q", "R32", "7-6(6) 6-7(4) 6-0", "3", "Makenna Jones", "1028", "", "", "U", "19980226", "", "USA", "0", "", "", "", "", "", "", "2024-W-ITF-USA-2024-039-103"],
          ["20241021", "W35 Hilton Head Island SC", "Hard", "35", "W", "", "", "", "Q2", "6-2 3-6 10-6", "3", "Ellie Schoppe", "", "", "", "U", "20011118", "", "USA", "0", "", "", "", "", "", "", "2024-W-ITF-USA-2024-039-816"],
          ["20241021", "W35 Hilton Head Island SC", "Hard", "35", "W", "", "", "", "Q1", "6-4 4-6 14-12", "3", "Margaux Maquet", "969", "6", "", "R", "20011010", "", "BEL", "0", "", "", "", "", "", "", "2024-W-ITF-USA-2024-039-721"],
          ["20240819", "W35 Vigo", "Hard", "35", "L", "", "", "", "Q2", "6-1 6-2", "3", "Judith Perello Saavedra", "1013", "5", "", "U", "20020123", "", "ESP", "0", "", "", "", "", "", "", "2024-W-ITF-ESP-2024-033-819"],
          ["20240819", "W35 Vigo", "Hard", "35", "W", "", "", "", "Q1", "6-0 6-0", "3", "Candela Fajardo Aranda", "", "", "", "U", "", "", "ESP", "0", "", "", "", "", "", "", "2024-W-ITF-ESP-2024-033-728"],
          ["20240722", "W35 Segovia", "Hard", "35", "L", "", "", "Q", "R32", "7-6(2) 6-2", "3", "Yuliya Hatouka", "432", "7", "", "R", "20000424", "", "BLR", "0", "", "", "", "", "", "", "2024-W-ITF-ESP-2024-037-113"],
          ["20240722", "W35 Segovia", "Hard", "35", "W", "", "", "WC", "Q2", "6-4 6-0", "3", "Raquel Gonzalez Vilar", "1197", "8", "", "U", "20040405", "", "ESP", "0", "", "", "", "", "", "", "2024-W-ITF-ESP-2024-037-818"],
          ["20240722", "W35 Segovia", "Hard", "35", "W", "", "", "WC", "Q1", "6-0 6-0", "3", "Madhurima Sawant", "1199", "11", "", "U", "", "", "IND", "0", "", "", "", "", "", "", "2024-W-ITF-ESP-2024-037-726"],
          ["20240624", "W50 Palma del Rio", "Hard", "50", "L", "", "", "", "Q1", "6-3 6-4", "3", "Radka Zelnickova", "539", "5", "", "R", "20030613", "", "SVK", "0", "", "", "", "20240623-W-W50_Palma_Del_Rio-Q1-Radka_Zelnickova-Alice_Ferlito", "", "", "2024-W-ITF-ESP-2024-026-719"],
          ["20240527", "W15 San Diego CA", "Hard", "15", "L", "", "", "", "Q1", "6-0 6-3", "3", "Chanel Simmonds", "", "10", "", "L", "19920810", "165", "RSA", "0", "", "", "", "", "", "", "2024-W-ITF-USA-2024-017-722"],
          ["20231016", "W15 Jackson TN", "Hard", "15", "L", "", "", "", "Q1", "6-4 6-0", "3", "Raquel Gonzalez Vilar", "1349", "5", "", "U", "20040405", "", "ESP", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2023-W-ITF-USA-49A-2023-109"],
          ["20230717", "W100 Vitoria-Gasteiz", "Hard", "100", "L", "", "", "", "Q1", "6-3 6-2", "3", "Nahia Berecoechea", "609", "5", "", "R", "20040423", "", "FRA", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2023-W-ITF-ESP-15A-2023-109"],
          ["20230605", "W25 Madrid", "Hard", "25", "L", "", "", "", "R16", "7-5 6-3", "3", "Viktoriia Dema", "", "", "", "U", "20001106", "", "UKR", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2023-W-ITF-ESP-18A-2023-308"],
          ["20230605", "W25 Madrid", "Hard", "25", "W", "", "", "", "R32", "3-6 7-5 14-12", "3", "Victoria Gomez", "1007", "8", "", "U", "20031113", "", "ESP", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2023-W-ITF-ESP-18A-2023-215"],
          ["20230605", "W25 Madrid", "Hard", "25", "W", "", "", "", "R64", "6-3 6-7(5) 10-5", "3", "Lucia Conde Zalona", "", "", "", "U", "20011212", "", "ESP", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2023-W-ITF-ESP-18A-2023-130"],
          ["20221114", "W15 Nules", "Clay", "15", "L", "", "", "", "Q2", "6-3 7-6(4)", "3", "Yu Chen", "", "11", "", "U", "20000602", "", "UNK", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2022-W-ITF-ESP-29A-2022-210"],
          ["20221114", "W15 Nules", "Clay", "15", "W", "", "", "", "Q1", "6-2 6-1", "3", "Victoria Lazarova", "", "", "", "U", "20040906", "", "BUL", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2022-W-ITF-ESP-29A-2022-119"]
          ];
