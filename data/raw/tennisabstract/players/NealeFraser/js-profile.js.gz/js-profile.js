
    var fullname = 'Neale Fraser';
    var lastname = 'Fraser';
    var currentrank="";
    var peakrank=188;
    var peakfirst=19741220;
    var peaklast=19741220;
    var dob=19331003;
    
    var hand='L';
    var country='AUS';
    var shortlist=1;
    var careerjs=1;
    var active=0;
    var lastdate=19800107;
    var ychoices=["Time Span", "Last 52", "Career", "1980", "1975", "1974", "1973", "1972", "1971", "1968", "1965", "1962", "1961", "1960", "1959", "1958", "1957", "1956", "1955", "1954", "1953", "1952"];
var tchoices=["Event", "All", "Davis Cup", "Adelaide", "Australian Chps", "Australian Open", "Bastad", "Cedar Grove", "Hilversum", "Perth", "Queen's Club", "Roland Garros", "US Open", "Wimbledon"];
var cchoices=["vs Country", "All", "AUS", "AUT", "BEL", "BRA", "CAN", "CHI", "CHN", "CRO", "CUB", "DEN", "ESP", "FRA", "GBR", "GER", "HUN", "IND", "ITA", "MEX", "NED", "NZL", "PER", "POL", "RSA", "RUS", "SWE", "USA", "YUG", "ZIM"];
var rchoices=["as Rank", "All"];
var ochoices=["Ashley Cooper", "Rod Laver", "E Victor Seixas", "Barry Mackay", "Alejandro Olmedo", "Robert Wilson", "Rafael Osuna", "Orlando Sirola", "Nicola Pietrangeli", "Martin Mulligan", "Lew Hoad", "Istvan Gulyas", "Tut Bartzen", "Tony Palafox", "Rudy Hernando", "Roy Emerson", "Ramanathan Krishnan", "Pierre Darmon", "Ned Neely", "Michael Davies", "Mal Anderson", "Jackie Brichant", "Hamilton Richardson", "Gil J Shea", "Don Candy", "Calvin Maccracken", "Budge Patty", "Bob Hewitt", "Billy Knight", "Barry Phillips Moore", "Willem Maris", "Whitney Reed", "Warren Jacques", "Vladimir Petrovic", "Uffe Schmidt", "Torben Ulrich", "Tony Trabert", "Tim Clements", "Thomas Lejus", "Syd Ball", "Sven Viktor Davidson", "Roger Taylor", "Roger Dowdeswell", "Roger Becker", "Robert Haillet", "Robert Bedard", "Robert Abdesselam", "Reynaldo Garrido", "Raymond Moore", "R Harvey", "Premjit Lall", "Peter Estin", "Patricio Rodriguez CHI", "Pancho Contreras", "Orlando H Garrido", "Onny Parun", "Nikola Pilic", "Mike E Green", "Michael Sangster", "Michael Preston Hann", "Mervyn Rose", "Mario Belardinelli", "Manuel Orantes", "Luis Ayala", "Lew Gerrard", "Kurt Nielsen", "Ken Fletcher", "Juan Manuel Couder", "Juan Gisbert", "Jozef Orlikowski", "Jose Luis Arillla", "Jorgen Ulrich", "John J Pearce", "John H Hann", "John F Obrien", "John Cooper", "Johann F Kupferburger", "Joe Blatchford", "Jimmy Connors", "Jerry Moss", "Jeff Borowiak", "James Chico Hagey", "Irvin Dorfman", "Hugh W Stewart", "Grover Raz Reid", "Greg Hughes", "Grant Golden", "Graham Lovett", "Graeme Stewart", "Gerard Pilet", "Geoffrey K Pares", "Geoff Masters", "Gardnar Mulloy", "G Harvey", "Fu Chi Mei", "Fred Stolle", "Franz Hainka", "Francis Nys", "Ernesto Aguirre", "Earl Butch Buchholz", "Donald Dell", "Dick Savitt", "Dick Raskind", "Dennis Ralston", "David Lloyd", "Crawford I Henry", "Courtney Henderson", "Corrado Barazzutti", "Colin Dibley", "Cliff P Mayne", "Cliff Letcher", "Christian Kuhnke", "Chris L Crawford", "Charles Mckinley", "Cesare Guerci Lena", "Carlos A Fernandes", "Brian Tobin", "Brian C Bowman", "Bob Mark", "Bob Lee", "Bob Howe", "Bob Falkenburg", "Bill Lloyd", "Berry Geraghty", "B Geoff Knox", "Antonio Maggi", "Anthony Hammond", "Andre Van Der Merwe B", "Allen Quay", "Alan Mills", "Adriano Panatta"];
var matchmx = [["19800107", "Perth", "Grass", "A", "L", "UNR", "", "", "R64", "3-6 7-5 12-10", "3", "Tim Clements", "511", "", "", "R", "", "", "AUS", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""]
          ];
