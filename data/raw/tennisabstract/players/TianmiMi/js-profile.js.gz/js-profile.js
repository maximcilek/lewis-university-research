
    var fullname = 'Tianmi Mi';
    var lastname = 'Mi';
    var currentrank=1120;
    var peakrank=639;
    var peakfirst=20240219;
    var peaklast=20240219;
    var dob=20040626;
    
    var hand='R';
    var backhand='';
    var country='CHN';
    var shortlist=12;
    var careerjs=1;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='';
    var wta_id='';
    var fc_id='800538981';
    var wiki_id='';
    var blast_link='';
    var more_link='';
    var death_date="";
    var dob_approx="";
    var elo_rating='';
    var elo_rank='';
    var ychoices=["Time Span", "Last 52", "Career", "2025", "2024", "2023", "2022"];
var tchoices=["Event", "All", "W100 Les Franqueses del Valles (Barcelona)", "W100 Shenzhen", "W100 Vitoria-Gasteiz", "W15 Antalya", "W15 Baza", "W15 Castellon", "W15 Gonesse", "W15 Kayseri", "W15 Malaga", "W15 Manacor", "W15 Monzon", "W15 Nules", "W15 Sant Vicenc de Torello (Barcelona)", "W15 Sharm ElSheikh", "W15 Telde", "W15 Valencia", "W25 Don Benito", "W25 Guiyang", "W25 Nakhon Si Thammarat", "W25 Ourense", "W25 Palmanova", "W25 Qian Daohu", "W25 Vigo", "W25 Yecla", "W25+H Tauste-Zaragoza", "W35 Antalya", "W35 Baza", "W35 Santo Domingo", "W40 Shenzhen", "W50 Antalya", "W50 Shenzhen", "W60 Madrid"];
var cchoices=["vs Country", "All", "ARG", "BLR", "BRA", "BUL", "CHN", "CRO", "CZE", "ESP", "FRA", "GBR", "GEO", "GER", "GRE", "IND", "ITA", "JPN", "LAT", "LUX", "MDA", "MEX", "NED", "PHI", "ROU", "RUS", "SLO", "SRB", "SUI", "SVK", "SWE", "THA", "TPE", "TUR", "UKR", "UNK", "USA", "UZB"];
var rchoices=["as Rank", "All"];
var ochoices=["Marie Weckerle", "Ana Martinez Vaquero", "Ylena In Albon", "Wushuang Zheng", "Ruth Roura Llaverias", "Oleksandra Oliynykova", "Lucia Cortez Llorca", "Laura Mair", "Yi Tsen Cho", "Victoria Allen", "Uladzislava Zverava", "Talia Neilson Gatenby", "Stefana Lazar", "Sofia Shapatava", "Sebastianna Scilipoti", "Nika Radisic", "Nicole Giannini", "Neus Torner Sensano", "Nahjime Dho", "Meng Yi Chen", "Melisa Ercan", "Mary Lewis", "Marie Villet", "Maria Kalyakina", "Maria Andrienko", "Lucia Peyre", "Lucia Llinares Domingo", "Lola Radivojevic", "Lola Collin", "Lidia Encheva", "Jiayou Li", "Jessica Hinojosa Gomez", "Irem Kurt", "Ela Nala Milic", "Diana Yakovleva", "Diana Marcinkevica", "Daniela Vismane", "Carlotta Moccia", "Astrid Cirotte", "Anna Ureke", "Anna Turati", "Anastasiia Aralova", "Anastasia Komkina", "Alina Charaeva", "Adelina Lachinova", "Zeynep Sonmez", "Xinxin Yao", "Victoria Rodriguez", "Verena Meliss", "Tilde Stromquist", "Shuoran Wang", "Shuo Feng", "Sara Dols", "Sara Baras Matei", "Prathyusha Rachapudi", "Pimlaphat Lim", "Paula Arias Manjon", "Nikol Palecek", "Mihaela Djakovic", "Meiling Wang", "Mayuka Aikawa", "Matilda Mutavdzic", "Marina Melnikova", "Marina Benito", "Maria Oliver Sanchez", "Maria Jose Portillo Ramirez", "Lidia Gonzalez", "Laura Boehner", "Katarina Stresnakova", "Karine Marion Job", "Jana Kareisova", "Ilay Yoruk", "Gina Feistel", "Fiona Ganz", "Emilie Lindh Gallagher", "Eleni Kordolaimi", "Dalayna Hewitt", "Chiara Girelli", "Caroline Romeo", "Carolin Raschdorf", "Carmen Lopez Martinez", "Caijsa Wilda Hennemann", "Alexandra Eala", "Alba Rey Garcia", "Aaddi Gupta", "Yu Chen", "Victoria Lazarova", "Vasanti Shinde", "Vanja Gudelj", "Noelia Bouzo Zanotti", "Nadiya Kolb", "Marine Szostak", "Kanupriya Rajawat", "Elena Noguero Asensio", "Ecaterina Visnevscaia", "Basak Eraydin", "Ariana Geerlings", "Adriana Tirado Marin"];
var tdates=["20220815", "20220822", "20221003", "20221031", "20221114", "20221128", "20230213", "20230227", "20230313", "20230320", "20230410", "20230417", "20230522", "20230529", "20230612", "20230619", "20230710", "20230717", "20230828", "20230904", "20230911", "20231009", "20231016", "20231023", "20240115", "20240122", "20240129", "20240205", "20240311", "20240318", "20240408", "20240415", "20240930", "20241014", "20241021", "20250310", "20250512", "20250526", "20250602", "20250609", "20250623", "20250630"];
var vranks=["177", "208", "233", "238", "258", "318", "337", "379", "380", "388", "394", "401", "434", "441", "470", "498", "534", "535", "538", "540", "543", "549", "561", "574", "578", "587", "627", "639", "650", "664", "672", "685", "695", "707", "709", "711", "714", "725", "739", "751", "753", "761", "797", "802", "804", "816", "825", "826", "839", "889", "900", "925", "927", "957", "983", "992", "1003", "1006", "1028", "1033", "1041", "1060", "1098", "1123", "1134", "1138", "1155", "1190", "1226", "1258", "1261", "1422"];
playernews = [];
var upcoming = "";
var matchmx = [["20250310", "W15 Gonesse", "Clay", "15", "L", "961", "", "", "R16", "4-6 6-2 1-0 RET", "3", "Astrid Cirotte", "839", "", "", "U", "20031216", "", "FRA", "0", "103", "2", "9", "63", "27", "19", "14", "10", "4", "9", "1", "1", "67", "43", "26", "11", "9", "8", "11", "", "", "", "", "2025-W-ITF-FRA-2025-005-205"],
          ["20250310", "W15 Gonesse", "Clay", "15", "W", "961", "", "", "R32", "6-3 6-2", "3", "Lola Collin", "", "", "", "U", "20070424", "", "FRA", "0", "72", "2", "6", "52", "27", "19", "12", "8", "3", "5", "0", "4", "47", "34", "17", "4", "9", "3", "9", "", "", "", "", "2025-W-ITF-FRA-2025-005-110"],
          ["20250512", "W15 Monzon", "Hard", "15", "L", "1008", "", "", "R16", "6-4 6-0", "3", "Carlotta Moccia", "1060", "", "", "U", "20030317", "", "ITA", "0", "83", "4", "5", "65", "38", "20", "10", "8", "3", "8", "0", "1", "47", "30", "24", "8", "8", "4", "5", "", "", "", "", "2025-W-ITF-ESP-2025-014-207"],
          ["20250512", "W15 Monzon", "Hard", "15", "W", "1008", "", "", "R32", "6-2 6-2", "3", "Marie Villet", "711", "", "", "U", "19961117", "", "FRA", "0", "88", "0", "2", "53", "34", "22", "8", "8", "3", "6", "1", "1", "66", "38", "19", "9", "8", "11", "18", "", "", "", "", "2025-W-ITF-ESP-2025-014-113"],
          ["20250526", "W35 Santo Domingo", "Clay", "35", "L", "1007", "", "", "R64", "6-3 6-4", "3", "Jessica Hinojosa Gomez", "983", "", "", "U", "19970918", "", "MEX", "0", "109", "0", "3", "76", "50", "28", "9", "10", "7", "13", "0", "6", "76", "51", "32", "8", "9", "8", "11", "", "", "", "", "2025-W-ITF-DOM-2025-004-103"],
          ["20250602", "W35 Santo Domingo", "Hard", "35", "L", "1007", "", "", "R32", "6-7(1) 6-2 6-3", "3", "Melisa Ercan", "388", "", "", "U", "20050901", "", "TUR", "0", "190", "1", "8", "106", "72", "45", "15", "15", "9", "15", "3", "4", "98", "56", "45", "15", "14", "4", "6", "", "", "", "", "2025-W-ITF-DOM-2025-005-212"],
          ["20250602", "W35 Santo Domingo", "Hard", "35", "W", "1007", "", "", "R64", "7-5 6-2", "3", "Mary Lewis", "804", "", "", "U", "19981025", "", "USA", "0", "109", "0", "12", "75", "50", "28", "7", "10", "8", "14", "1", "5", "72", "55", "22", "6", "10", "4", "13", "", "", "", "", "2025-W-ITF-DOM-2025-005-123"],
          ["20250609", "W35 Santo Domingo", "Hard", "35", "L", "992", "", "", "R64", "6-4 3-6 6-2", "3", "Victoria Allen", "889", "", "", "U", "20010226", "", "GBR", "0", "149", "0", "8", "101", "67", "41", "13", "14", "7", "13", "5", "2", "76", "49", "33", "12", "13", "5", "9", "", "", "", "", "2025-W-ITF-DOM-2025-006-103"],
          ["20250623", "W15 Kayseri", "Hard", "15", "L", "944", "", "", "R16", "6-3 7-6(3)", "3", "Adelina Lachinova", "711", "", "", "U", "20080210", "", "LAT", "0", "94", "0", "11", "61", "40", "28", "5", "10", "2", "6", "3", "3", "83", "47", "33", "15", "11", "6", "9", "", "", "", "", "2025-W-ITF-TUR-2025-023-203"],
          ["20250623", "W15 Kayseri", "Hard", "15", "W", "944", "", "", "R32", "6-0 7-6(3)", "3", "Stefana Lazar", "1422", "", "", "U", "20020211", "", "ROU", "0", "91", "0", "7", "68", "40", "27", "11", "9", "6", "9", "1", "10", "56", "25", "12", "11", "9", "5", "11", "", "", "", "", "2025-W-ITF-TUR-2025-023-106"],
          ["20250630", "W15 Kayseri", "Hard", "15", "L", "944", "", "", "R16", "7-6(6) 0-0", "3", "Nahjime Dho", "", "", "", "U", "", "", "FRA", "0", "65", "0", "0", "47", "31", "14", "6", "6", "2", "6", "0", "6", "43", "19", "9", "10", "6", "4", "8", "", "", "", "", "2025-W-ITF-TUR-2025-024-205"],
          ["20250630", "W15 Kayseri", "Hard", "15", "W", "944", "", "", "R32", "7-5 6-0", "3", "Anastasiia Aralova", "", "", "", "U", "20070123", "", "RUS", "0", "74", "1", "3", "65", "53", "35", "3", "9", "3", "5", "0", "6", "50", "27", "12", "7", "9", "2", "8", "", "", "", "", "2025-W-ITF-TUR-2025-024-109"]
          ];
