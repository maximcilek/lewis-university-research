
    var fullname = 'Andrea Jaeger';
    var lastname = 'Jaeger';
    var currentrank="";
    var peakrank=3;
    var peakfirst=19840102;
    var peaklast=19840213;
    var dob=19650604;
    var ht=168;
    var hand='R';
    var backhand='2';
    var country='USA';
    var shortlist=6;
    var careerjs=1;
    var active=0;
    var lastdate=19870420;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='20002715';
    var wta_id='';
    var fc_id='800177139';
    var wiki_id='';
    var blast_link='';
    var more_link='';
    var death_date="";
    var dob_approx="";
    var ychoices=["Time Span", "Last 52", "Career", "1987", "1986", "1985", "1984", "1983", "1982", "1981", "1980", "1979"];
var tchoices=["Event", "All", "Australian Open", "Wimbledon", "US Open", "Olympics", "Fed Cup", "Amelia Island", "Amelia island", "Avon Championships", "Beckenham", "Belgium Exho", "Berlin", "Boca Raton", "Boston", "Carlsbad", "Carta Blanca Exho", "Charleston", "Chicago", "Chichester", "Dallas", "Deerfield Beach", "Detroit", "East Rutherford", "Eastbourne", "Edmond", "Filderstadt", "Hilton Head", "Houston", "Indianapolis", "Johannesburg", "Johannesburg Eagle", "Johannesburg Exho", "Kansas City", "Landover", "Las Vegas", "Las Vegas Futures", "Los Angeles", "Mahwah", "Marco Island", "Montreal", "Oakland", "Orlando", "Palm Beach", "Palm Beach Gardens", "Perth", "Perth 2", "Roland Garros", "San Diego", "San Diego Exho", "Seattle", "St. Joseph", "Sydney", "Sydney Indoors", "Sydney Indoors 2", "Tampa", "Tokyo Gunze", "Tokyo Lion Cup", "Tokyo Queen's", "Toronto", "Virginia Slims Championships", "Washington", "Wightman Cup"];
var cchoices=["vs Country", "All", "ARG", "AUS", "CAN", "CZE", "DEN", "ESP", "FRA", "GBR", "GER", "HUN", "ITA", "JPN", "KOR", "NED", "NOR", "NZL", "PER", "ROU", "RSA", "SLO", "SUI", "SWE", "TCH", "USA", "YUG"];
var rchoices=["as Rank", "All", "Top 5", "Top 10", "Top 20", "Top 50", "Top 100", "6+", "11+", "21+", "51+", "101+"];
var ochoices=["Chris Evert", "Martina Navratilova", "Wendy Turnbull", "Sylvia Hanika", "Hana Mandlikova", "Tracy Austin", "Sue Barker", "Virginia Ruzici", "Pam Shriver", "Mima Jausovec", "Joanne Russell", "Bettina Bunge", "Leslie Allen", "Kathy Jordan", "Barbara Potter", "Mareen Louie Harper", "Kathy Rinaldi Stunkel", "Candy Reynolds", "Bonnie Gadusek", "Anne Smith", "Anne Hobbs", "Zina Garrison", "Virginia Wade", "Sherry Acker", "Pam Casale", "Lisa Bonder Kreiss", "Kathy Horvath", "Evonne Goolagong", "Claudia Kohde Kilsch", "Catherine Tanvier", "Andrea Temesvari", "Yvonne Vermaak", "Susan Mascarin", "Susan Leo", "Sandy Collins", "Rosie Casals", "Rosalyn Fairbank", "Mary Lou Piatek", "Jo Durie", "Jeanne Duvall", "Eva Pfaff", "Betsy Nagelsen", "Barbara Jordan", "Anne White", "Ann Henricksson", "Wendy White", "Sabina Simmonds", "Renee Richards", "Renata Tomanova", "Petra Delhees Jauch", "Nina Bohm", "Marie Christine Calleja", "Lucia Romanov", "Lena Sandin", "Laura Arraya", "Ivanna Madruga", "Helena Sukova", "Gretchen Magers", "Elise Burgin", "Duk Hee Lee", "Dianne Fromholtz", "Dana Gilbert", "Corinne Vanier", "Billie Jean King", "Alycia Moulton", "Wendy Barlow", "Vicki Nelson", "Tine Scheuer Larsen", "Tanya Harford", "Susie Jaeger", "Susan Sloane Lundy", "Susan Rimes", "Sue Saliba", "Sheila Mcinerney", "Shawn Foltz", "Sharon Walsh Pete", "Rene Uys", "Rene Blount", "Renata Sasak", "Regina Marsikova", "Raquel Giscafre", "Paula Smith", "Patty Fendick", "Patricia Tarabini", "Patricia Hy Boulais", "Pascale Paradis Mangon", "Pam Teeguarden", "Nerida Gregory", "Nancy Yeargin", "Min Kyung Seol", "Micki Schillig", "Melissa Gurney", "Marita Redondo", "Marianne Van Der Torre", "Maria Victoria Baldovinos Cibeira", "Lori Mcneil", "Liz Smylie", "Lesley Charles", "Leigh Anne Thompson", "Kim Steinmetz", "Kim Sands", "Kim Jones", "Kerry Reid", "Kelly Henry", "Kay Mcdaniel", "Kathy May", "Kate Latham", "Julie Salmon", "Judy Chaloner", "Jane Stratton", "Jamie Golder", "Iva Budarova", "Hana Strachonova", "Greer Stevens", "Glynis Coles", "Etsuko Inoue", "Ellen Grindvold", "Donna Rubin", "Diane Morrison", "Claudia Pasquale", "Chris Matison", "Catrin Jexell", "Carling Bassett Seguso", "Beverly Mould", "Beverly Bowes", "Betty Stove", "Bettina Fulco", "Beth Norton", "Beth Herr", "Bernadette Randall", "Barbara Hallquist", "Barbara Gerken", "Anthea Stewart", "Anne Minter", "Andrea Whitmore", "Andrea Leand", "Amanda Tobin"];
var tdates=["19790716", "19790828", "19791119", "19800114", "19800121", "19800128", "19800218", "19800303", "19800310", "19800329", "19800407", "19800429", "19800526", "19800602", "19800608", "19800616", "19800623", "19800804", "19800810", "19800818", "19800826", "19800915", "19801013", "19801031", "19801103", "19801110", "19810107", "19810112", "19810126", "19810209", "19810302", "19810322", "19810405", "19810420", "19810427", "19810512", "19810525", "19810615", "19810622", "19810717", "19810803", "19810817", "19810901", "19811012", "19811109", "19811116", "19811123", "19811130", "19811214", "19820104", "19820118", "19820125", "19820201", "19820222", "19820301", "19820308", "19820322", "19820405", "19820419", "19820426", "19820510", "19820524", "19820614", "19820621", "19820729", "19820802", "19820815", "19820823", "19820831", "19821004", "19821011", "19821103", "19821115", "19821122", "19821129", "19821214", "19830103", "19830110", "19830122", "19830130", "19830214", "19830228", "19830323", "19830404", "19830418", "19830513", "19830516", "19830523", "19830613", "19830620", "19830717", "19830728", "19830807", "19830815", "19830830", "19830912", "19831121", "19840102", "19840109", "19840130", "19840228", "19840402", "19840430", "19840528", "19840725", "19840806", "19850422", "19850527", "19850812", "19850827", "19850916", "19860210", "19870330", "19870420"];
var vranks=["2", "9", "12", "13", "16", "21", "28", "32", "34", "50", "52", "56", "64", "81", "95", "99", "100", "101", "109", "110", "171"];
playernews = [];
var upcoming = "";
var matchmx = [["19870420", "Houston", "Clay", "W", "L", "", "", "", "R16", "W/O", "3", "Lori Mcneil", "13", "6", "", "U", "19631218", "", "USA", "0", "", "", "", "", "", "", "", "", "", "1987-W-WT-USA-14A-1987-018"],
          ["19870420", "Houston", "Clay", "W", "W", "", "", "", "R32", "4-6 6-0 6-4", "3", "Mary Lou Daniels", "81", "", "", "R", "19610806", "", "USA", "0", "", "", "", "", "", "", "", "", "", "1987-W-WT-USA-14A-1987-003"],
          ["19870330", "Charleston", "Clay", "W", "L", "", "", "", "R16", "6-1 6-1", "3", "Bettina Fulco", "109", "", "", "R", "19681023", "", "ARG", "0", "", "", "", "", "", "", "", "", "", "1987-W-WT-USA-11A-1987-044"],
          ["19870330", "Charleston", "Clay", "W", "W", "", "", "", "R32", "2-6 6-3 6-1", "3", "Patricia Tarabini", "110", "", "", "R", "19680806", "", "ARG", "0", "", "", "", "", "", "", "", "", "", "1987-W-WT-USA-11A-1987-031"],
          ["19870330", "Charleston", "Clay", "W", "W", "", "", "", "R64", "6-3 6-2", "3", "Susan Sloane Lundy", "100", "", "", "R", "19701205", "", "USA", "0", "", "", "", "", "", "", "", "", "", "1987-W-WT-USA-11A-1987-011"],
          ["19860210", "Boca Raton", "Hard", "W", "L", "114", "", "", "R128", "6-7 6-2 6-2", "3", "Ann Henricksson", "52", "", "", "U", "19591031", "", "USA", "0", "", "", "", "", "", "", "", "", "", "1986-W-WT-USA-05A-1986-047"]
          ];
