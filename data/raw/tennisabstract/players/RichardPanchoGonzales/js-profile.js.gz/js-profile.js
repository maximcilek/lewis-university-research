
    var fullname = 'Richard Pancho Gonzales';
    var lastname = 'Gonzales';
    var currentrank="";
    var peakrank=109;
    var peakfirst=19740729;
    var peaklast=19740729;
    var dob=19280509;
    var ht=188;
    var hand='R';
    var country='USA';
    var shortlist=1;
    var careerjs=1;
    var active=0;
    var lastdate=19760214;
    var ychoices=["Time Span", "Last 52", "Career", "1976", "1973", "1972", "1971", "1970", "1969", "1968", "1949", "1948", "1947"];
var tchoices=["Event", "All", "Davis Cup", "Albany", "Auckland", "Australian Open", "Boston", "Bournemouth", "Cincinnati", "Cleveland WCT", "Columbus", "Des Moines", "London Indoor", "Los Angeles", "Los Angeles WCT", "Monte Carlo", "Montreal Toronto", "Paris Indoor", "Philadelphia WCT", "Queen's Club", "Roland Garros", "Salisbury", "South Orange", "Sydney", "Toronto WCT", "US Open", "Wimbledon"];
var cchoices=["vs Country", "All", "AUS", "BEL", "BRA", "CHI", "CRO", "CZE", "DEN", "EGY", "ESP", "FRA", "GBR", "GER", "GRE", "HUN", "IND", "ITA", "JAM", "MEX", "NED", "NZL", "PAK", "ROU", "RSA", "RUS", "SWE", "TCH", "UNK", "USA"];
var rchoices=["as Rank", "All"];
var ochoices=["Tony Roche", "Roscoe Tanner", "Marty Riessen", "Ken Rosewall", "Jimmy Connors", "Zeljko Franulovic", "Torben Ulrich", "Tom Okker", "Tom Edlefsen", "Thomaz Koch", "Roger Taylor", "Pierre Barthes", "Ove Nils Bengtson", "Onny Parun", "Mike Estep", "Michele Leclercq", "Manuel Orantes", "John Newcombe", "Jim Osborne", "Ian Fletcher", "Haroon Rahim", "Georges Goven", "Frank Parker", "Cliff Richey", "Bob Carmichael", "Art Larsen", "Vladimir Korotkov", "Vijay Amritraj", "U Unknown", "Torsten Johansson", "Straight Clark", "Stanley Matthews", "Stan Smith", "Sandy Mayer", "Roy Emerson", "Ron Holmberg", "Roger Dubuc", "Rod Laver", "Robert Potthast", "Robert Maud", "Robert Kreiss", "Raymond Moore", "Ray Ruffels", "Ray Keldie", "Ramanathan Krishnan", "Pierre Darmon", "Peter Curtis", "Paul Gerken", "Patrice Dominguez", "Nikola Pilic", "Nicholas Kalogeropoulos", "Milan Holecek", "Mike Machette", "Martin Mulligan", "Mark Cox", "Marcel Coen", "Marcel Bernard", "Marc Bolle", "Mal Anderson", "Ladislav Hecht", "Kirk Watson", "Karl Meiler", "Juan Gisbert", "John Sharpe", "John Paish", "John Lloyd", "Joaquin Loyo Mayo", "Jeff Borowiak", "Jaroslav Drobny", "James Brink", "Jackie Brichant", "Jack Geller", "Istvan Gulyas", "Ion Tiriac", "Ingo Buding", "Hans Gildemeister", "Gus Ganzenmuller", "Geoffrey Edmund Brown", "Geoff Masters", "Gene Mayer", "Gardnar Mulloy", "Frew Mcmillan", "Frederick Ted Schroeder", "Frank Arthur Sedgman", "Eric William Sturgess", "Earl Butch Buchholz", "Donald Dell", "Dick Crealy", "Derrick William Barton", "Derek Schroder", "D Richard Russell", "Colin Stubs", "Colin Dibley", "Coco Gentien", "Clay Iles", "Clark Graebner", "Christian Kuhnke", "Christian Grandet", "Charlie Pasarell", "Budge Patty", "Brian Fairlie", "Bob Giltinan", "Bill Sidwell", "Bill Bowrey", "Arthur Ashe", "Armistead Neely", "Antonio Munoz", "Andrew Pattison", "Alex Metreveli", "Adriano Panatta"];
var matchmx = [["19760214", "Salisbury", "Carpet", "A", "L", "UNR", "", "", "R64", "6-3 6-3", "3", "Gene Mayer", "144", "", "", "R", "19560411", "183", "USA", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""]
          ];
