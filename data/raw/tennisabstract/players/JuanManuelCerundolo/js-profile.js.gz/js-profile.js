
    var fullname = 'Juan Manuel Cerundolo';
    var lastname = 'Cerundolo';
    var currentrank=1581;
    var peakrank=1520;
    var peakfirst=20181112;
    var peaklast=20181112;
    var dob=20011115;
    
    var hand='U';
    var backhand='';
    var country='ARG';
    var shortlist=8;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs=1538;
    var peak_dubs=1510;
    var peakfirst_dubs=20181112;
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100288982';
    var atp_id='';
    var dc_id='';
    var wiki_id='';
    var ychoices=["Time Span", "Last 52", "Career", "2018", "2017"];
var tchoices=["Event", "All"];
var cchoices=["vs Country", "All", "ARG"];
var rchoices=["as Rank", "All"];
var ochoices=["Gonzalo Villanueva", "Oscar Gabriel Ortiz", "Julian Gimenez", "Guido Ivan Justo", "Gabriel Alejandro Hidalgo", "Camilo Ugo Carabelli", "Andres Gabriel Ciurletti"];
var tdates=["20170821", "20180910", "20180917", "20181029", "20181105", "20181112"];
var vranks=["557", "561", "871", "959", "1019", "1615", "1617"];
playernews = [];
var upcoming = "";
var matchmx = [["20170821", "Argentina F4", "Clay", "S", "L", "", "", "WC", "R32", "6-2 6-2", "3", "Camilo Ugo Carabelli", "871", "", "", "R", "18.1793292266", "", "ARG", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2017-M-FU-ARG-04A-2017-007", "", "1", "1"],
          ["20180910", "Argentina F5", "Clay", "S", "L", "UNR", "", "", "R16", "6-2 6-0", "3", "Gonzalo Villanueva", "561", "", "", "R", "19950113", "", "ARG", "1", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-ARG-05A-2018-021", "", "2", "2"],
          ["20180910", "Argentina F5", "Clay", "S", "W", "UNR", "", "", "R32", "7-6(5) 6-0", "3", "Julian Gimenez", "1615", "", "Q", "U", "20010223", "", "ARG", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-ARG-05A-2018-010", "", "1", "1"],
          ["20180917", "Argentina F6", "Clay", "S", "L", "UNR", "", "WC", "R32", "6-1 6-2", "3", "Gonzalo Villanueva", "557", "", "", "R", "19950113", "", "ARG", "1", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-ARG-06A-2018-009", "", "1", "1"],
          ["20181029", "Argentina F7", "Clay", "S", "L", "1724", "", "Q", "R16", "6-3 1-6 6-3", "3", "Guido Ivan Justo", "959", "", "", "U", "19971217", "", "ARG", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-ARG-07A-2018-020", "", "2", "2"],
          ["20181029", "Argentina F7", "Clay", "S", "W", "1724", "", "Q", "R32", "3-6 6-2 6-1", "3", "Oscar Gabriel Ortiz", "UNR", "", "", "U", "19970924", "", "ARG", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-ARG-07A-2018-007", "", "1", "1"],
          ["20181105", "Argentina F8", "Clay", "S", "L", "1720", "", "", "R32", "4-6 6-3 6-3", "3", "Andres Gabriel Ciurletti", "1617", "", "Q", "U", "19980104", "", "ARG", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-ARG-08A-2018-011", "", "1", "1"],
          ["20181112", "Argentina F9", "Clay", "S", "L", "1520", "", "", "R32", "6-1 6-2", "3", "Gabriel Alejandro Hidalgo", "1019", "", "", "R", "19900806", "", "ARG", "1", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-ARG-09A-2018-002", "", "1", "1"]
          ];
