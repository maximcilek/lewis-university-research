
    var fullname = 'Dane Sweeny';
    var lastname = 'Sweeny';
    var currentrank=1912;
    var peakrank=1593;
    var peakfirst=20180402;
    var peaklast=20180402;
    var dob=20010212;
    
    var hand='R';
    var backhand='';
    var country='AUS';
    var shortlist=4;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs=1189;
    var peak_dubs=1185;
    var peakfirst_dubs=20181001;
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100236260';
    var atp_id='';
    var dc_id='';
    var wiki_id='';
    var ychoices=["Time Span", "Last 52", "Career", "2018"];
var tchoices=["Event", "All"];
var cchoices=["vs Country", "All", "AUS"];
var rchoices=["as Rank", "All"];
var ochoices=["Scott Puodziunas", "Lucas Vuradin", "Jayden Court", "Aaron Addison"];
var tdates=["20180319", "20180326", "20180917"];
var vranks=["925", "1573", "1970"];
playernews = [];
var upcoming = "";
var matchmx = [["20180319", "Australia F3", "Clay", "S", "L", "UNR", "", "", "R16", "7-5 6-3", "3", "Aaron Addison", "1970", "", "", "R", "19951112", "", "AUS", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-AUS-03A-2018-020", "", "2", "2"],
          ["20180319", "Australia F3", "Clay", "S", "W", "UNR", "", "", "R32", "6-3 6-4", "3", "Scott Puodziunas", "925", "8", "", "U", "19891109", "", "AUS", "1", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "1", "2018-M-FU-AUS-03A-2018-008", "", "1", "1"],
          ["20180326", "Australia F4", "Clay", "S", "L", "UNR", "", "", "R32", "6-4 1-6 6-2", "3", "Lucas Vuradin", "1573", "", "WC", "R", "19990126", "", "AUS", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-AUS-04A-2018-002", "", "1", "1"],
          ["20180917", "Australia F5", "Hard", "S", "L", "1699", "", "WC", "R32", "6-3 6-3", "3", "Jayden Court", "UNR", "", "", "R", "20000619", "", "AUS", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-AUS-05A-2018-015", "", "1", "1"]
          ];
