
    var fullname = 'Kanako Morisaki';
    var lastname = 'Morisaki';
    var currentrank=1279;
    var peakrank=637;
    var peakfirst=20190617;
    var peaklast=20190624;
    var dob=19960905;
    
    var hand='U';
    var backhand='';
    var country='JPN';
    var shortlist=3;
    var careerjs=1;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100171262';
    var wta_id='19741/title/kanako-morisaki';
    var fc_id='';
    var wiki_id='';
    var blast_link='';
    var more_link='';
    var death_date="";
    var dob_approx="";
    var elo_rating='';
    var elo_rank='';
    var ychoices=["Time Span", "Last 52", "Career", "2025", "2024", "2023", "2022", "2021", "2020", "2019", "2018", "2017", "2016", "2014", "2013", "2012"];
var tchoices=["Event", "All", "W100 Tokyo", "W15 Annenheim", "W15 Antalya", "W15 Fukui", "W15 Gimcheon", "W15 Hinode", "W15 Ipoh Perak", "W15 Kawaguchi", "W15 Kuala Lumpur", "W15 Nakhon Si Thammarat", "W15 Sapporo", "W15 Tokyo", "W25 Annenheim", "W25 Austin TX", "W25 Bydgoszcz", "W25 Daegu", "W25 Daytona Beach FL", "W25 Frydek Mistek", "W25 Hamamatsu", "W25 Hong Kong", "W25 Incheon", "W25 Jablonec nad Nisou", "W25 Karuizawa", "W25 Kashiwa", "W25 Kofu", "W25 Kyoto", "W25 Makinohara", "W25 Nanao", "W25 Oldenzaal", "W25 Orlando FL", "W25 Osaka", "W25 Pelham AL", "W25 Perth", "W25 Radom", "W25 Santo Domingo", "W25 Tainan", "W25 Tokyo", "W25 Tsukuba", "W25 Warmbad Villach", "W35 Hamamatsu", "W35 Makinohara", "W35 Nakhon Si Thammarat", "W35 Osaka", "W35 Taipei", "W40 Hong Kong", "W40 Nanao", "W50 Ahmedabad", "W50 Caloundra", "W50 Guimaraes", "W50 Navi Mumbai", "W60 Fukuoka", "W60 Kurume", "W60 Prague", "W60 Prerov", "W60 San Bartolome (Gran Canaria)", "W75 Carrara", "W80 Gifu", "Daegu $25K", "Gyeongsan $15K", "Hamamatsu $25K", "Karuizawa $25K", "Karuizawa 25K", "Kurume $60K", "Makinohara $25K", "Nishi Tama $10K", "Nishi Tama $15K", "Noto 25K", "Sangju $15K", "Tsukuba $25K", "Tsukuba 25K"];
var cchoices=["vs Country", "All", "ARG", "AUS", "AUT", "BIH", "CAN", "CHN", "CZE", "FRA", "GER", "HKG", "HUN", "INA", "IND", "ITA", "JPN", "KAZ", "KOR", "NED", "NZL", "PHI", "POL", "RSA", "RUS", "SRB", "SVK", "SWE", "THA", "TPE", "TUR", "TWN", "UKR", "UNK", "USA"];
var rchoices=["as Rank", "All"];
var ochoices=["Mio Mushika", "Haruna Arakawa", "Yui Chikaraishi", "Tanuchaporn Yongmod", "Lisa Marie Rioux", "Ayaka Ozeki", "Seri Nayuki", "Sera Nishimoto", "Momoko Kobori", "Miho Kuramochi", "Junri Namigata", "Nagi Hanatani", "Chihiro Muramatsu", "Yuna Sugiyama", "Yuika Ikawa", "Yui Ohwaki", "Yu Ning Tsai", "Ying Zhang", "Yi Tsen Cho", "Yanni Liu", "Sohyun Park", "Shiyu Ye", "Risa Ushijima", "Rena Yoshida", "Pranjala Yadlapalli", "Pawinee Ruamrak", "Natsuko Saegusa", "Minori Ishida", "Meng Yi Chen", "Mao Mushika", "Lidia Podgorichani", "Kisa Yoshioka", "Kamonwan Yodpetch", "Ikumi Yamazaki", "I Wen Wan", "Honami Sodeyama", "Hiromi Abe", "Hina Nishi", "Hikaru Sato", "Funa Kozaki", "Fangran Tian", "Fang Ying Xun", "Elena Micic", "Dayeon Back", "Bunyawi Thamchaiwat", "Azusa Yasaki", "Azuna Ichioka", "Ayumi Miyamoto", "Apurva Vemuri", "Alice Pesci", "Alana Parnaby", "Aditi Rawat", "Zhibek Kulambayeva", "Yukina Saigo", "Ya Hsuan Lee", "Wushuang Zheng", "Shiho Tsujioka", "Sakura Hosogi", "Pei Chi Lee", "Natsumi Kawaguchi", "Miyu Nakashima", "Miharu Imanishi", "Kit Yi Kaye Au Yeung", "Kayo Nishimura", "Kanako Osafune", "Hiroko Kuwata", "Eri Shimizu", "Chisa Hosonuma", "Alexandra Eala", "Alevtina Ibragimova", "Zara Brankovic", "Yuna Ohashi", "Yuka Hosoki", "Yu Ting Hsieh", "Yu Jin Ahn", "Warona Mdlulwa", "Vanda Lukacs", "Valeriya Olyanovskaya", "Tully Richter", "Tereza Smitkova", "Tereza Dejnozkova", "Tayisiya Morderger", "Tammi Patterson", "Suzura Takaoka", "Suzuna Oigawa", "Sunam Jeong", "Su Jeong Jang", "Sofia Camila Rojas", "So Hee Jung", "Satona Yada", "Robu Kajitani", "Radka Zelnickova", "Olivia Tjandramulia", "Natalia Szabanin", "Naomi Cheong", "Naoko Eto", "Nana Kawagishi", "Na Ri Kim", "Na Lae Han", "Mutsumi Uemura", "Moyuka Uchijima", "Monique Barry", "Momo Arishika", "Misaki Matsuda", "Michiru Furuya", "Melis Yasar", "Melania Delai", "Meeka Marshall", "Maryna Chernyshova", "Mana Kawamura", "Mana Ayukawa", "Mai Minokoshi", "Mai Hontama", "Liel Marlies Rothensteiner", "Laura Radakovic", "Kyoka Okamura", "Karolina Jaskiewicz", "Kariann Pierre Louis", "Kanami Tsuji", "Ju Eun Kim", "Jovana Jaksic", "Johana Markova", "Ji Hee Choi", "Ipek Oz", "Hua Chen Lee", "Himeno Sakatsume", "Haruka Kaji", "Handeul Kim", "Federica Arcidiacono", "Erina Hayashi", "Erika Takao", "Erika Matsuda", "Emma Lella", "Elysia Bolton", "Doga Turkmen", "Denisa Hindova", "Demi Tran", "Dabin Kim", "Da Ye Kim", "Ching Wen Hsu", "Chie Kezuka", "Charlotte Chavatipon", "Chang Liu", "Berta Bonardi", "Berfu Cengiz", "Ashlyn Krueger", "Arina Rodionova", "Anchisa Chanta", "Ana Grubor", "Alison Bai", "Alice Rame", "Alexandra Bozovic", "Aldila Sutjiadi", "Akiko Yonemura"];
var tdates=["20120521", "20120827", "20120903", "20130826", "20140519", "20160321", "20170522", "20170821", "20180319", "20180514", "20180521", "20180604", "20180611", "20180618", "20180820", "20181008", "20181015", "20190114", "20190121", "20190128", "20190204", "20190211", "20190401", "20190408", "20190429", "20190506", "20190513", "20190520", "20190527", "20190603", "20190610", "20190617", "20190819", "20190826", "20190902", "20191007", "20191014", "20191111", "20191230", "20200106", "20200217", "20200224", "20210517", "20210531", "20210802", "20210809", "20210816", "20210823", "20210830", "20210906", "20210913", "20211025", "20211101", "20211108", "20220516", "20220523", "20220530", "20220808", "20221010", "20230320", "20230327", "20230410", "20230424", "20230515", "20230529", "20230619", "20230626", "20230703", "20230904", "20230918", "20230925", "20240226", "20240304", "20240318", "20240408", "20240527", "20240603", "20240617", "20240624", "20240722", "20240729", "20240819", "20240826", "20240902", "20241028", "20241104", "20241118", "20241125", "20241216", "20250224", "20250609"];
var vranks=["127", "189", "195", "252", "260", "280", "284", "296", "299", "306", "309", "317", "323", "328", "332", "334", "346", "353", "354", "364", "378", "386", "387", "392", "395", "435", "442", "443", "445", "446", "447", "450", "451", "453", "456", "462", "491", "498", "501", "502", "512", "520", "522", "537", "545", "546", "548", "557", "561", "570", "582", "584", "587", "588", "590", "592", "603", "608", "613", "618", "651", "652", "660", "681", "682", "688", "692", "695", "701", "718", "723", "726", "766", "775", "793", "805", "810", "830", "831", "836", "839", "845", "846", "850", "858", "887", "912", "916", "945", "953", "977", "994", "1008", "1011", "1023", "1035", "1058", "1061", "1094", "1120", "1157", "1197", "1204", "1216", "1225", "1257", "1264", "1334", "1342", "1358", "1412", "1481"];
playernews = [];
var upcoming = "";
var matchmx = [["20250224", "W50 Ahmedabad", "Hard", "50", "L", "879", "", "", "R32", "6-3 6-1", "3", "Sohyun Park", "378", "", "", "U", "20020702", "", "KOR", "0", "68", "0", "3", "46", "37", "19", "5", "8", "1", "5", "4", "1", "69", "36", "26", "18", "8", "8", "8", "", "", "", "", "2025-W-ITF-IND-2025-004-210"],
          ["20250224", "W50 Ahmedabad", "Hard", "50", "W", "879", "", "", "R64", "6-2 6-3", "3", "Pranjala Yadlapalli", "", "", "", "R", "19990330", "", "IND", "0", "97", "3", "7", "69", "51", "33", "8", "9", "7", "9", "4", "4", "57", "39", "19", "6", "8", "3", "8", "", "", "", "", "2025-W-ITF-IND-2025-004-119"],
          ["20250609", "W50 Guimaraes", "Hard", "50", "L", "888", "", "", "R32", "4-6 7-5 6-3", "3", "Elena Micic", "386", "", "", "U", "20040713", "", "AUS", "0", "133", "1", "7", "108", "68", "34", "16", "16", "4", "13", "0", "10", "95", "62", "37", "10", "15", "4", "11", "", "", "", "", "2025-W-ITF-POR-2025-009-102"]
          ];
