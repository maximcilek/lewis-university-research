
    var fullname = 'Nicholas David Ionel';
    var lastname = 'Ionel';
    var currentrank=1912;
    var peakrank=1867;
    var peakfirst=20180910;
    var peaklast=20180910;
    var dob=20021012;
    
    var hand='R';
    var backhand='';
    var country='ROU';
    var shortlist=6;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs=1327;
    var peak_dubs=1321;
    var peakfirst_dubs=20180917;
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100245686';
    var atp_id='';
    var dc_id='';
    var wiki_id='';
    var ychoices=["Time Span", "Last 52", "Career", "2018", "2017"];
var tchoices=["Event", "All"];
var cchoices=["vs Country", "All", "BRA", "BUL", "ROU", "RUS", "URU"];
var rchoices=["as Rank", "All"];
var ochoices=["Vasile Alexandru Ghilea", "Santiago Maresca", "Orlando Luz", "Mikhail Korovin", "Gabi Adrian Boitan", "Alexandar Lazarov"];
var tdates=["20170821", "20180521", "20180528", "20180813", "20180820"];
var vranks=["668", "747", "796", "852", "983", "989"];
playernews = [];
var upcoming = "";
var matchmx = [["20170821", "Romania F11", "Clay", "S", "L", "", "", "WC", "R32", "6-3 6-4", "3", "Santiago Maresca", "989", "", "", "U", "22.9349760438", "", "URU", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2017-M-FU-ROU-11A-2017-006", "", "1", "1"],
          ["20180521", "Romania F1", "Clay", "S", "L", "UNR", "", "", "R32", "7-6(4) 7-5", "3", "Alexandar Lazarov", "747", "7", "", "R", "19971106", "", "BUL", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-ROU-01A-2018-004", "", "1", "1"],
          ["20180528", "Romania F2", "Clay", "S", "L", "UNR", "", "Q", "R32", "3-6 6-1 6-2", "3", "Orlando Luz", "668", "", "", "R", "19980208", "", "BRA", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-ROU-02A-2018-014", "", "1", "1"],
          ["20180813", "Romania F9", "Clay", "S", "L", "UNR", "", "", "R32", "7-6(4) 2-6 6-3", "3", "Vasile Alexandru Ghilea", "983", "", "Q", "R", "19931231", "", "ROU", "1", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-ROU-09A-2018-010", "", "1", "1"],
          ["20180820", "Romania F10", "Clay", "S", "L", "UNR", "", "WC", "R16", "6-4 6-2", "3", "Mikhail Korovin", "796", "6", "", "R", "19960226", "", "RUS", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-ROU-10A-2018-020", "", "2", "2"],
          ["20180820", "Romania F10", "Clay", "S", "W", "UNR", "", "WC", "R32", "6-1 6-3", "3", "Gabi Adrian Boitan", "852", "", "", "U", "19990711", "", "ROU", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-ROU-10A-2018-007", "", "1", "1"]
          ];
