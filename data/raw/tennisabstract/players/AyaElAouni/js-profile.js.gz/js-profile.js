
    var fullname = 'Aya El Aouni';
    var lastname = 'El Aouni';
    var currentrank=1244;
    var peakrank=598;
    var peakfirst=20250127;
    var peaklast=20250127;
    var dob=20050706;
    
    var hand='U';
    var backhand='';
    var country='MAR';
    var shortlist=46;
    var careerjs=1;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='';
    var wta_id='';
    var fc_id='800530478';
    var wiki_id='';
    var blast_link='';
    var more_link='';
    var death_date="";
    var dob_approx="";
    var elo_rating='';
    var elo_rank='';
    var ychoices=["Time Span", "Last 52", "Career", "2025", "2024", "2023", "2022", "2021", "2020"];
var tchoices=["Event", "All", "Rabat", "W15 Antalya", "W15 Cairo", "W15 Casablanca", "W15 Duffel", "W15 Heraklion", "W15 Monastir", "W15 Wanfercee-Baulet", "W25 Heraklion", "W25 Perigueux", "W35 Antalya", "W35 Casablanca", "W35 Miami FL", "W35 Mohammedia", "W35 Norman OK", "W35 Palm Coast FL", "W50 Austin TX", "W50 Boca Raton FL"];
var cchoices=["vs Country", "All", "ARG", "AUT", "BDI", "BEL", "BRA", "BUL", "CHN", "CZE", "EGY", "ESP", "EST", "FRA", "GBR", "GEO", "GER", "GRE", "ITA", "JPN", "KAZ", "LAT", "LTU", "MAR", "NED", "NZL", "POL", "ROU", "RSA", "RUS", "SRB", "SUI", "SVK", "TUR", "USA"];
var rchoices=["as Rank", "All"];
var ochoices=["Valeriya Yushchenko", "Sofia Shapatava", "Sada Nahimana", "Rinko Matsuda", "Ilay Yoruk", "Edda Mamedova", "Claudia Hoste Ferrer", "Anastasiia Gureva", "Yasmine Kabbaj", "Yulia Putintseva", "Yujia Huang", "Whitney Osuigwe", "Vittoria Modesti", "Vicky Van De Peer", "Varvara Panshina", "Valentina Ivanov", "Tori Kinard", "Tiantsoa Sarah Rakotomanga Rajaonah", "Thaisa Grana Pedretti", "Stefania Bojica", "Sofia Rocchetti", "Sofia Costoulas", "Simona Ogescu", "Selina Dal", "Sara Dols", "Sapfo Sakellaridi", "Sandugash Kenzhibayeva", "Samira De Stefano", "Rositsa Dencheva", "Patricija Paukstyte", "Natalija Senic", "Mina Hodzic", "Milana Zhabrailova", "Mayar Sherif", "Marilyn Van Brempt", "Marija Semenistaja", "Marie Mettraux", "Maria Sara Popa", "Margaux Komano", "Margarita Skryabina", "Mara Guth", "Lucie Urbanova", "Liisa Varul", "Lauren Seye", "Lamis Alhussein Abdel Aziz", "Karolina Krajmer", "Julie Belgraver", "Jizel Matos Sequeira Fernandes", "Jamie Loeb", "Helena Buchwald", "Georgiana Francesca Prodan", "Francesca Pace", "Emma Lene", "Ema Harajda", "Ekaterina Ovcharenko", "Ekaterina Ivanova", "Diana Demidova", "Diae El Jardi", "Daniela Vismane", "Chelsea Fontenel", "Chantal Sauvant", "Barbora Michalkova", "Andrea Obradovic", "Andrea Lazaro Garcia", "Anca Alexia Todoni", "Ana Candiotto", "Amira Badawi", "Alina Granwehr", "Alexandra Shubladze", "Ada Piestrzynska", "Oriana Parkins Godwin", "Oana Gavrila", "Michelle Dzjachangirova", "Merna Refaat", "Maria Mikhailova", "Mai Elkamash", "Luisa Meyer Auf Der Heide", "Jana Elgebily", "Irina Dshandshgava", "Giulia Crescenzi", "Dalia Sherif", "Chanel Simmonds", "Barbora Matusova", "Anastasija Radojevic", "Anastasia Sukhotina", "Anastasia Mozgaleva", "Anastasia Evgenyevna Nefedova", "Alexandra Iordache", "Zoziya Kardava", "Zhibek Kulambayeva", "Salma Raslan", "Oumaima Aziz", "Noelia Bouzo Zanotti", "Nathalie Mokhtar", "Naima Karamoko", "Nadine Keller", "Midori Castillo Meza", "Ksenia Laskutova", "Jazmin Ortenzi", "Giuliana Bestetti", "Engy Abouelseoud", "Alisa Axyanova"];
var tdates=["20201123", "20201130", "20201207", "20210104", "20210111", "20210315", "20210322", "20210719", "20210726", "20210802", "20220704", "20220711", "20230410", "20230417", "20230522", "20230626", "20230717", "20230724", "20230814", "20230821", "20231016", "20231023", "20231127", "20231204", "20240122", "20240129", "20240205", "20240212", "20240304", "20240422", "20240429", "20240506", "20240520", "20240715", "20240722", "20240729", "20241028", "20241104", "20241111", "20241118", "20241209", "20241216", "20250113", "20250519", "20251215"];
var vranks=["61", "66", "259", "267", "275", "308", "324", "337", "342", "363", "378", "390", "450", "471", "502", "511", "533", "541", "546", "558", "561", "574", "576", "578", "593", "598", "601", "624", "635", "641", "657", "667", "672", "678", "679", "681", "682", "683", "685", "696", "700", "712", "714", "717", "736", "743", "771", "775", "783", "786", "788", "794", "798", "831", "861", "883", "917", "921", "940", "978", "994", "999", "1063", "1068", "1085", "1100", "1114", "1171", "1184", "1226", "1286", "1289", "1293", "1299", "1308", "1326", "1353", "1433"];
playernews = [];
var upcoming = "";
var matchmx = [["20240122", "W15 Antalya", "Clay", "15", "L", "832", "", "", "R16", "6-0 6-4", "3", "Andrea Lazaro Garcia", "471", "2", "", "R", "19941104", "", "ESP", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-003-208"],
          ["20240122", "W15 Antalya", "Clay", "15", "W", "832", "", "", "R32", "6-2 6-4", "3", "Margarita Skryabina", "", "", "Q", "U", "20000113", "", "RUS", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-003-115"],
          ["20240129", "W15 Antalya", "Clay", "15", "L", "832", "", "", "R16", "6-3 6-1", "3", "Rositsa Dencheva", "1114", "", "", "", "20070310", "", "BUL", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-004-206"],
          ["20240129", "W15 Antalya", "Clay", "15", "W", "832", "", "", "R32", "6-3 6-4", "3", "Sara Dols", "", "", "Q", "U", "20050509", "", "ESP", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-004-111"],
          ["20240205", "W35 Antalya", "Clay", "35", "L", "829", "", "", "Q1", "3-6 6-1 10-8", "3", "Sofia Shapatava", "574", "8", "", "R", "19890112", "170", "GEO", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-005-739"],
          ["20240212", "W35 Antalya", "Clay", "35", "L", "820", "", "Q", "R16", "4-6 6-0 6-3", "3", "Alexandra Shubladze", "593", "", "WC", "U", "20050906", "", "RUS", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-006-206"],
          ["20240212", "W35 Antalya", "Clay", "35", "W", "820", "", "Q", "R32", "6-3 6-1", "3", "Ekaterina Ovcharenko", "635", "", "Q", "R", "20001231", "", "RUS", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-006-111"],
          ["20240212", "W35 Antalya", "Clay", "35", "W", "820", "16", "", "Q1", "6-3 6-1", "3", "Ekaterina Ivanova", "1289", "", "", "R", "19871218", "", "RUS", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-006-730"],
          ["20240212", "W35 Antalya", "Clay", "35", "W", "820", "16", "", "Q2", "6-2 6-1", "3", "Barbora Michalkova", "", "", "", "U", "20060403", "", "CZE", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-006-820"],
          ["20240212", "W35 Antalya", "Clay", "35", "W", "820", "16", "", "Q3", "6-4 6-2", "3", "Ilay Yoruk", "502", "5", "", "R", "20011105", "", "TUR", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-006-915"],
          ["20240304", "W15 Monastir", "Hard", "15", "L", "781", "", "", "R16", "6-1 6-2", "3", "Sada Nahimana", "342", "1", "", "R", "20010421", "", "BDI", "0", "", "", "", "", "", "", "2024-W-ITF-TUN-2024-013-201"],
          ["20240304", "W15 Monastir", "Hard", "15", "W", "781", "", "", "R32", "6-3 6-1", "3", "Marija Semenistaja", "", "", "WC", "U", "", "", "LAT", "0", "", "", "", "", "", "", "2024-W-ITF-TUN-2024-013-102"],
          ["20240422", "W15 Antalya", "Clay", "15", "L", "782", "", "", "R32", "6-2 6-2", "3", "Mina Hodzic", "831", "", "", "R", "20020606", "", "GER", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-016-111"],
          ["20240429", "W15 Antalya", "Clay", "15", "W", "782", "6", "", "F", "2-6 7-6(5) 6-3", "3", "Valeriya Yushchenko", "775", "5", "", "R", "19990626", "", "RUS", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-017-501"],
          ["20240429", "W15 Antalya", "Clay", "15", "W", "782", "6", "", "QF", "1-6 7-5 7-6(2)", "3", "Ilay Yoruk", "511", "1", "", "R", "20011105", "", "TUR", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-017-301"],
          ["20240429", "W15 Antalya", "Clay", "15", "W", "782", "6", "", "R16", "6-3 6-1", "3", "Varvara Panshina", "", "", "Q", "U", "20060211", "", "RUS", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-017-202"],
          ["20240429", "W15 Antalya", "Clay", "15", "W", "782", "6", "", "R32", "6-0 6-2", "3", "Ema Harajda", "", "", "Q", "U", "20070607", "", "CZE", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-017-104"],
          ["20240429", "W15 Antalya", "Clay", "15", "W", "782", "6", "", "SF", "6-3 7-6(2)", "3", "Alina Granwehr", "771", "4", "", "U", "20030713", "", "SUI", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-017-401"],
          ["20240506", "W15 Antalya", "Clay", "15", "W", "788", "7", "", "F", "6-2 2-0 RET", "3", "Valeriya Yushchenko", "657", "6", "", "R", "19990626", "", "RUS", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-018-501"],
          ["20240506", "W15 Antalya", "Clay", "15", "W", "788", "7", "", "QF", "6-1 6-3", "3", "Claudia Hoste Ferrer", "683", "3", "", "U", "19981112", "", "ESP", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-018-303"],
          ["20240506", "W15 Antalya", "Clay", "15", "W", "788", "7", "", "R16", "6-0 6-2", "3", "Liisa Varul", "1326", "", "Q", "U", "", "", "EST", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-018-205"],
          ["20240506", "W15 Antalya", "Clay", "15", "W", "788", "7", "", "R32", "6-0 6-2", "3", "Georgiana Francesca Prodan", "", "", "WC", "U", "", "", "ROU", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-018-109"],
          ["20240506", "W15 Antalya", "Clay", "15", "W", "788", "7", "", "SF", "6-3 6-0", "3", "Sandugash Kenzhibayeva", "1171", "", "", "U", "20050318", "", "KAZ", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-018-402"],
          ["20240520", "Rabat", "Clay", "I", "L", "629", "", "WC", "R32", "6-2 6-1", "3", "Mayar Sherif", "66", "", "", "R", "19960505", "180", "EGY", "0", "72", "2", "1", "50", "45", "22", "1", "7", "6", "10", "0", "1", "52", "37", "28", "8", "8", "3", "3", "", "20240521-W-Rabat-R32-Mayar_Sherif-Aya_El_Aouni", "", "", "2024-1005-279"],
          ["20240715", "W15 Casablanca", "Clay", "15", "L", "618", "6", "", "R16", "6-4 3-6 6-2", "3", "Rinko Matsuda", "831", "", "", "U", "20050410", "", "JPN", "0", "", "", "", "", "", "", "2024-W-ITF-MAR-2024-001-202"],
          ["20240715", "W15 Casablanca", "Clay", "15", "W", "618", "6", "", "R32", "5-1 RET", "3", "Patricija Paukstyte", "717", "", "", "U", "20040913", "", "LTU", "0", "", "", "", "", "", "", "2024-W-ITF-MAR-2024-001-104"],
          ["20240722", "W35 Casablanca", "Clay", "35", "L", "623", "", "WC", "R32", "2-6 7-5 6-1", "3", "Sofia Costoulas", "275", "2", "", "U", "20050402", "", "BEL", "0", "", "", "", "", "", "", "2024-W-ITF-MAR-2024-003-116"],
          ["20240729", "W35 Mohammedia", "Clay", "35", "L", "624", "", "", "QF", "6-2 6-2", "3", "Emma Lene", "378", "4", "", "R", "19990715", "", "FRA", "0", "", "", "", "", "", "", "2024-W-ITF-MAR-2024-004-303"],
          ["20240729", "W35 Mohammedia", "Clay", "35", "W", "624", "", "", "R16", "6-2 6-2", "3", "Chelsea Fontenel", "1068", "", "Q", "U", "20040625", "", "SUI", "0", "", "", "", "", "", "", "2024-W-ITF-MAR-2024-004-205"],
          ["20240729", "W35 Mohammedia", "Clay", "35", "W", "624", "", "", "R32", "6-7(9) 6-2 6-0", "3", "Daniela Vismane", "390", "5", "", "R", "20000810", "", "LAT", "0", "", "", "", "", "", "", "2024-W-ITF-MAR-2024-004-109"],
          ["20241028", "W35 Norman OK", "Hard", "35", "L", "613", "8", "", "R32", "7-5 6-2", "3", "Valentina Ivanov", "861", "", "", "R", "20010327", "172", "NZL", "0", "", "", "", "", "", "", "2024-W-ITF-USA-2024-048-104"],
          ["20241104", "W35 Miami FL", "Hard", "35", "L", "669", "", "", "R32", "2-6 6-1 6-3", "3", "Thaisa Grana Pedretti", "546", "", "", "U", "19990515", "", "BRA", "0", "", "", "", "", "", "", "2024-W-ITF-USA-2024-049-111"],
          ["20241111", "W50 Austin TX", "Hard", "50", "L", "668", "8", "", "Q2", "7-5 6-4", "3", "Yujia Huang", "783", "11", "", "R", "20021118", "", "CHN", "0", "", "", "", "", "", "", "2024-W-ITF-USA-2024-051-818"],
          ["20241111", "W50 Austin TX", "Hard", "50", "W", "668", "8", "", "Q1", "6-7(9) 7-6(0) 6-1", "3", "Diae El Jardi", "", "", "", "R", "20001013", "", "MAR", "0", "", "", "", "", "", "", "2024-W-ITF-USA-2024-051-725"],
          ["20241118", "W50 Boca Raton FL", "Clay", "50", "L", "665", "", "", "R16", "3-6 6-2 6-3", "3", "Whitney Osuigwe", "324", "7", "", "R", "20020417", "168", "USA", "0", "", "", "", "", "", "", "2024-W-ITF-USA-2024-053-205"],
          ["20241118", "W50 Boca Raton FL", "Clay", "50", "W", "665", "", "", "R32", "6-7(2) 6-1 6-2", "3", "Tori Kinard", "999", "", "Q", "U", "19871124", "", "USA", "0", "", "", "", "", "", "", "2024-W-ITF-USA-2024-053-110"],
          ["20241209", "W15 Antalya", "Clay", "15", "L", "662", "8", "", "QF", "6-1 6-2", "3", "Chantal Sauvant", "578", "4", "", "U", "20020508", "", "GER", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-032-303"],
          ["20241209", "W15 Antalya", "Clay", "15", "W", "662", "8", "", "R16", "6-3 6-1", "3", "Stefania Bojica", "667", "", "", "U", "20050310", "", "ROU", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-032-205"],
          ["20241209", "W15 Antalya", "Clay", "15", "W", "662", "8", "", "R32", "2-6 6-4 6-1", "3", "Lucie Urbanova", "1293", "", "Q", "U", "20060214", "", "CZE", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-032-109"],
          ["20241216", "W15 Antalya", "Clay", "15", "L", "665", "7", "", "QF", "2-6 6-4 6-4", "3", "Sofia Shapatava", "541", "4", "", "R", "19890112", "170", "GEO", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-033-303"],
          ["20241216", "W15 Antalya", "Clay", "15", "W", "665", "7", "", "R16", "7-5 7-5", "3", "Yasmine Kabbaj", "798", "", "Q", "U", "20040115", "", "MAR", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-033-205"],
          ["20241216", "W15 Antalya", "Clay", "15", "W", "665", "7", "", "R32", "6-4 6-4", "3", "Edda Mamedova", "883", "", "Q", "U", "20061012", "", "RUS", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-033-109"],
          ["20250113", "W35 Palm Coast FL", "Clay", "35", "L", "620", "", "", "R16", "6-4 6-3", "3", "Julie Belgraver", "363", "", "", "R", "20020704", "", "FRA", "0", "101", "0", "0", "72", "52", "26", "11", "9", "8", "12", "5", "2", "59", "35", "21", "16", "10", "2", "4", "", "", "", "", "2025-W-ITF-USA-2025-002-208"],
          ["20250113", "W35 Palm Coast FL", "Clay", "35", "W", "620", "", "", "R32", "6-3 4-6 6-3", "3", "Jamie Loeb", "450", "", "", "R", "19950308", "168", "USA", "0", "168", "0", "4", "94", "67", "38", "12", "14", "5", "11", "0", "3", "105", "65", "34", "16", "14", "10", "18", "", "", "", "", "2025-W-ITF-USA-2025-002-115"],
          ["20250519", "Rabat", "Clay", "I", "L", "835", "", "WC", "R32", "6-3 6-2", "3", "Sada Nahimana", "267", "", "Q", "R", "20010421", "", "BDI", "0", "84", "1", "4", "55", "42", "23", "3", "8", "4", "9", "3", "3", "63", "42", "32", "6", "9", "5", "7", "", "", "", "", "2025-1005-284"],
          ["20251215", "W15 Antalya", "Clay", "15", "L", "1078", "", "", "R32", "7-5 1-0", "3", "Rinko Matsuda", "533", "", "", "U", "20050410", "", "JPN", "0", "78", "0", "2", "58", "50", "26", "3", "7", "10", "14", "3", "1", "39", "28", "19", "5", "7", "2", "4", "", "", "", "", "2025-W-ITF-TUR-2025-041-116"]
          ];
