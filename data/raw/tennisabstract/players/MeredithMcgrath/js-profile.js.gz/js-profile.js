
    var fullname = 'Meredith Mcgrath';
    var lastname = 'Mcgrath';
    var currentrank="";
    var peakrank=18;
    var peakfirst=19960722;
    var peaklast=19960812;
    var dob=19710428;
    
    var hand='U';
    var backhand='';
    var country='USA';
    var shortlist=7;
    var careerjs=1;
    var active=0;
    var lastdate=19980223;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='20000476';
    var wta_id='5080/title/meredith-mcgrath';
    var fc_id='';
    var wiki_id='Meredith_McGrath';
    var blast_link='';
    var more_link='';
    var death_date="";
    var dob_approx="";
    var ychoices=["Time Span", "Last 52", "Career", "1998", "1996", "1995", "1994", "1993", "1992", "1991", "1990", "1989", "1988"];
var tchoices=["Event", "All", "Australian Open", "French Open", "Wimbledon", "US Open", "Albuquerque", "Amelia Island", "Birmingham", "Boca Raton", "Canadian Open", "Chicago", "Delray Beach", "Dorado", "Eastbourne", "Filderstadt", "Geneva", "Hamburg", "ITF Evansville", "ITF Fayetteville", "ITF Midland", "ITF Midland 2", "Indian Wells", "Indianapolis", "Key Biscayne", "Kuala Lumpur", "Leipzig", "Linz", "Lucerne", "Mahwah", "Montpellier", "Montreal", "Moscow", "Nashville", "Newport", "Oakland", "Oklahoma", "Paris", "Pattaya", "Philadelphia", "Roland Garros", "Rome", "Schenectady", "Scottsdale", "Singapore", "Sydney", "Toronto", "Wichita", "Wimbledon Plate", "Worcester", "Zurich", "ITF Midland 25K", "Midland 50K"];
var cchoices=["vs Country", "All", "ARG", "AUS", "AUT", "BEL", "BLR", "BUL", "CAN", "CHN", "CRO", "CZE", "ESP", "FRA", "GBR", "GER", "HKG", "HUN", "INA", "ISR", "ITA", "JPN", "MAD", "MEX", "NED", "NZL", "PER", "POL", "RSA", "RUS", "SLO", "SUI", "SVK", "SWE", "TPE", "UKR", "URS", "USA"];
var rchoices=["as Rank", "All", "Top 50", "Top 100", "Top 200", "51+", "101+", "201+"];
var ochoices=["Brenda Schultz Mccarthy", "Steffi Graf", "Nathalie Tauziat", "Jana Novotna", "Claudia Porwik", "Amy Frazier", "Tina Krizan", "Sophie Amiach", "Shaun Stafford", "Rene Simpson", "Natalia Zvereva", "Nancy Feber", "Mary Joe Fernandez", "Martina Navratilova", "Helen Kelesi", "Els Callens", "Chanda Rubin", "Arantxa Sanchez Vicario", "Amanda Coetzer", "Zina Garrison", "Wiltrud Probst", "Sonya Jeyaseelan", "Sandra Cecchini", "Romana Tedjakusuma", "Raffaella Reggi Concato", "Patricia Hy Boulais", "Pascale Paradis Mangon", "Pam Shriver", "Natalia Medvedeva", "Miriam Oremans", "Melissa Mazzotta", "Meilen Tu", "Martina Hingis", "Manon Bollegraf", "Lindsay Davenport", "Linda Wild", "Larisa Savchenko", "Kristine Kunce", "Judith Wiesner", "Jessica Emmons", "Jennifer Capriati", "Hu Na", "Gabriela Sabatini", "Florencia Labat", "Dally Randriantefy", "Barbara Paulus", "Ann Grossman", "Angelica Gavaldon", "Yuka Yoshida", "Yayuk Basuki", "Yael Segal", "Wendy White", "Trisha Laux", "Titia Wilmink", "Tessa Price", "Tammy Whittington", "Tami Whitlinger Jones", "Sylvia Hanika", "Susi Fortun Lohrmann", "Susan Sloane Lundy", "Stacey Martin", "Silke Frankl", "Shannan Mccarthy", "Shandra Livingston", "Sara Gomer", "Sandy Collins", "Samantha Reeves", "Sabine Haas", "Rosalyn Fairbank", "Robin White", "Rita Grande", "Petra Schwarz", "Petra Begerow", "Patty Schnyder", "Patty Fendick", "Nicole Bradtke", "Naoko Sawamatsu", "Monica Seles", "Melissa Gurney", "Megan Miller", "Masako Yanagi", "Mary Lou Piatek", "Marianne Werdel Witmeyer", "Mariaan De Swardt", "Mana Endo", "Maja Palaversic", "Magdalena Maleeva", "Luanne Spadea", "Louise Field", "Lori Mcneil", "Liz Smylie", "Lisa Bonder Kreiss", "Linda Ferrando", "Laurence Courtois", "Laura Golarsa", "Laura Arraya", "Kristin Godridge", "Kristie Boogert", "Kimiko Date Krumm", "Kimberly Po Messerli", "Kathy Rinaldi Stunkel", "Kathy Foxworth", "Katerina Maleeva", "Katarzyna Nowak", "Katarina Studenikova", "Karine Quentrec", "Karen Schimper", "Julie Steven", "Julie Pullin", "Joannette Kruger", "Jillian Alexander Brower", "Jenny Klitch", "Jennifer Santrock", "Janet Lee", "Jane Chi", "Jana Nejedly", "Jana Kandarr", "Iva Majoli", "Ines Heise", "Helena Sukova", "Gloria Pizzichini", "Federica Haumuller", "Federica Bonsignori", "Fang Li", "Eva Martincova", "Emmanuelle Derly", "Elena Makarova", "Elena Likhovtseva", "Elena Brioukhovets", "Donna Faber", "Dominique Monami", "Dianne Van Rensburg", "Danielle Jones", "Cristina Salvi", "Catrin Jexell", "Carrie Cunningham", "Caroline Kuhlman", "Caroline Billingham", "Candy Reynolds", "Beverly Bowes", "Beth Herr", "Belinda Cordwell", "Barbara Potter", "Ayako Hirose", "Asa Carlsson", "Annabel Ellwood", "Anke Huber", "Andrea Temesvari", "Andrea Farley", "Aleksandra Olsza", "Akiko Kijimuta"];
var tdates=["19880229", "19880606", "19880718", "19880725", "19881031", "19890206", "19890220", "19890227", "19890320", "19890522", "19890529", "19890612", "19890626", "19890703", "19890717", "19890821", "19890828", "19891106", "19900205", "19900226", "19900316", "19900611", "19900618", "19900625", "19900716", "19900806", "19900827", "19901015", "19901022", "19901029", "19901105", "19910128", "19910211", "19910218", "19910304", "19910315", "19910527", "19910610", "19920302", "19920313", "19930201", "19930215", "19930301", "19930312", "19930412", "19930419", "19930517", "19930524", "19930607", "19930621", "19930816", "19930830", "19930927", "19931011", "19931101", "19940110", "19940117", "19940131", "19940214", "19940311", "19940411", "19940418", "19940516", "19940523", "19940606", "19940613", "19940620", "19940815", "19940822", "19940829", "19940926", "19941003", "19941010", "19941031", "19941107", "19950109", "19950116", "19950214", "19950220", "19950317", "19950501", "19950508", "19950529", "19950612", "19950626", "19950814", "19950828", "19950918", "19951009", "19951106", "19960115", "19960213", "19960226", "19960321", "19960408", "19960527", "19960610", "19960618", "19960624", "19961028", "19980119", "19980210", "19980223"];
var vranks=["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "32", "35", "36", "37", "39", "40", "42", "43", "44", "45", "48", "50", "52", "53", "55", "56", "57", "58", "59", "61", "63", "64", "65", "69", "70", "71", "72", "73", "74", "75", "76", "78", "79", "82", "83", "86", "87", "90", "92", "93", "94", "95", "96", "98", "99", "100", "101", "102", "103", "104", "105", "106", "107", "108", "109", "112", "113", "114", "116", "117", "120", "121", "122", "123", "124", "126", "127", "130", "132", "133", "134", "138", "142", "147", "148", "149", "150", "151", "152", "154", "156", "159", "167", "170", "171", "173", "175", "181", "182", "188", "189", "196", "197", "204", "207", "209", "211", "218", "234", "240", "242", "246", "252", "262", "311", "321", "322", "330", "335", "357", "358", "391", "392", "430", "490", "507", "636"];
var playernews=["<b>24 Nov</b> <a href=\"http://www.tennisabstract.com/charting/19960704-W-Wimbledon-SF-Meredith_Mcgrath-Arantxa_Sanchez_Vicario.html\" target=\"new\">The Match Charting Project: 1996 Wimbledon SF: Meredith Mcgrath vs Arantxa Sanchez Vicario</a>: <i>Point-by-point serve, return, and rally analysis for every shot in</i><a href=\"http://www.tennisabstract.com/charting/19960704-W-Wimbledon-SF-Meredith_Mcgrath-Arantxa_Sanchez_Vicario.html\" target=\"new\">...</a>"];
var upcoming = "";
var matchmx = [["19980223", "Oklahoma", "Hard", "W", "L", "", "", "", "R16", "W/O", "3", "Joannette Kruger", "27", "4", "", "R", "19730903", "", "RSA", "0", "", "", "", "", "", "", "1998-W-WT-USA-01A-1998-020"],
          ["19980223", "Oklahoma", "Hard", "W", "W", "", "", "", "R32", "6-3 5-7 6-2", "3", "Patricia Hy Boulais", "70", "", "", "U", "19650822", "", "CAN", "0", "", "", "", "", "", "", "1998-W-WT-USA-01A-1998-010"],
          ["19980210", "Midland 50K", "Hard", "50", "L", "", "", "WC", "SF", "3-0 RET", "3", "Samantha Reeves", "122", "", "WC", "R", "19790117", "", "USA", "0", "", "", "", "", "", "", "1998-W-C50-USA-01A-1998-029"],
          ["19980210", "Midland 50K", "Hard", "50", "W", "", "", "WC", "QF", "7-5 6-3", "3", "Aleksandra Olsza", "138", "", "", "U", "19771208", "", "POL", "0", "", "", "", "", "", "", "1998-W-C50-USA-01A-1998-025"],
          ["19980210", "Midland 50K", "Hard", "50", "W", "", "", "WC", "R16", "6-4 6-2", "3", "Jane Chi", "252", "", "Q", "R", "19740621", "", "USA", "0", "", "", "", "", "", "", "1998-W-C50-USA-01A-1998-018"],
          ["19980210", "Midland 50K", "Hard", "50", "W", "", "", "WC", "R32", "2-6 6-2 6-4", "3", "Sonya Jeyaseelan", "90", "7", "", "R", "19760424", "", "CAN", "0", "", "", "", "", "", "", "1998-W-C50-USA-01A-1998-004"],
          ["19980119", "Australian Open", "Hard", "G", "L", "", "", "SR", "R128", "6-1 6-3", "3", "Yuka Yoshida", "70", "", "", "R", "19760401", "", "JPN", "0", "", "", "", "", "", "", "1998-W-SL-AUS-01A-1998-011"]
          ];
