
    var fullname = 'Elena Giessler';
    var lastname = 'Giessler';
    var currentrank=1228;
    var peakrank=1228;
    var peakfirst=20260330;
    var peaklast=20260330;
    var dob=20021221;
    
    var hand='R';
    var backhand='2';
    var country='GER';
    var shortlist=10;
    var careerjs=1;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100271481';
    var wta_id='';
    var fc_id='';
    var wiki_id='';
    var blast_link='';
    var more_link='';
    var death_date="";
    var dob_approx="";
    var elo_rating='';
    var elo_rank='';
    var ychoices=["Time Span", "Last 52", "Career", "2025", "2024", "2023", "2022", "2021", "2019"];
var tchoices=["Event", "All", "W15 Antalya", "W15 Bydgoszcz", "W15 CEUTA", "W15 Cairo", "W15 Castellon", "W15 Denia", "W15 Don Benito", "W15 Gurugram", "W15 Heraklion", "W15 Jhajjar", "W15 Malaga", "W15 Manacor", "W15 Melilla", "W15 Monastir", "W15 Monzon", "W15 Norrkoping", "W15 Nules", "W15 Sabadell", "W15 Santa Margarita de Montbui", "W15 Sharm El Sheikh", "W15 Tabarka", "W15 Telde", "W15 Valencia", "W15 Villena", "W25 Ceuta", "W25 Madrid", "W25 Marbella", "W25 Platja D'Aro", "W25 Santa Margherita di Pula", "W25 Valladolid", "W25 Yecla", "W25 Zaragoza", "W25+H Tossa de Mar", "W35 Aschaffenburg", "W35 Horb", "W35 Klosters", "W35 Platja D'Aro", "W35 Stuttgart-Vaihingen", "W35 Yecla", "W50 Montemor-o-Novo", "W50 Yecla", "W50+H Palma del Río"];
var cchoices=["vs Country", "All", "ARG", "BEL", "BRA", "BUL", "CAN", "CHI", "CHN", "CZE", "DEN", "EGY", "ESP", "FRA", "GBR", "GER", "GRE", "IND", "ITA", "JPN", "KAZ", "KOR", "LTU", "MEX", "NED", "NZL", "POL", "POR", "ROU", "RSA", "RUS", "SUI", "SWE", "UKR", "USA"];
var rchoices=["as Rank", "All"];
var ochoices=["Isabel Skoog", "Mina Hodzic", "Jimar Geraldine Gerald Gonzalez", "Giorgia Pinto", "Carmen Garri Murcia", "Vasilisa Borisova", "Suhani Patil", "Shuqian Xu", "Shannon Lam", "Sara Lanca", "Rinko Matsuda", "Paula Arias Manjon", "Patricija Paukstyte", "Nina Radovanovic", "Marine Szostak", "Mariia Kostiuk", "Mariia Bergen", "Maria Aran Teixido Garcia", "Lucia Cortez Llorca", "Luana Plaza", "Laura Boehner", "Lara Russiniello", "Jasmijn Gimbrere", "Giulia Alternini", "Ester Ivaldo", "Diletta Cherubini", "Dia Evtimova", "Cristina Diaz Adrover", "Claudia Ferrer Perez", "Celia Anson Sanchez", "Carolina Troiano", "Arlinda Rushiti", "Arina Gabriela Vasilescu", "Anastasia Mozgaleva", "Victoria Lazarova", "Victoria Gomez", "Vanja Gudelj", "Tomoe Yazawa", "Tilde Stromquist", "Stella Beldiman", "Sofia Camila Rojas", "Pooja Ingale", "Patricia Rodriguez Carretero", "Pari Singh", "Nina Ugrelidze", "Marina Benito", "Malika Kabdesh", "Luisa Hrda", "Lidia Moreno Arias", "Laia Petretic", "Kira Pavlova", "Kashish Bhatia", "Kanupriya Rajawat", "Julie Myatovic", "Julia Lovqvist", "Jasmine Conway", "Harsshali Mandavkar", "Hanne Vandewinkel", "Farhat Aleen Qamar", "Eugenia Jazmin Ceinos", "Dariia Monakhova", "Claudia Sofia Martinez Solis", "Chiara Di Genova", "Carla Fity", "Bianca Jolie Fernandez", "Arina Arifullina", "Ariadna Briones Ginesta", "Annika Kannan", "Anna Wise", "Anna Kislyak", "Anastasiia Firman", "Aleksandra Julia Zuchanska", "Zuzanna Frankowska", "Valentina Ryser", "Thanh Lan Truong", "Tea Pavlicic", "Stefana Lazar", "Sophie Luescher", "Sofia Sewing", "Shona Nakano", "Rebeca Maria Tudose", "Polina Gubina", "Pilar Astigarraga Harper", "Olivia Gram", "Nour Adel", "Neila Trklja", "Maria Sysoeva", "Maja Bajorek", "Lola Mireille Glantz", "Karola Patricia Bejenaru", "Jana Rovira Alier", "Irene Lavino", "Ilaria Sposetti", "Fernanda Rain Contreras", "Fangran Tian", "Eun Ji Lee", "Esther Lopez Alcaraz", "Emily Di Giannantonio", "Ema Harajda", "Daria Yesypchuk", "Cecilie Wiche", "Camille Moga", "Beatrice Ricci", "Anna Klasen", "Anna Arkadianou", "Adele Burato"];
var tdates=["20190708", "20190715", "20210201", "20210906", "20210913", "20211101", "20211108", "20211115", "20211122", "20220207", "20220502", "20220516", "20220523", "20220711", "20220815", "20220822", "20220905", "20220912", "20220926", "20221003", "20221017", "20221024", "20221114", "20221205", "20230206", "20230213", "20230220", "20230410", "20230417", "20230424", "20230508", "20230522", "20230529", "20230605", "20230828", "20230904", "20230918", "20231009", "20231016", "20231023", "20231106", "20231113", "20231127", "20231204", "20231211", "20240212", "20240219", "20240226", "20240318", "20240401", "20240408", "20240415", "20240429", "20240506", "20240527", "20240603", "20240624", "20240701", "20240708", "20240722", "20250428", "20250512", "20250623", "20250901", "20250915", "20251103", "20251201"];
var vranks=["365", "443", "527", "563", "579", "598", "629", "644", "645", "695", "703", "724", "747", "748", "751", "768", "787", "828", "865", "866", "878", "908", "924", "931", "940", "1048", "1064", "1067", "1095", "1112", "1127", "1193", "1209", "1242", "1257", "1265", "1274"];
playernews = [];
var upcoming = "";
var matchmx = [["20250428", "W50 Yecla", "Hard", "50", "L", "", "", "", "R32", "6-1 6-0", "3", "Marine Szostak", "579", "", "", "U", "20020102", "", "FRA", "0", "46", "0", "2", "42", "29", "11", "3", "7", "7", "13", "2", "4", "37", "22", "18", "8", "6", "1", "1", "", "", "", "", "2025-W-ITF-ESP-2025-015-111"],
          ["20250512", "W15 Monzon", "Hard", "15", "L", "1369", "", "", "R16", "6-3 6-4", "3", "Claudia Ferrer Perez", "1265", "", "", "U", "20060714", "", "ESP", "0", "88", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2025-W-ITF-ESP-2025-014-201"],
          ["20250512", "W15 Monzon", "Hard", "15", "W", "1369", "", "", "R32", "6-4 6-1", "3", "Celia Anson Sanchez", "", "", "", "U", "", "", "ESP", "0", "92", "3", "3", "51", "33", "22", "10", "8", "3", "5", "0", "4", "59", "41", "21", "6", "9", "7", "13", "", "", "", "", "2025-W-ITF-ESP-2025-014-102"],
          ["20250623", "W50+H Palma del Río", "Hard", "50+H", "L", "1391", "", "", "R32", "6-4 6-3", "3", "Diletta Cherubini", "443", "", "", "U", "20020509", "", "ITA", "0", "90", "1", "4", "54", "26", "17", "15", "8", "3", "4", "1", "1", "37", "27", "23", "6", "7", "0", "0", "", "20250623-W-ITF_Palma_Del_Rio-R32-Elena_Giessler-Diletta_Cherubini", "", "", "2025-W-ITF-ESP-2025-017-107"],
          ["20250901", "W15 Denia", "Clay", "15", "L", "1272", "", "", "R16", "6-3 6-4", "3", "Isabel Skoog", "", "", "", "U", "", "", "SWE", "0", "93", "1", "6", "62", "34", "17", "10", "9", "3", "9", "0", "4", "69", "49", "30", "7", "10", "8", "12", "", "", "", "", "2025-W-ITF-ESP-2025-034-206"],
          ["20250901", "W15 Denia", "Clay", "15", "W", "1272", "", "", "R32", "6-4 6-0", "3", "Shannon Lam", "", "", "", "U", "20080607", "", "USA", "0", "105", "3", "5", "72", "41", "27", "14", "8", "7", "9", "0", "8", "61", "38", "22", "4", "8", "3", "9", "", "", "", "", "2025-W-ITF-ESP-2025-034-111"],
          ["20250915", "W15 CEUTA", "Hard", "15", "L", "1242", "", "", "R32", "6-2 6-1", "3", "Maria Aran Teixido Garcia", "878", "", "", "U", "20010117", "", "ESP", "0", "79", "1", "9", "52", "29", "17", "4", "8", "4", "10", "4", "3", "45", "34", "24", "6", "7", "0", "1", "", "", "", "", "2025-W-ITF-ESP-2025-035-116"],
          ["20251103", "W15 Castellon", "Clay", "15", "L", "1264", "", "", "R32", "6-3 6-0", "3", "Cristina Diaz Adrover", "365", "", "", "U", "20051203", "", "ESP", "0", "72", "0", "0", "39", "27", "9", "4", "7", "4", "10", "0", "0", "40", "34", "24", "3", "8", "2", "4", "", "", "", "", "2025-W-ITF-ESP-2025-043-101"],
          ["20251201", "W15 Melilla", "clay", "15", "L", "1268", "", "", "R16", "6-1 6-1", "3", "Lucia Cortez Llorca", "598", "", "", "U", "20000605", "", "ESP", "0", "73", "0", "3", "44", "27", "10", "6", "7", "1", "7", "0", "2", "44", "28", "18", "10", "7", "3", "4", "", "", "", "", "2025-W-ITF-ESP-2025-039-208"],
          ["20251201", "W15 Melilla", "clay", "15", "W", "1268", "", "", "R32", "6-0 2-0", "3", "Laura Boehner", "1242", "", "", "U", "20010730", "", "GER", "0", "71", "0", "1", "35", "23", "16", "6", "4", "3", "3", "1", "2", "44", "30", "14", "3", "5", "9", "13", "", "", "", "", "2025-W-ITF-ESP-2025-039-115"]
          ];
