
    var fullname = 'Jiri Lehecka';
    var lastname = 'Lehecka';
    var currentrank=1843;
    var peakrank=1738;
    var peakfirst=20181119;
    var peaklast=20181119;
    var dob=20011108;
    
    var hand='R';
    var backhand='';
    var country='CZE';
    var shortlist=9;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs=1510;
    var peak_dubs=1510;
    var peakfirst_dubs=20181126;
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100239663';
    var atp_id='';
    var dc_id='';
    var wiki_id='';
    var ychoices=["Time Span", "Last 52", "Career", "2018"];
var tchoices=["Event", "All"];
var cchoices=["vs Country", "All", "CZE", "GER", "POL", "RUS"];
var rchoices=["as Rank", "All"];
var ochoices=["Wojciech Marek", "Valentin Guenther", "Tomas Machac", "Petr Nouza", "Ondrej Krstev", "Michael Vrbensky", "Filip Duda", "Dominik Kellovsky", "Artem Dubrivnyy"];
var tdates=["20180521", "20181105", "20181112", "20181119"];
var vranks=["503", "604", "684", "814", "823", "965", "1050", "1110", "1840"];
playernews = [];
var upcoming = "";
var matchmx = [["20180521", "Czech Republic F2", "Clay", "S", "L", "UNR", "", "", "R32", "5-7 6-1 6-4", "3", "Dominik Kellovsky", "823", "", "", "U", "19960724", "", "CZE", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-CZE-02A-2018-007", "", "1", "1"],
          ["20181105", "Czech Republic F9", "Hard", "S", "L", "UNR", "", "", "R16", "7-6(4) 4-6 6-4", "3", "Petr Nouza", "684", "6", "", "U", "19980909", "", "CZE", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-CZE-09A-2018-020", "", "2", "2"],
          ["20181105", "Czech Republic F9", "Hard", "S", "W", "UNR", "", "", "R32", "6-2 RET", "3", "Filip Duda", "965", "", "", "U", "19980930", "", "CZE", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-CZE-09A-2018-007", "", "1", "1"],
          ["20181112", "Czech Republic F10", "Hard", "S", "L", "UNR", "", "", "R32", "5-7 6-3 6-1", "3", "Ondrej Krstev", "1110", "", "Q", "L", "19970613", "", "CZE", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-CZE-10A-2018-010", "", "1", "1"],
          ["20181119", "Czech Republic F11", "Hard", "S", "L", "1738", "", "", "F", "W/O", "3", "Tomas Machac", "814", "", "Q", "R", "20001013", "", "CZE", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-CZE-11A-2018-031", "", "", ""],
          ["20181119", "Czech Republic F11", "Hard", "S", "W", "1738", "", "", "QF", "6-1 4-6 7-5", "3", "Wojciech Marek", "1840", "", "Q", "R", "20010527", "", "POL", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-CZE-11A-2018-027", "", "3", "3"],
          ["20181119", "Czech Republic F11", "Hard", "S", "W", "1738", "", "", "R16", "6-1 6-3", "3", "Valentin Guenther", "1050", "", "", "R", "19980214", "", "GER", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-CZE-11A-2018-022", "", "2", "2"],
          ["20181119", "Czech Republic F11", "Hard", "S", "W", "1738", "", "", "R32", "6-3 7-6(5)", "3", "Michael Vrbensky", "503", "3", "", "U", "19991226", "", "CZE", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-CZE-11A-2018-012", "", "1", "1"],
          ["20181119", "Czech Republic F11", "Hard", "S", "W", "1738", "", "", "SF", "W/O", "3", "Artem Dubrivnyy", "604", "", "", "U", "19990131", "", "RUS", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-CZE-11A-2018-030", "", "", ""]
          ];
