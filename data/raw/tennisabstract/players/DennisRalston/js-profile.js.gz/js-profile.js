
    var fullname = 'Dennis Ralston';
    var lastname = 'Ralston';
    var currentrank="";
    var peakrank=115;
    var peakfirst=19730823;
    var peaklast=19730823;
    var dob=19420727;
    var ht=188;
    var hand='R';
    var country='USA';
    var shortlist=4;
    var careerjs=1;
    var active=0;
    var lastdate=19800602;
    var ychoices=["Time Span", "Last 52", "Career", "1980", "1978", "1977", "1976", "1975", "1974", "1973", "1972", "1971", "1970", "1969", "1968", "1966", "1965", "1964", "1963", "1962", "1961", "1960", "1959", "1958"];
var tchoices=["Event", "All", "Davis Cup", "Aptos", "Australian Open", "Berkeley", "Birmingham", "Boca Raton", "Boston", "Casablanca WCT", "Charlotte", "Chicago WCT", "Columbus WCT", "Dallas WCT", "Fort Worth WCT", "Gstaad", "Lacosta WCT", "Las Vegas", "Los Angeles", "Louisville", "Louisville WCT", "Manchester", "Maui", "Miami WCT", "Monte Carlo", "Montreal Toronto", "Palm Desert WCT", "Palm Springs", "Paris Indoor", "Philadelphia WCT", "Queen's Club", "Richmond", "Roland Garros", "Rome", "Sacramento", "Salisbury", "San Francisco", "St Louis WCT", "Stockholm Open", "Tehran WCT", "Toronto WCT", "Tuscon", "US Open", "Washington", "Washington WCT", "Washington WTC", "Wimbledon"];
var cchoices=["vs Country", "All", "ARG", "AUS", "AUT", "BRA", "CAN", "CHI", "COL", "CRO", "CZE", "DEN", "ECU", "EGY", "ESP", "FRA", "GBR", "GER", "HUN", "IND", "ITA", "JAM", "MEX", "NED", "NOR", "NZL", "PAK", "PHI", "ROU", "RSA", "RUS", "SUI", "SWE", "UNK", "USA", "VEN"];
var rchoices=["as Rank", "All"];
var ochoices=["Roy Emerson", "Rod Laver", "Raymond Moore", "Fred Stolle", "Cliff Drysdale", "Tom Okker", "Marty Riessen", "Tony Roche", "Rafael Osuna", "John Newcombe", "Arthur Ashe", "Stan Smith", "Ron Holmberg", "Joaquin Loyo Mayo", "Graham Stilwell", "Colin Dibley", "Cliff Richey", "Bob Hewitt", "Bob Carmichael", "Alex Metreveli", "Trey Waltke", "Tony Palafox", "Tom Gorman", "Thomaz Koch", "Roy Barth", "Robert Lutz", "Ramanathan Krishnan", "Phil Dent", "Patrick Proisy", "Patricio Rodriguez CHI", "Owen Davidson", "Martin Mulligan", "Ken Rosewall", "Juan Manuel Couder", "John Lloyd", "Jim Mcmanus", "Jeff Borowiak", "Jean Baptiste Chanfreau", "Jan Kodes", "Jan Eric Lundquist", "Jaime Fillol", "Ian Fletcher", "Haroon Rahim", "Georges Goven", "Frank Froehling", "D Richard Russell", "Charlie Pasarell", "Allan Stone", "Zeljko Franulovic", "William Alvarez", "Whitney Reed", "Walter Johnson", "Vladimir Zednik", "U Unknown", "Torben Ulrich", "Tony Pickard", "Tom Mozur", "Tom Leonard", "Tim Gullikson", "Thorvald Moe", "Terry Ryan", "Terry Addison", "Syd Ball", "Steve Shaw", "Sherwood Stewart", "Sergei Likhachev", "Ronnie Barnes", "Roger Taylor", "Robert Wilson", "Robert Maud", "Red Sledge Jr", "Raymundo Deyro", "Rauty Krog", "Pierre Darmon", "Pancho Walthall", "Ove Nils Bengtson", "Orlando Bracamonte", "Onny Parun", "Nikola Pilic", "Nicola Pietrangeli", "Nick Saviano", "Neale Fraser", "Milan Holecek", "Mike Estep", "Miguel Olvera", "Michele Leclercq", "Michael Sangster", "Mathias Werren", "Mark Cox", "Manuel Santana", "Laci Legenstein", "Kim Warwick", "Ken Stuart", "Keith Diepraam", "Keith Carpenter", "Juan Gisbert", "Jose Mandarino", "John S Evans", "John E Sharpe", "John Brown", "John Andrews", "John Alexander", "Jimmy Connors", "Jean Loup Rouyer", "Jasjit Singh", "Jan Kukal", "James W Hobson", "Jaime Pinto Bravo", "Iyo Pimentel", "Istvan Gulyas", "Ismail El Shafei", "Ion Tiriac", "Ingo Buding", "Ilie Nastase", "Hamilton Richardson", "Guillermo Vilas", "Grover Raz Reid", "Gerard Pilet", "Gerald Battrick", "Geoff Masters", "Frew Mcmillan", "Fred Mcnair", "Francois Jauffret", "Francois Godbout", "Earl Butch Buchholz", "E Victor Seixas", "Dick Sorlein", "Crawford I Henry", "Colin Stubs", "Clark Graebner", "Chum Steele Iii", "Chiraid Mukherjea", "Chauncey Steele Iii", "Brian Fairlie", "Boro Jovanovic", "Bob Mark", "Bernard Paul", "Bernard Montrenaud", "B Geoff Knox", "Alvaro Fillol", "Adriano Panatta"];
var matchmx = [["19800602", "Manchester", "Grass", "A", "L", "UNR", "", "", "QF", "6-3 6-3", "3", "Stan Smith", "22", "3", "", "R", "19461214", "193", "USA", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""],
          ["19800602", "Manchester", "Grass", "A", "W", "UNR", "", "", "R16", "6-3 6-3", "3", "John Lloyd", "145", "", "", "R", "19540827", "178", "GBR", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""],
          ["19800602", "Manchester", "Grass", "A", "W", "UNR", "", "", "R32", "6-3 7-5", "3", "Trey Waltke", "89", "6", "", "R", "19550316", "173", "USA", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""],
          ["19800602", "Manchester", "Grass", "A", "W", "UNR", "", "", "R64", "6-1 6-1", "3", "Steve Shaw", "UNR", "", "", "R", "19630101", "190", "GBR", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""]
          ];
