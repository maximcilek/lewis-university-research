
    var fullname = 'Zachary Svajda';
    var lastname = 'Svajda';
    var currentrank=1843;
    var peakrank=1617;
    var peakfirst=20180924;
    var peaklast=20180924;
    var dob=20021129;
    
    var hand='U';
    var backhand='';
    var country='USA';
    var shortlist=4;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100321944';
    var atp_id='';
    var dc_id='';
    var wiki_id='';
    var ychoices=["Time Span", "Last 52", "Career", "2018"];
var tchoices=["Event", "All"];
var cchoices=["vs Country", "All", "BRA", "ESP", "GBR", "JPN"];
var rchoices=["as Rank", "All"];
var ochoices=["Takuto Niki", "Nicolas Moreno De Alboran", "Joao Lucas Reis Da Silva", "Jack Findel Hawkins"];
var tdates=["20180910", "20180917", "20181022"];
var vranks=["601", "612", "803"];
playernews = [];
var upcoming = "";
var matchmx = [["20180910", "USA F24", "Hard", "S", "L", "UNR", "", "WC", "R16", "6-0 2-6 6-2", "3", "Nicolas Moreno De Alboran", "UNR", "", "Q", "U", "19970714", "", "ESP", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-USA-24A-2018-017", "", "2", "2"],
          ["20180910", "USA F24", "Hard", "S", "W", "UNR", "", "WC", "R32", "6-3 6-4", "3", "Joao Lucas Reis Da Silva", "601", "", "", "R", "20000326", "", "BRA", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-USA-24A-2018-001", "", "1", "1"],
          ["20180917", "USA F25", "Hard", "S", "L", "UNR", "", "WC", "R32", "6-4 6-2", "3", "Takuto Niki", "612", "", "", "U", "19871012", "", "JPN", "1", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-USA-25A-2018-005", "", "1", "1"],
          ["20181022", "USA F28B", "Hard", "S", "L", "1727", "", "Q", "R32", "6-2 4-6 6-2", "3", "Jack Findel Hawkins", "803", "", "", "U", "19941006", "", "GBR", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-USA-28B-2018-007", "", "1", "1"]
          ];
