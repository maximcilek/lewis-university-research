
    var fullname = 'Adam Walton';
    var lastname = 'Walton';
    var currentrank="UNR";
    var peakrank=1473;
    var peakfirst=20170320;
    var peaklast=20170619;
    var dob=19990417;
    
    var hand='U';
    var backhand='';
    var country='AUS';
    var shortlist=9;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100236215';
    var atp_id='';
    var dc_id='';
    var wiki_id='';
    var ychoices=["Time Span", "Last 52", "Career", "2017", "2016", "2015"];
var tchoices=["Event", "All", "Canberra CH", "Knoxville Challenger"];
var cchoices=["vs Country", "All", "AUS", "BRA", "NZL", "USA"];
var rchoices=["as Rank", "All"];
var ochoices=["Patrick Flynn", "Nathan Eshmade", "Mislav Bosnjak", "Max Purcell", "Jarmere Jenkins", "Finn Tearney", "Bruno Santanna", "Brian Tran", "Blake Mott"];
var tdates=["20151005", "20151019", "20160111", "20160222", "20160926", "20161003", "20171106"];
var vranks=["378", "388", "491", "791", "811", "1500"];
playernews = [];
var upcoming = "";
var matchmx = [["20151005", "Australia F7", "Hard", "S", "L", "", "", "Q", "R32", "6-0 6-1", "3", "Finn Tearney", "491", "6", "", "R", "25.0212183436", "", "NZL", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2015-M-FU-AUS-07A-2015-004", "", "1", "1"],
          ["20151019", "Australia F9", "Hard", "S", "L", "", "", "WC", "R32", "6-2 6-2", "3", "Blake Mott", "791", "", "", "U", "19.4934976044", "", "AUS", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2015-M-FU-AUS-09A-2015-002", "", "1", "1"],
          ["20160111", "Canberra CH", "Hard", "C", "L", "", "", "WC", "Q1", "7-6(9) 6-2", "3", "Brian Tran", "", "", "WC", "U", "17.9000684463", "", "AUS", "0", "106", "2", "10", "86", "52", "29", "14", "10", "2", "7", "4", "0", "80", "43", "27", "19", "10", "7", "10", "", "", "", "", "2016-7393-256", "", "", ""],
          ["20160222", "Australia F1", "Hard", "S", "L", "", "", "WC", "R32", "3-6 6-3 6-4", "3", "Mislav Bosnjak", "", "", "Q", "U", "17.7193702943", "", "AUS", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2016-M-FU-AUS-01A-2016-010", "", "1", "1"],
          ["20160926", "Australia F6", "Hard", "S", "L", "", "", "WC", "R16", "6-3 6-1", "3", "Jarmere Jenkins", "811", "", "", "R", "25.8370978782", "", "USA", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "0", "2016-M-FU-AUS-06A-2016-020", "", "2", "2"],
          ["20160926", "Australia F6", "Hard", "S", "W", "", "", "WC", "R32", "2-6 6-4 7-6(5)", "3", "Nathan Eshmade", "1500", "", "Q", "U", "22.4421629021", "", "AUS", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "1", "2016-M-FU-AUS-06A-2016-007", "", "1", "1"],
          ["20161003", "Australia F7", "Hard", "S", "L", "", "", "WC", "R16", "6-4 6-4", "3", "Max Purcell", "388", "5", "", "U", "18.5023956194", "", "AUS", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "0", "2016-M-FU-AUS-07A-2016-020", "", "2", "2"],
          ["20161003", "Australia F7", "Hard", "S", "W", "", "", "WC", "R32", "6-3 6-1", "3", "Patrick Flynn", "", "", "Q", "R", "48.1314168378", "183", "AUS", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "1", "2016-M-FU-AUS-07A-2016-007", "", "1", "1"],
          ["20171106", "Knoxville Challenger", "Hard", "C", "L", "UNR", "", "WC", "Q1", "6-4 6-3", "3", "Bruno Santanna", "378", "6", "", "R", "19930712", "", "BRA", "1", "72", "1", "1", "61", "36", "22", "13", "10", "5", "9", "2", "3", "73", "55", "38", "7", "9", "3", "4", "2", "", "", "", "2017-0363-239", "", "", ""]
          ];
