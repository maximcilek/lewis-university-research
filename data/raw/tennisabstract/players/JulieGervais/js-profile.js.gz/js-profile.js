
    var fullname = 'Julie Gervais';
    var lastname = 'Gervais';
    var currentrank=1129;
    var peakrank=374;
    var peakfirst=20191118;
    var peaklast=20191118;
    var dob=19910722;
    
    var hand='U';
    var backhand='';
    var country='FRA';
    var shortlist=7;
    var careerjs=1;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100090835';
    var wta_id='14995/title/julie-gervais';
    var fc_id='';
    var wiki_id='';
    var blast_link='';
    var more_link='';
    var death_date="";
    var dob_approx="";
    var ychoices=["Time Span", "Last 52", "Career", "2022", "2021", "2020", "2019", "2018", "2017", "2016", "2015", "2012", "2011", "2010", "2009", "2008"];
var tchoices=["Event", "All", "Contrexeville 125", "Strasbourg", "W15 Fort-de-France (Martinique)", "W15 Stockholm", "W15 Wanfercee-Baulet", "W25 Calvi", "W25 Cherbourg en Cotentin", "W25 Denain", "W25 Grenoble", "W25 Koksijde", "W25 Leipzig", "W25 Macon", "W25 Montpellier", "W25 Palmela", "W25 Perigueux", "W25 Petange", "W25 Petit-Bourg (Guadeloupe)", "W25 Porto", "W25 Prague", "W25 Roehampton", "W25 St Etienne", "W60 Andrezieux Boutheon", "W60 Barcelona", "W60 Croissy Beaubourg", "W60 Wiesbaden", "W80 Cagnes Sur Mer", "Alkmaar $15K", "Amiens $15K", "Amiens 10K", "Amstelveen $15K", "Brussels 10K", "Cherboug en Cotentin $25K", "Dijon $10K", "Dijon 10K", "Equeurdreville $25K", "Glasgow $10K", "Grenoble 10K", "Hammamet $15K", "Heraklion $10K", "Joue Les Tours $25K", "Koksijde $25K", "Las Palmas de Gran Canaria $10K", "Le Havre $15K", "Lyon 10K", "Macon $10K", "Macon $15K", "Madrid $15K", "Mont-De-Marsan 25K", "Montpellier $25K", "Nantes $25K", "Navi Mumbai $25K", "Oeiras $15K", "Perigueux $25K", "Petange $15K", "Poitiers $80K", "Porto $15K", "Pune $25K", "Rebecq $10K", "Rebecq 10K", "Solapur $25K", "Stockholm $10K", "Stuttgart Stammheim $10K", "Valladolid 25K", "Wanfercee Baulet $15K", "Wiesbaden $25K", "Wirral $10K"];
var cchoices=["vs Country", "All", "BEL", "BLR", "BRA", "BUL", "CHN", "COL", "CZE", "DEN", "ECU", "ESP", "FIN", "FRA", "GBR", "GEO", "GER", "GRE", "HUN", "IND", "ISR", "ITA", "LAT", "LIE", "LUX", "MEX", "NED", "NOR", "POL", "ROU", "RUS", "SAM", "SLO", "SRB", "SUI", "SVK", "SWE", "THA", "TPE", "TUR", "UKR", "USA"];
var rchoices=["as Rank", "All"];
var ochoices=["Katharina Hobgarski", "Pemra Ozgen", "Arantxa Rus", "Tess Sugnaux", "Sofia Nami Samavati", "Selena Janicijevic", "Salma Djoubri", "Olga Saez Larra", "Myrtille Georges", "Magali Kempen", "Lilly Elida Haseth", "Eleonora Molinaro", "Chi Chi Scholl", "Astrid Wanja Brune Olsen", "Aliaksandra Sasnovich", "Victoria Larriere", "Valentini Grammatikopoulou", "Steffi Carruthers", "Samantha Murray", "Oceane Dodin", "Oana Georgeta Simion", "Mylene Halemai", "Miriam Kolodziejova", "Marina Melnikova", "Maria Marfutina", "Maia Lumsden", "Lucie Wargnier", "Lesley Pattinama Kerkhove", "Kelly Versteeg", "Katarzyna Kawa", "Julia Wachaczyk", "Harmony Tan", "Guiomar Maristany Zuleta De Reales", "Estelle Cascino", "Epiphany B Turner", "Elsa Pellegrinelli", "Charlotte Roemer", "Audrey Albie", "Anette Munozova", "Ana Sofia Sanchez", "Yue Yuan", "Vitalia Diatchenko", "Violette Huck", "Victoria Kan", "Tiffany William", "Tessah Andrianjafitrimo", "Tereza Mihalikova", "Tayisiya Morderger", "Syna Kayser", "Sviatlana Pirazhenka", "Suzan Lamens", "Stephanie Wagner", "Stephanie Vongsouthi", "Schena Benamar", "Sandra Ortevall", "Romy Koelzer", "Rocio De La Torre Sanchez", "Rebecca Sramkova", "Polina Vinogradova", "Polina Leykina", "Oona Orpana", "Nuria Brancaccio", "Nora Niedmers", "Noa Liauw A Fong", "Nicole Clerico", "Nathaly Kurata", "Mina Hodzic", "Mia Nicole Eklund", "Mathilde Devits", "Mathilde Armitano", "Marine Partaud", "Marie Temin", "Mariam Bolkvadze", "Maria Jose Luque Moreno", "Maria Fernanda Herazo Gonzalez", "Margot Yerolymos", "Marcella Koek", "Mallaurie Noel", "Mailyne Andrieux", "Magdalena Frech", "Luna Meers", "Lou Brouleau", "Lisa Matviyenko", "Linda Puppendahl", "Laura Schaeder", "Laura Deigman", "Lara Schmidt", "Lara Michel", "Ksenia Gaydarzhi", "Kristina Milenkovic", "Kimberley Zimmermann", "Katyarina Paulenka", "Katie Swan", "Kathinka Von Deichmann", "Katarzyna Piter", "Karman Thandi", "Julita Saner", "Juliette Bastin", "Julie Noe", "Julia Stamatova", "Joanna Garland", "Jacqueline Cabaj Awad", "Isabella Shinikova", "Iga Swiatek", "Ida Jarlskog", "Helen De Cesare", "Giorgia Marchetti", "Gioia Barbieri", "Gaelle Desperrier", "Francesca Jones", "Fiona Gervais", "Fiona Codino", "Fanny Ostlund", "Eva Guerrero Alvarez", "Emma Lene", "Emma Ek", "Emilie Francati", "Eliz Maloney", "Elitsa Kostova", "Eden Silva", "Diana Sumova", "Deniz Khazaniuk", "Dejana Radanovic", "Dana Kremer", "Dalila Jakupovic", "Clothilde De Bernardi", "Chantal Skamlova", "Catherine Chantraine", "Caroline Uebelhoer", "Berfu Cengiz", "Beatriz Haddad Maia", "Arlinda Rushiti", "Arabela Fernandez Rabener", "Anna Gerasimou", "Anna Blinkova", "Angela Fita Boluda", "Andrea Lazaro Garcia", "Anastasiya Shoshyna", "Anastasija Homutova", "Anastasia Grymalska", "Ana Giraldi Requena", "Amina Anshba", "Amandine Hesse", "Amanda Carreras", "Alize Lim", "Alicia Herrero Linana", "Aleksandra Pospelova", "Ainhoa Atucha Gomez", "Agnes Bukta", "Adrianna Sosnowska", "Adeline Goncalves"];
var tdates=["20080121", "20080310", "20080707", "20080804", "20090302", "20090309", "20090629", "20100308", "20100315", "20110704", "20120305", "20150223", "20151012", "20151019", "20151102", "20160111", "20160201", "20160215", "20160229", "20160321", "20160328", "20160411", "20160613", "20160801", "20160808", "20160815", "20161010", "20161024", "20170508", "20170605", "20170619", "20170710", "20170731", "20170821", "20170918", "20171009", "20171016", "20171030", "20180226", "20180305", "20180319", "20180423", "20180521", "20180604", "20180618", "20180625", "20180806", "20180820", "20181015", "20181022", "20181029", "20181203", "20181210", "20181217", "20190121", "20190204", "20190225", "20190325", "20190408", "20190429", "20190506", "20190610", "20190617", "20190624", "20190701", "20190715", "20190722", "20190805", "20190812", "20190826", "20190902", "20190916", "20190923", "20191007", "20191021", "20191028", "20191104", "20200113", "20200120", "20200210", "20200224", "20210823", "20220516", "20220613", "20220704"];
var vranks=["45", "86", "106", "125", "129", "169", "192", "196", "198", "203", "208", "220", "222", "223", "225", "233", "235", "238", "242", "248", "251", "253", "254", "259", "260", "261", "263", "266", "267", "268", "275", "276", "279", "282", "290", "291", "292", "301", "303", "307", "309", "311", "318", "327", "329", "332", "333", "340", "348", "350", "352", "353", "356", "357", "364", "367", "370", "384", "387", "396", "406", "409", "410", "412", "419", "429", "431", "459", "464", "466", "484", "489", "497", "498", "500", "508", "514", "517", "521", "522", "523", "529", "539", "547", "550", "552", "571", "572", "583", "607", "613", "616", "620", "626", "631", "634", "639", "645", "655", "670", "679", "680", "691", "693", "708", "716", "735", "737", "741", "742", "745", "753", "758", "773", "777", "779", "789", "796", "800", "846", "851", "857", "859", "884", "886", "887", "892", "905", "912", "917", "927", "934", "936", "938", "941", "945", "1003", "1014", "1033", "1037", "1074", "1076", "1106", "1120", "1141", "1162", "1167", "1172", "1177", "1206", "1207", "1213", "1225", "1251"];
playernews = [];
var upcoming = "";
var matchmx = [["20220516", "Strasbourg", "Clay", "I", "L", "", "", "Q", "R32", "6-4 6-2", "3", "Aliaksandra Sasnovich", "45", "", "Q", "R", "19940322", "174", "BLR", "0", "70", "1", "13", "69", "44", "25", "7", "9", "2", "8", "1", "0", "55", "34", "20", "12", "9", "3", "6", "", "20220516-W-Strasbourg-R32-Aliaksandra_Sasnovich-Julie_Gervais.html", "", "", "2022-406-271"],
          ["20220516", "Strasbourg", "Clay", "I", "W", "", "", "WC", "Q1", "6-4 7-5", "3", "Magali Kempen", "357", "8", "", "R", "19971130", "", "BEL", "0", "90", "4", "12", "74", "40", "28", "13", "11", "4", "8", "1", "4", "68", "43", "22", "11", "11", "3", "9", "", "", "", "", "2022-406-258"],
          ["20220516", "Strasbourg", "Clay", "I", "W", "", "", "WC", "Q2", "6-4 6-0", "3", "Katharina Hobgarski", "292", "4", "", "R", "19970618", "171", "GER", "0", "62", "3", "3", "47", "30", "19", "12", "8", "2", "3", "2", "5", "59", "38", "18", "8", "8", "5", "10", "", "", "", "", "2022-406-266"],
          ["20220613", "W25 Denain", "Clay", "25", "L", "620", "", "", "QF", "6-1 6-2", "3", "Sofia Nami Samavati", "387", "7", "", "U", "20000214", "", "DEN", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2022-W-ITF-FRA-12A-2022-302"],
          ["20220613", "W25 Denain", "Clay", "25", "W", "620", "", "", "R16", "4-6 6-4 6-3", "3", "Chi Chi Scholl", "539", "", "", "R", "19920705", "", "USA", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2022-W-ITF-FRA-12A-2022-203"],
          ["20220613", "W25 Denain", "Clay", "25", "W", "620", "", "", "R32", "6-3 4-6 6-1", "3", "Selena Janicijevic", "329", "4", "", "U", "20020723", "", "FRA", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2022-W-ITF-FRA-12A-2022-105"],
          ["20220704", "Contrexeville 125", "Clay", "C", "L", "584", "", "WC", "R32", "6-0 6-3", "3", "Arantxa Rus", "86", "5", "", "L", "19901213", "180", "NED", "0", "63", "0", "6", "50", "29", "13", "10", "7", "5", "10", "3", "1", "44", "33", "25", "6", "8", "2", "3", "", "", "", "", "2022-2071-277"]
          ];
