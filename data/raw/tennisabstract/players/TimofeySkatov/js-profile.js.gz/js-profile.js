
    var fullname = 'Timofey Skatov';
    var lastname = 'Skatov';
    var currentrank=1400;
    var peakrank=1324;
    var peakfirst=20180423;
    var peaklast=20180507;
    var dob=20010121;
    
    var hand='R';
    var backhand='';
    var country='RUS';
    var shortlist=9;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs=1538;
    var peak_dubs=1524;
    var peakfirst_dubs=20180910;
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100228382';
    var atp_id='';
    var dc_id='';
    var wiki_id='';
    var ychoices=["Time Span", "Last 52", "Career", "2018", "2017"];
var tchoices=["Event", "All", "Almaty CH"];
var cchoices=["vs Country", "All", "BLR", "GBR", "RUS", "TPE"];
var rchoices=["as Rank", "All"];
var ochoices=["Yaraslau Shyla", "Tsung Hua Yang", "Philip Davydenko", "Pavel Kotov", "Matvey Minin", "Ben Jones", "Artur Shakhnubaryan", "Alexandr Igoshin"];
var tdates=["20170814", "20180226", "20180305", "20180312", "20180611", "20180820"];
var vranks=["224", "426", "455", "705", "1092", "1235", "1931"];
playernews = [];
var upcoming = "";
var matchmx = [["20170814", "Russia F7", "Clay", "S", "L", "", "", "WC", "R32", "6-4 7-5", "3", "Artur Shakhnubaryan", "1092", "", "SE", "U", "20.9938398357", "", "RUS", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2017-M-FU-RUS-07A-2017-006", "", "1", "1"],
          ["20180226", "Russia F1", "Hard", "S", "L", "UNR", "", "", "R32", "3-6 7-5 6-3", "3", "Philip Davydenko", "1235", "", "PR", "U", "19920902", "", "RUS", "1", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "0", "2018-M-FU-RUS-01A-2018-015", "", "1", "1"],
          ["20180305", "Russia F2", "Hard", "S", "L", "UNR", "", "", "R16", "6-4 7-6(2)", "3", "Yaraslau Shyla", "426", "", "", "R", "19930305", "", "BLR", "1", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "0", "2018-M-FU-RUS-02A-2018-019", "", "2", "2"],
          ["20180305", "Russia F2", "Hard", "S", "W", "UNR", "", "", "R32", "6-4 6-3", "3", "Matvey Minin", "1931", "", "Q", "U", "20010628", "", "RUS", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-RUS-02A-2018-006", "", "1", "1"],
          ["20180312", "Russia F3", "Hard", "S", "L", "UNR", "", "", "QF", "6-3 6-1", "3", "Pavel Kotov", "455", "5", "", "U", "19981118", "", "RUS", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "0", "2018-M-FU-RUS-03A-2018-026", "", "3", "3"],
          ["20180312", "Russia F3", "Hard", "S", "W", "UNR", "", "", "R16", "6-2 7-6(3)", "3", "Yaraslau Shyla", "426", "", "", "R", "19930305", "", "BLR", "1", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "1", "2018-M-FU-RUS-03A-2018-019", "", "2", "2"],
          ["20180312", "Russia F3", "Hard", "S", "W", "UNR", "", "", "R32", "6-1 6-3", "3", "Alexandr Igoshin", "705", "", "", "U", "19920110", "", "RUS", "1", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-RUS-03A-2018-006", "", "1", "1"],
          ["20180611", "Almaty CH", "Clay", "C", "L", "1347", "", "WC", "R32", "6-0 6-1", "3", "Tsung Hua Yang", "224", "", "", "R", "19910329", "", "TPE", "1", "54", "1", "7", "42", "23", "9", "2", "7", "1", "8", "3", "6", "43", "13", "8", "17", "6", "3", "4", "2", "", "", "0", "2018-7791-280", "", "1", "1"],
          ["20180820", "Belarus F3", "Hard", "S", "L", "1367", "", "JE", "R32", "6-2 4-6 7-6(6)", "3", "Ben Jones", "UNR", "", "", "R", "19980519", "", "GBR", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2018-M-FU-BLR-03A-2018-007", "", "1", "1"]
          ];
