
    var fullname = 'Mateus Alves';
    var lastname = 'Alves';
    var currentrank="UNR";
    var peakrank="UNR";
    var peakfirst="";
    var peaklast="";
    
    
    var hand='U';
    var backhand='';
    var country='BRA';
    var shortlist=2;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var ychoices=["Time Span", "Last 52", "Career", "2016"];
var tchoices=["Event", "All", "São Paulo Challenger"];
var cchoices=["vs Country", "All", "BRA"];
var rchoices=["as Rank", "All"];
var ochoices=["Andre Miele"];
var tdates=["20160418"];
var vranks=["725"];
playernews = [];
var upcoming = "";
var matchmx = [["20160418", "São Paulo Challenger", "Clay", "C", "L", "UNR", "", "WC", "Q1", "6-2 6-2", "3", "Andre Miele", "725", "6", "", "R", "19870412", "", "BRA", "1", "79", "3", "4", "59", "29", "17", "13", "8", "5", "9", "2", "5", "50", "28", "24", "11", "8", "5", "5", "", "", "", "", "2016-6492-246", "", "", ""],
          ["20160418", "São Paulo Challenger", "Clay", "C", "L", "UNR", "", "WC", "Q1", "6-2 6-2", "3", "Andre Miele", "725", "6", "", "R", "19870412", "", "BRA", "1", "79", "3", "4", "59", "29", "17", "13", "8", "5", "9", "2", "5", "50", "28", "24", "11", "8", "5", "5", "", "", "", "", "2016-6492-246", "", "", ""]
          ];
