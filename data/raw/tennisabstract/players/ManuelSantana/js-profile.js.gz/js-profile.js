
    var fullname = 'Manuel Santana';
    var lastname = 'Santana';
    var currentrank="";
    var peakrank=145;
    var peakfirst=19750305;
    var peaklast=19750305;
    var dob=19380510;
    
    var hand='R';
    var country='ESP';
    var shortlist=4;
    var careerjs=1;
    var active=0;
    var lastdate=19780710;
    var ychoices=["Time Span", "Last 52", "Career", "1978", "1977", "1976", "1975", "1974", "1973", "1972", "1971", "1970", "1969", "1968", "1967", "1966", "1965", "1964", "1963", "1962", "1961", "1960", "1959", "1958"];
var tchoices=["Event", "All", "Davis Cup", "Barcelona", "Barcelona WCT", "Basel", "Bastad", "Boca Raton", "Bombay", "Bournemouth", "Hilversum", "Johannesburg", "Mexico City WCT", "Monte Carlo", "Munich", "New York", "Newport", "Philadelphia WCT", "Roland Garros", "Rome", "Salisbury", "San Francisco", "South Orange", "US Open", "Wimbledon"];
var cchoices=["vs Country", "All", "ARG", "AUS", "AUT", "BEL", "BRA", "BUL", "CAN", "CHI", "COL", "CRO", "CZE", "DEN", "ECU", "EGY", "ESP", "FRA", "GBR", "GER", "GRE", "HUN", "IND", "ITA", "JPN", "MEX", "NED", "NZL", "RHO", "ROU", "RSA", "RUS", "SUI", "SWE", "TCH", "UNK", "USA", "YUG", "ZIM"];
var rchoices=["as Rank", "All"];
var ochoices=["Rod Laver", "Jan Eric Lundquist", "Cliff Drysdale", "Arthur Ashe", "Roy Emerson", "Pierre Darmon", "Nicola Pietrangeli", "Thomas Lejus", "Ronnie Barnes", "Roger Taylor", "Owen Davidson", "Michael Sangster", "Jan Leschly", "Ion Tiriac", "Ingo Buding", "Francois Jauffret", "Clark Graebner", "Christian Kuhnke", "Zeljko Franulovic", "William Alvarez", "Wilhelm Bungert", "Uffe Schmidt", "Tom Okker", "Thomaz Koch", "Robert Wilson", "Robert Mckinley", "Raymond Moore", "Pancho Guzman", "Ove Nils Bengtson", "Milan Holecek", "Miguel Olvera", "Marty Riessen", "Karl Meiler", "Jose Mandarino", "John Newcombe", "Jim Osborne", "Jim Mcmanus", "Jean Claude Barclay", "Graham Stilwell", "Georges Goven", "Fred Stolle", "Frank Froehling", "Boro Jovanovic", "Billy Knight", "Antonio Munoz", "Alex Metreveli", "Adrian Bey", "Woody Blocher", "William Higgins", "Willem Maris", "Whitney Reed", "Vladimir Zednik", "Vittorio Crotta", "Vitas Gerulaitis", "Victor Amaya", "U Unknown", "U Mcdonald", "Trey Waltke", "Torben Ulrich", "Tony Roche", "Tony Palafox", "Toma Ovici", "Tim Sturdza", "Szabolcz Baranyi", "Syd Ball", "Stojan Velev", "Stepan Koudelka", "Steffan Oscar Stockenberg", "Stan Smith", "Shaher Mourad", "Sergei Likhachev", "Sashi Menon", "Ronald S Mckenzie", "Rolf Thung", "Ramanathan Krishnan", "Rafael Osuna", "Premjit Lall", "Paul Hutchins", "Patricio Cornejo", "Pat Cramer", "Orlando Sirola", "Nikola Pilic", "Nicholas Kalogeropoulos", "Moataz El Sonbol", "Mike Belkin", "Michael Davies", "Mark Cox", "Mark Anthony Otway", "Marcello Lara", "Manuel Orantes", "Luis Ayala", "Lew Gerrard", "Larry Gottfried", "Kiril Yashmakov", "Ken Fletcher", "Keith Diepraam", "Jose Guerrero", "Jorgen Ulrich", "John Marks", "John Feaver", "John Cooper", "John Andrews", "Jiri Javorsky", "Jean Noel Grinda", "Jean Courcol", "Jan Kodes", "Jan Hajer", "Jaidip Mukerjea", "Jacques Renavand", "Jacques Grigry", "Jackie Brichant", "Ivan Molina", "Ivan Jaksic", "Istvan Gulyas", "Ismail El Shafei", "Isao Watanabe", "Ilie Nastase", "Ibrahim Badreldin Sayed", "Henry Hank Irvine", "Hans Nerell", "Hans Jaochim Plotz", "Hakar Zahr", "Guillermo Vilas", "Fred Berli", "Franz Hainka", "Frank Tutvin", "Frank Saloman", "Fausto Gardini", "Eugene L Scott", "Ernesto Aguirre", "Eduardo Soriano", "Edison Mandarino", "Donald H Fontana", "Dick Stockton", "Dick Crealy", "Dennis Ralston", "Daniel Contet", "Corrado Barazzutti", "Cliff Richey", "Charlie Pasarell", "Charles Mckinley", "Carlos Alberto Fernandes", "Bob Hewitt", "Bob Carmichael", "Bill Tully", "Bill Bowrey", "Bernard Paul", "Bernard Mignot", "Bengt Aberg", "Antonio Zugarelli", "Angel Gimenez", "Andres Gimeno", "Allan Stone", "Alex Kurucz", "Alan J Lane", "Alain Bresson", "Adel Ismail", "Abe Segal"];
var matchmx = [["19770704", "Newport", "Grass", "A", "L", "234", "", "", "R32", "7-6 6-3", "3", "Dick Crealy", "36", "1", "", "R", "19440918", "", "AUS", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""],
          ["19770831", "US Open", "Clay", "G", "L", "234", "", "", "R128", "6-1 6-0", "5", "Guillermo Vilas", "4", "4", "", "L", "19520817", "180", "ARG", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""],
          ["19780710", "Newport", "Grass", "A", "L", "352", "", "", "R16", "7-5 6-2", "3", "Arthur Ashe", "235", "1", "", "R", "19430710", "185", "USA", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""],
          ["19780710", "Newport", "Grass", "A", "W", "352", "", "", "R32", "6-7 6-3 6-3", "3", "Woody Blocher", "156", "", "", "R", "19510824", "173", "USA", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""]
          ];
