
    var fullname = 'Selina Dal';
    var lastname = 'Dal';
    var currentrank=1079;
    var peakrank=547;
    var peakfirst=20241021;
    var peaklast=20241104;
    var dob=20011128;
    
    var hand='U';
    var backhand='';
    var country='GER';
    var shortlist=9;
    var careerjs=1;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='';
    var wta_id='';
    var fc_id='800400223';
    var wiki_id='';
    var blast_link='';
    var more_link='';
    var death_date="";
    var dob_approx="";
    var elo_rating='';
    var elo_rank='';
    var ychoices=["Time Span", "Last 52", "Career", "2026", "2025", "2024", "2023", "2022", "2021", "2020"];
var tchoices=["Event", "All", "W15 Alkmaar", "W15 Bol", "W15 Eindhoven", "W15 Haabneeme", "W15 Kottingbrunn", "W15 Leimen", "W15 Les Contamines-Montjoie", "W15 Melilla", "W15 Monastir", "W15 Sharm ElSheikh", "W15 Wanfercee-Baulet", "W25 Altenkirchen", "W25 Darmstadt", "W25 Denain", "W25 Koksijde", "W25 Loule", "W25 Oldenzaal", "W25 Reims", "W25 Troisdorf", "W35 Aschaffenburg", "W35 Braunschweig", "W35 Darmstadt", "W35 Horb", "W35 Joue-les-Tours", "W35 Koksijde", "W35 Lousada", "W35 Reims", "W35 Solarino", "W35 Stuttgart-Vaihingen", "W40 Oldenzaal", "W50 Aschaffenburg", "W50 Cherbourg-en-Cotentin", "W50 Meerbusch", "W60 Hamburg", "W75 Hamburg", "W75 Hechingen", "W75 Vienna"];
var cchoices=["vs Country", "All", "AUS", "AUT", "BEL", "BLR", "BUL", "CHN", "CRO", "CZE", "DEN", "EGY", "ESP", "EST", "FIN", "FRA", "GBR", "GEO", "GER", "GRE", "HKG", "HUN", "IND", "ITA", "JPN", "LAT", "LTU", "LUX", "MAR", "MEX", "NED", "POL", "ROU", "RUS", "SLO", "SRB", "SRI", "SUI", "SVK", "SWE", "TUN", "TUR", "UKR", "USA", "UZB"];
var rchoices=["as Rank", "All"];
var ochoices=["Yufei Ren", "Vlada Ekshibarova", "Olga Helmi", "Katarina Kuzmova", "Ziva Falkner", "Stefania Bojica", "Michaela Laki", "Lian Tran", "Jenny Lim", "Fabienne Gettwart", "Julia Stamatova", "Jiaqi Wang", "Ho Ching Wu", "Zoziya Kardava", "Xenia Bandurowska", "Vlada Mincheva", "Victoria Rodriguez", "Victoria Milovanova", "Valeriia Artemeva", "Valentina Steiner", "Tiantsoa Sarah Rakotomanga Rajaonah", "Tamila Gadamauri", "Stephanie Judith Visscher", "Sina Herrmann", "Silvia Ambrosio", "Sara Svetac", "Sandra Samir", "Rhiann Newborn", "Rebecca Munk Mortensen", "Paula Arias Manjon", "Patricia Maria Tig", "Nicol Benesova", "Mona Barthel", "Martha Matoula", "Lucie Nguyen Tan", "Louanne Djafari", "Lola Radivojevic", "Leonie Kung", "Leire De Ezcurra", "Lea Karren", "Lauren Seye", "Laura Samson", "Lara Pfeifer", "Julie Myatovic", "Julia Grabher", "Jaimee Fourlis", "Hiroko Kuwata", "Haruka Kaji", "Giulia Paterno", "Franziska Sziedat", "Fiona Ganz", "Filippa Stieg", "Emily Seibold", "Emeline Dartron", "Eleni Christofi", "Eleejah Inisan", "Ekaterine Gorgodze", "Denisa Hindova", "Cristina Diaz Adrover", "Chelsea Fontenel", "Camilla Zanolini", "Ayla Aksu", "Ava Hrastar", "Audelie Lesauvage", "Arlinda Rushiti", "Arianna Zucchini", "Aravane Rezai", "Antonia Schmidt", "Anna Zyryanova", "Ann Akasha Ceuca", "Anastasiia Firman", "Anastasia Kulikova", "Alexa Volkov", "Aino Alkio", "Adrienn Nagy", "Zixuan Zeng", "Virginia Ferrara", "Vaishnavi Adkar", "Tess Sugnaux", "Salma Drugdova", "Nina Radovanovic", "Michika Ozeki", "Melisa Ercan", "Marie Vogt", "Mara Gae", "Manal Ennaciri", "Lea Ribourdouille", "Lara Smejkal", "Ksenia Efremova", "Kateryna Lazarenko", "Karla Bartel", "Julia Adams", "Jeline Vandromme", "Jade Psonka", "Ivonne Cavalle Reimers", "Gina Marie Dittmann", "Gina Feistel", "Emmanuelle Girard", "Emily Welker", "Ekaterina Ovcharenko", "Doga Turkmen", "Demi Tran", "Darya Shauha", "Darja Suvirdjonkova", "Chiraz Bechri", "Carson Branstine", "Carlotta Moccia", "Barbora Michalkova", "Aya El Aouni", "Anja Wildgruber", "Alyssa Reguer", "Adithya Karunaratne", "Verena Meliss", "Tilwith Di Girolami", "Simona Waltert", "Sijia Wei", "Saumya Vig", "Sarah Mueller", "Sarah Iliev", "Sanne Schalekamp", "Rebeka Stolmar", "Nikol Palecek", "Nadine Keller", "Na Dong", "Milana Zhabrailova", "Marwa Hakimi", "Marie Weckerle", "Marie Villet", "Maria Sholokhova", "Maria Fernanda Morales", "Manon Leonard", "Malak El Allami", "Maileen Nuudi", "Luisa Meyer Auf Der Heide", "Lexie Stevens", "Laura Hietaranta", "Laura Boehner", "Kristina Paskauskas", "Klaudija Bubelyte", "Kayleigh Didderiens", "Julia Middendorf", "Jennifer Luikham", "Ilay Yoruk", "Federica Prati", "Evita Ramirez", "Esther Bataille", "Emma Mazzoni", "Emilie Ballintijn", "Eloise De Mooij", "Elena Karner", "Elena Jamshidi", "Dilara Okur", "Diana Chehoudi", "Denise Hrdinkova", "Dasha Lopatetskaya", "Daniela Vismane", "Chelsea Vanhoutte", "Charlotte Wijkamp", "Audrey Albie", "Aubane Droguet", "Arina Gabriela Vasilescu", "Arabella Koller", "Anouck Vrancken Peeters", "Anastasiia Gureva"];
var tdates=["20201116", "20210215", "20210412", "20210913", "20211004", "20211101", "20211108", "20211115", "20220131", "20220207", "20220314", "20220321", "20220613", "20220620", "20220718", "20220725", "20220808", "20220815", "20220822", "20220912", "20220919", "20220926", "20221017", "20221031", "20221107", "20221114", "20230130", "20230206", "20230227", "20230306", "20230313", "20230320", "20230410", "20230417", "20230424", "20230529", "20230619", "20230717", "20230821", "20230828", "20231002", "20231106", "20231113", "20231120", "20231218", "20231225", "20240205", "20240212", "20240304", "20240325", "20240520", "20240527", "20240624", "20240701", "20240708", "20240715", "20240722", "20240729", "20240805", "20240819", "20240826", "20240902", "20240930", "20241007", "20241014", "20241028", "20241118", "20250707", "20260223", "20260316", "20260323"];
var vranks=["172", "243", "247", "248", "259", "260", "273", "288", "301", "307", "322", "355", "361", "373", "404", "410", "412", "418", "446", "462", "476", "486", "505", "507", "508", "509", "517", "519", "520", "535", "538", "542", "545", "547", "552", "566", "570", "576", "579", "580", "593", "596", "598", "616", "617", "622", "623", "626", "627", "628", "647", "648", "651", "653", "654", "660", "663", "664", "679", "685", "695", "696", "698", "704", "707", "715", "722", "745", "750", "751", "765", "766", "776", "777", "789", "792", "797", "816", "818", "822", "834", "835", "852", "885", "904", "906", "916", "923", "930", "932", "945", "954", "961", "964", "984", "996", "1020", "1023", "1029", "1030", "1078", "1079", "1081", "1085", "1097", "1104", "1112", "1120", "1130", "1132", "1133", "1155", "1180", "1203", "1212", "1219", "1231", "1236", "1238", "1259", "1269", "1302", "1337", "1338", "1501"];
playernews = [];
var upcoming = "";
var matchmx = [["20250707", "W50 Aschaffenburg", "Clay", "50", "L", "695", "", "", "R16", "6-3 0-6 6-3", "3", "Ekaterine Gorgodze", "243", "", "", "L", "19911203", "", "GEO", "0", "140", "1", "0", "95", "71", "33", "11", "12", "9", "16", "1", "2", "92", "73", "37", "9", "12", "12", "19", "", "", "", "", "2025-W-ITF-GER-2025-014-204"],
          ["20250707", "W50 Aschaffenburg", "Clay", "50", "W", "695", "", "", "R32", "7-6(5) 5-7 6-1", "3", "Valentina Steiner", "750", "", "", "U", "20060719", "", "GER", "0", "184", "2", "7", "125", "68", "38", "32", "16", "9", "14", "3", "10", "116", "61", "36", "22", "15", "11", "17", "", "", "", "", "2025-W-ITF-GER-2025-014-107"],
          ["20260223", "W15 Leimen", "Hard", "15", "L", "1080", "", "", "R32", "6-3 6-7(6) 6-2", "3", "Tamila Gadamauri", "576", "", "", "U", "20050221", "", "BEL", "0", "171", "0", "6", "86", "51", "27", "14", "14", "4", "12", "0", "5", "129", "77", "46", "24", "15", "7", "12", "", "", "", "", "2026-W-ITF-GER-2026-001-103"],
          ["20260316", "W15 Sharm ElSheikh", "Hard", "15", "L", "1080", "", "", "R32", "4-6 6-3 6-2", "3", "Ann Akasha Ceuca", "707", "", "", "U", "20061108", "", "GER", "0", "137", "1", "3", "85", "58", "31", "12", "13", "7", "14", "1", "4", "96", "68", "40", "12", "14", "7", "12", "", "", "", "", "2026-W-ITF-EGY-2026-010-113"],
          ["20260323", "W15 Sharm ElSheikh", "Hard", "15", "W", "1080", "", "", "F", "6-2 6-4", "3", "Victoria Milovanova", "715", "", "", "L", "20070301", "", "RUS", "0", "99", "0", "0", "62", "43", "27", "12", "9", "3", "4", "0", "2", "51", "32", "18", "9", "9", "4", "8", "", "", "", "", "2026-W-ITF-EGY-2026-014-501"],
          ["20260323", "W15 Sharm ElSheikh", "Hard", "15", "W", "1080", "", "", "QF", "6-3 6-3", "3", "Sandra Samir", "373", "", "", "R", "19971104", "170", "EGY", "0", "123", "0", "0", "65", "50", "21", "12", "9", "6", "10", "1", "4", "58", "34", "18", "6", "9", "6", "13", "", "", "", "", "2026-W-ITF-EGY-2026-014-301"],
          ["20260323", "W15 Sharm ElSheikh", "Hard", "15", "W", "1080", "", "", "R16", "7-5 6-3", "3", "Valeriia Artemeva", "954", "", "", "U", "20070609", "", "RUS", "0", "116", "0", "2", "67", "47", "27", "11", "10", "4", "8", "1", "7", "74", "52", "28", "6", "11", "4", "11", "", "", "", "", "2026-W-ITF-EGY-2026-014-202"],
          ["20260323", "W15 Sharm ElSheikh", "Hard", "15", "W", "1080", "", "", "R32", "6-0 6-2", "3", "Zoziya Kardava", "751", "", "", "R", "20010715", "", "RUS", "0", "65", "1", "0", "39", "27", "22", "7", "7", "0", "0", "0", "3", "43", "37", "15", "2", "7", "2", "7", "", "", "", "", "2026-W-ITF-EGY-2026-014-104"],
          ["20260323", "W15 Sharm ElSheikh", "Hard", "15", "W", "1080", "", "", "SF", "6-3 7-5", "3", "Ava Hrastar", "852", "", "", "U", "20020227", "", "USA", "0", "135", "2", "2", "89", "66", "37", "15", "10", "14", "16", "3", "4", "72", "38", "22", "16", "11", "3", "8", "", "", "", "", "2026-W-ITF-EGY-2026-014-401"]
          ];
