
    var fullname = 'Laura Radakovic';
    var lastname = 'Radakovic';
    var currentrank="UNR";
    var peakrank=1143;
    var peakfirst=20230626;
    var peaklast=20230626;
    var dob=20010329;
    
    var hand='U';
    var backhand='';
    var country='BIH';
    var shortlist=19;
    var careerjs=1;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100251517';
    var wta_id='';
    var fc_id='';
    var wiki_id='';
    var blast_link='';
    var more_link='';
    var death_date="";
    var dob_approx="";
    var ychoices=["Time Span", "Last 52", "Career", "2024", "2023", "2022", "2021", "2020", "2019", "2018"];
var tchoices=["Event", "All", "W15 Annenheim", "W15 Antalya", "W15 Bad Waltersdorf", "W15 Banja Luka", "W15 Bucharest", "W15 Catez Ob Savi", "W15 Kottingbrunn", "W15 Oberpullendorf", "W15 Olomouc", "W15 Osijek", "W15 Vejle", "W25 Bydgoszcz", "W25 Darmstadt", "W25 Feld am See", "W25 Frydek Mistek", "W25 Jablonec nad Nisou", "W25 Kaposvar", "W25 Osijek (MOVED FROM 16 May)", "W25 Otocec", "W25 Podgorica", "W25 Poertschach", "W25 Split", "W25 St Poelten", "W25 Vienna", "W25 Warmbad Villach", "W25 Zagreb", "W40 Murska Sobota", "W40 Otocec", "W50 Otocec", "W60 Bratislava", "W60 Istanbul", "W60 Olomouc", "W60 Zagreb", "Antalya $15K", "Szekesfehervar $15K"];
var cchoices=["vs Country", "All", "ARG", "AUS", "AUT", "BIH", "BUL", "CHN", "COL", "CRO", "CZE", "DEN", "ESP", "EST", "FRA", "GBR", "GER", "HUN", "ISR", "ITA", "JPN", "KOR", "LAT", "ROU", "RUS", "SLO", "SRB", "SUI", "SVK", "SWE", "TUR", "USA"];
var rchoices=["as Rank", "All"];
var ochoices=["Margarita Ignatjeva", "Katerina Tsygourova", "Mia Chudejova", "Jana Vanik", "Ivana Sebestova", "Denise Hrdinkova", "Costanza Traversi", "Zuzana Sopkova", "Yana Morderger", "Yana Kircheva", "Victoria Borodulina", "Veronika Bokor", "Vanda Vargova", "Tina Cvetkovic", "Terezia Baraniakova", "Tal Dekel", "Svetlana Samardzic", "Stefanie Auer", "Rina Saigo", "Rebeka Stolmar", "Petra Csabi", "Oleksandra Oliynykova", "Na Dong", "Moni Potrc", "Mia Liepert", "Martina Spigarelli", "Martina Marusinova", "Luciana Blatter", "Lola Maya Gutensohn", "Linda Klimovicova", "Liliana Gajdosova", "Liel Marlies Rothensteiner", "Laura Pasterk", "Kseniia Piskareva", "Julie Struplova", "Julia Stamatova", "Joulia Cristiana Cirstea", "Jenifer Anger", "Jelena Ristic", "Ipek Sakiroglu", "Francesca De Matteo", "Federica Rossi", "Eva Maria Riml", "Ena Baltic", "Emma Mazzoni", "Carolina Kuhl", "Beatrice Ricci", "Barbara Dessolis", "Arabella Koller", "Anna Semenova", "Anna Lena Ebster", "Andrea Obradovic", "Anastasia Zhilina", "Anastasia Piangerelli", "Amila Jusufbegovic", "Alina Michalitsch", "Alexandra Vasilyeva", "Agustina Chlpac", "Adriana Rajkovic", "Yui Chikaraishi", "Vanessa Ersoz", "Sonay Kartal", "Sarafina Hansen", "Sabina Dadaciu", "Pauline Wuarin", "Olivia Gadecki", "Nika Radisic", "Martina Pradova", "Kim Michaela Zahraj", "Kanako Morisaki", "Johanne Christine Svendsen", "Jennifer Ruggeri", "Izabela Heinzova", "Flaminia Scara", "Erica Oosterhout", "Eliz Maloney", "Dayeon Back", "Darta Dalecka", "Anet Angelika Koskel", "Anastasia Petrova", "Alexandra Osborne", "Ziva Falkner", "Zita Kovacs", "Tayisiya Morderger", "Reka Luca Jani", "Nikoletta Muller", "Marina Melnikova", "Kristina Novak", "Josephine Boualem", "Federica Arcidiacono", "Emiliana Arango", "Elena Gemovic", "Anastassia Pantelic", "Ana Vrljic", "Alena Fomina"];
var tdates=["20180903", "20181015", "20190401", "20190408", "20190603", "20190624", "20190708", "20190805", "20190902", "20190909", "20190916", "20190923", "20200914", "20210419", "20210426", "20210503", "20210719", "20210726", "20210802", "20210823", "20210830", "20210906", "20211011", "20211018", "20211025", "20220321", "20220328", "20220425", "20220502", "20220509", "20220516", "20220523", "20220530", "20220606", "20220613", "20220725", "20220801", "20220815", "20220822", "20220829", "20220905", "20220912", "20220919", "20221114", "20221128", "20221205", "20230313", "20230320", "20230327", "20230515", "20230529", "20230605", "20240325", "20240429", "20240520", "20240603"];
var vranks=["276", "287", "470", "480", "542", "568", "587", "607", "621", "673", "681", "705", "756", "777", "785", "790", "803", "804", "807", "808", "869", "871", "876", "917", "1015", "1021", "1027", "1056", "1076", "1086", "1104", "1109", "1125", "1130", "1157", "1159", "1161", "1228", "1238", "1239", "1274", "1286", "1289", "1294", "1307", "1318", "1329", "1333", "1349", "1368", "1445", "1473", "1529"];
var playernews=["<b>1 Jul</b> <a href=\"http://www.tennisabstract.com/charting/20230327-W-ITF_Murska_Sobota-Q2-Laura_Radakovic-Linda_Klimovicova.html\" target=\"new\">The Match Charting Project: 2023 ITF Murska Sobota Q2: Laura Radakovic vs Linda Klimovicova</a>: <i>Detailed shot-by-shot stats plus serve and return analytics for both</i><a href=\"http://www.tennisabstract.com/charting/20230327-W-ITF_Murska_Sobota-Q2-Laura_Radakovic-Linda_Klimovicova.html\" target=\"new\">...</a>"];
var upcoming = "";
var matchmx = [["20230313", "W15 Antalya", "Clay", "15", "L", "1202", "9", "", "Q3", "6-2 7-5", "3", "Anastasia Piangerelli", "1159", "5", "", "U", "20000822", "", "ITA", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2023-W-ITF-TUR-10A-2023-305"],
          ["20230313", "W15 Antalya", "Clay", "15", "W", "1202", "9", "", "Q1", "6-2 6-1", "3", "Yana Kircheva", "", "", "", "U", "", "", "BUL", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2023-W-ITF-TUR-10A-2023-120"],
          ["20230313", "W15 Antalya", "Clay", "15", "W", "1202", "9", "", "Q2", "6-1 6-1", "3", "Ipek Sakiroglu", "", "", "", "U", "20070212", "", "TUR", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2023-W-ITF-TUR-10A-2023-210"],
          ["20230320", "W15 Antalya", "Clay", "15", "L", "1208", "13", "", "Q2", "6-4 6-3", "3", "Joulia Cristiana Cirstea", "", "", "", "U", "20060302", "", "ROU", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2023-W-ITF-TUR-11A-2023-210"],
          ["20230320", "W15 Antalya", "Clay", "15", "W", "1208", "13", "", "Q1", "6-0 6-7(5) 12-10", "3", "Kseniia Piskareva", "", "", "", "U", "", "", "RUS", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2023-W-ITF-TUR-11A-2023-120"],
          ["20230327", "W40 Murska Sobota", "Hard", "40", "L", "1208", "15", "", "Q2", "6-4 6-2", "3", "Linda Klimovicova", "542", "8", "", "U", "20040618", "", "CZE", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2023-W-ITF-SLO-09A-2023-208"],
          ["20230327", "W40 Murska Sobota", "Hard", "40", "W", "1208", "15", "", "Q1", "6-1 7-6(5)", "3", "Anna Semenova", "", "", "", "U", "20040201", "", "RUS", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2023-W-ITF-SLO-09A-2023-116"],
          ["20230515", "W25 Feld am See", "Clay", "25", "L", "1170", "10", "", "R32", "7-5 6-2", "3", "Anna Lena Ebster", "", "", "", "U", "20040106", "", "AUT", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2023-W-ITF-AUT-06A-2023-204"],
          ["20230529", "W40 Otocec", "Clay", "40", "L", "1185", "", "", "Q1", "6-2 6-3", "3", "Oleksandra Oliynykova", "621", "3", "", "R", "20010103", "", "CRO", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2023-W-ITF-SLO-07A-2023-105"],
          ["20230605", "W15 Banja Luka", "Clay", "15", "L", "1185", "", "", "QF", "6-3 6-3", "3", "Katerina Tsygourova", "869", "7", "", "U", "20000511", "", "SUI", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2023-W-ITF-BIH-01A-2023-304"],
          ["20230605", "W15 Banja Luka", "Clay", "15", "W", "1185", "", "", "R16", "6-2 6-1", "3", "Mia Chudejova", "1104", "", "", "U", "20030730", "", "SVK", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2023-W-ITF-BIH-01A-2023-208"],
          ["20230605", "W15 Banja Luka", "Clay", "15", "W", "1185", "", "", "R32", "6-0 6-1", "3", "Svetlana Samardzic", "", "", "Q", "U", "20040622", "", "GER", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2023-W-ITF-BIH-01A-2023-115"],
          ["20240325", "W15 Antalya", "Clay", "15", "L", "", "", "", "R32", "6-4 6-1", "3", "Agustina Chlpac", "1274", "7", "", "U", "19970210", "", "ARG", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-012-213"],
          ["20240325", "W15 Antalya", "Clay", "15", "W", "", "", "", "R64", "7-5 6-1", "3", "Francesca De Matteo", "", "", "", "U", "", "", "ITA", "0", "", "", "", "", "", "", "2024-W-ITF-TUR-2024-012-126"],
          ["20240429", "W15 Osijek", "Clay", "15", "L", "", "", "", "R32", "7-5 6-3", "3", "Victoria Borodulina", "", "3", "", "R", "", "", "RUS", "0", "", "", "", "", "", "", "2024-W-ITF-CRO-2024-004-205"],
          ["20240520", "W50 Otocec", "Clay", "50", "L", "", "", "", "Q2", "6-3 6-3", "3", "Denise Hrdinkova", "790", "5", "", "U", "20030929", "", "CZE", "0", "", "", "", "", "", "", "2024-W-ITF-SLO-2024-006-205"],
          ["20240520", "W50 Otocec", "Clay", "50", "W", "", "", "", "Q1", "6-1 6-0", "3", "Emma Mazzoni", "1349", "16", "", "U", "19981015", "", "FRA", "0", "", "", "", "", "", "", "2024-W-ITF-SLO-2024-006-110"],
          ["20240603", "W15 Banja Luka", "Clay", "15", "L", "", "", "WC", "R16", "6-4 6-2", "3", "Katerina Tsygourova", "785", "7", "", "U", "20000511", "", "SUI", "0", "", "", "", "", "", "", "2024-W-ITF-BIH-2024-001-207"],
          ["20240603", "W15 Banja Luka", "Clay", "15", "W", "", "", "WC", "R32", "6-1 6-0", "3", "Jelena Ristic", "", "", "WC", "U", "20031225", "", "AUT", "0", "", "", "", "", "", "", "2024-W-ITF-BIH-2024-001-114"]
          ];
