
    var fullname = 'Patrick Zahraj';
    var lastname = 'Zahraj';
    var currentrank=1912;
    var peakrank=1699;
    var peakfirst=20180917;
    var peaklast=20180917;
    var dob=19990717;
    
    var hand='U';
    var backhand='';
    var country='GER';
    var shortlist=6;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100185448';
    var atp_id='';
    var dc_id='';
    var wiki_id='';
    var ychoices=["Time Span", "Last 52", "Career", "2018", "2015"];
var tchoices=["Event", "All", "Koblenz CH"];
var cchoices=["vs Country", "All", "AUT", "CZE", "GBR", "GER", "SVK"];
var rchoices=["as Rank", "All"];
var ochoices=["Petr Nouza", "Matthias Haim", "Marvin Schaber", "Gibril Diarra", "Filip Horansky", "Jonny Omara"];
var tdates=["20151012", "20180115", "20180618", "20180820", "20181008"];
var vranks=["318", "502", "730", "751", "1222"];
playernews = [];
var upcoming = "";
var matchmx = [["20151012", "Egypt F35", "Hard", "S", "L", "", "", "Q", "R32", "6-4 6-2", "3", "Jonny Omara", "1222", "", "", "R", "20.6132785763", "", "GBR", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2", "", "", "", "2015-M-FU-EGY-35A-2015-014", "", "1", "1"],
          ["20180115", "Koblenz CH", "Hard", "C", "L", "UNR", "", "WC", "Q1", "6-2 7-5", "3", "Filip Horansky", "318", "5", "", "R", "19930107", "", "SVK", "1", "73", "7", "2", "61", "37", "23", "12", "10", "3", "6", "4", "3", "70", "45", "33", "14", "10", "2", "2", "2", "", "", "", "2018-7652-231", "", "", ""],
          ["20180618", "Germany F4", "Clay", "S", "L", "UNR", "", "", "R32", "6-3 6-4", "3", "Gibril Diarra", "751", "", "", "U", "19900526", "", "AUT", "1", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-GER-04A-2018-011", "", "1", "1"],
          ["20180820", "Germany F13", "Clay", "S", "L", "UNR", "", "", "R16", "6-3 6-4", "3", "Matthias Haim", "502", "7", "Q", "R", "19980111", "", "AUT", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-GER-13A-2018-020", "", "2", "2"],
          ["20180820", "Germany F13", "Clay", "S", "W", "UNR", "", "", "R32", "6-4 6-3", "3", "Marvin Schaber", "UNR", "", "Q", "U", "20010306", "", "GER", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-GER-13A-2018-007", "", "1", "1"],
          ["20181008", "Germany F15", "Carpet", "S", "L", "1716", "", "Q", "R32", "6-2 6-4", "3", "Petr Nouza", "730", "", "", "U", "19980909", "", "CZE", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2018-M-FU-GER-15A-2018-013", "", "1", "1"]
          ];
