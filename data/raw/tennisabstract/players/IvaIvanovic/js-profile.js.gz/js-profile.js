
    var fullname = 'Iva Ivanovic';
    var lastname = 'Ivanovic';
    var currentrank="UNR";
    var peakrank="UNR";
    var peakfirst="";
    var peaklast="";
    
    
    var hand='U';
    var backhand='';
    var country='SUI';
    var shortlist=6;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='';
    var wta_id='';
    var fc_id='800681097';
    var wiki_id='';
    var blast_link='';
    var more_link='';
    var death_date="";
    var dob_approx="";
    var elo_rating='';
    var elo_rank='';
    var ychoices=["Time Span", "Last 52", "Career", "2025", "2024", "2023"];
var tchoices=["Event", "All", "W15 Antalya", "W15 Banja Luka", "W15 Kursumlijska Banja"];
var cchoices=["vs Country", "All", "BIH", "ITA", "KAZ", "TUR", "UKR"];
var rchoices=["as Rank", "All"];
var ochoices=["Sofia Avataneo", "Sara Mikaca", "Melis Sakiroglu", "Gaia Squarcialupi", "Daria Yesypchuk", "Anastasiya Krymkova"];
var tdates=["20231127", "20231204", "20240429", "20250602", "20250908"];
var vranks=["629", "974", "1159", "1374"];
var playernews=["<b>15 Sep</b> <a href=\"http://www.tennisabstract.com/charting/20250914-W-ITF_Kursumlijska_Banja-Q1-Iva_Ivanovic-Klara_Vaja.html\" target=\"new\">The Match Charting Project: 2025 ITF Kursumlijska Banja Q1: Iva Ivanovic vs Klara Vaja</a>: <i>Crowdsourced, detailed analytics for every shot of all the points of</i><a href=\"http://www.tennisabstract.com/charting/20250914-W-ITF_Kursumlijska_Banja-Q1-Iva_Ivanovic-Klara_Vaja.html\" target=\"new\">...</a>"];
var upcoming = "";
var matchmx = [["20250908", "W15 Kursumlijska Banja", "Clay", "15", "L", "", "", "", "R32", "1-6 6-3 7-5", "3", "Sara Mikaca", "974", "", "", "U", "", "", "BIH", "0", "158", "8", "8", "103", "54", "41", "20", "14", "10", "13", "3", "4", "92", "56", "40", "16", "14", "9", "12", "", "", "", "", "2025-W-ITF-SRB-2025-019-102"],
          ["20250602", "W15 Banja Luka", "Clay", "15", "L", "", "", "", "R32", "7-6(5) 6-2", "3", "Gaia Squarcialupi", "629", "", "", "U", "19971023", "", "ITA", "0", "106", "4", "5", "70", "37", "26", "16", "10", "5", "8", "10", "4", "78", "40", "32", "19", "10", "11", "12", "", "", "", "", "2025-W-ITF-BIH-2025-001-116"],
          ["20240429", "W15 Kursumlijska Banja", "Clay", "15", "L", "", "", "WC", "R32", "6-0 6-1", "3", "Daria Yesypchuk", "1159", "", "", "U", "20051004", "", "UKR", "0", "", "", "", "", "", "", "2024-W-ITF-SRB-2024-003-106"],
          ["20231204", "W15 Antalya", "Clay", "15", "L", "", "", "", "R64", "6-4 6-0", "3", "Anastasiya Krymkova", "", "", "", "U", "20070205", "", "KAZ", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2023-W-ITF-TUR-28A-2023-111"],
          ["20231127", "W15 Antalya", "Clay", "15", "L", "", "", "", "R32", "6-1 6-3", "3", "Sofia Avataneo", "1374", "4", "", "U", "20030127", "", "ITA", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2023-W-ITF-TUR-27A-2023-207"],
          ["20231127", "W15 Antalya", "Clay", "15", "W", "", "", "", "R64", "7-5 6-1", "3", "Melis Sakiroglu", "", "", "WC", "U", "", "", "TUR", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2023-W-ITF-TUR-27A-2023-114"]
          ];
