
    var fullname = 'Luciana Perry';
    var lastname = 'Perry';
    var currentrank=1129;
    var peakrank=1115;
    var peakfirst=20251110;
    var peaklast=20251110;
    
    
    var hand='U';
    var backhand='';
    var country='USA';
    var shortlist=4;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='';
    var wta_id='';
    var fc_id='800648275';
    var wiki_id='';
    var blast_link='';
    var more_link='';
    var death_date="";
    var dob_approx="";
    var elo_rating='';
    var elo_rank='';
    var ychoices=["Time Span", "Last 52", "Career", "2025", "2024"];
var tchoices=["Event", "All", "W75 Evansville IN", "W75 Sumter SC"];
var cchoices=["vs Country", "All", "CAN", "MEX", "USA"];
var rchoices=["as Rank", "All"];
var ochoices=["Victoria Hu", "Jessica Hinojosa Gomez", "Cadence Brace", "Alexis Blokhina"];
var tdates=["20240715", "20250602"];
var vranks=["305", "356", "756", "1163"];
playernews = [];
var upcoming = "";
var matchmx = [["20250602", "W75 Sumter SC", "Hard", "75", "L", "", "", "", "R16", "6-0 6-2", "3", "Cadence Brace", "305", "", "", "R", "20050225", "", "CAN", "0", "70", "0", "3", "39", "25", "8", "1", "7", "0", "7", "1", "1", "38", "22", "17", "8", "7", "1", "3", "", "20250604-W-ITF_Sumter-R16-Cadence_Brace-Luciana_Perry", "", "", "2025-W-ITF-USA-2025-023-206"],
          ["20250602", "W75 Sumter SC", "Hard", "75", "W", "", "", "", "R32", "1-6 6-3 6-4", "3", "Victoria Hu", "356", "", "", "U", "20020425", "", "USA", "0", "151", "0", "4", "102", "67", "40", "20", "13", "6", "9", "3", "2", "80", "50", "33", "15", "13", "1", "4", "", "", "", "", "2025-W-ITF-USA-2025-023-111"],
          ["20240715", "W75 Evansville IN", "Hard", "75", "L", "", "", "", "Q2", "6-4 5-7 6-1", "3", "Alexis Blokhina", "1163", "13", "", "L", "20040817", "", "USA", "0", "", "", "", "", "", "", "2024-W-ITF-USA-2024-031-813"],
          ["20240715", "W75 Evansville IN", "Hard", "75", "W", "", "", "", "Q1", "6-4 6-1", "3", "Jessica Hinojosa Gomez", "756", "3", "", "U", "19970918", "", "MEX", "0", "", "", "", "", "", "", "2024-W-ITF-USA-2024-031-715"]
          ];
