
    var fullname = 'Kryce Didier Momo Kassa';
    var lastname = 'Momo Kassa';
    var currentrank=1791;
    var peakrank=1385;
    var peakfirst=20141103;
    var peaklast=20141103;
    var dob=19820610;
    
    var hand='U';
    var backhand='';
    var country='GAB';
    var shortlist=9;
    var careerjs=0;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var ychoices=["Time Span", "Last 52", "Career", "2015", "2014", "2013"];
var tchoices=["Event", "All"];
var cchoices=["vs Country", "All", "ARG", "BDI", "EGY", "GAB", "IND", "ISR", "RSA", "TOG"];
var rchoices=["as Rank", "All"];
var ochoices=["Nicolaas Scholtz", "Matias Castro", "Karim Kadry", "Jeevan Nedunchezhiyan", "Hassan Ndayishimiye", "Darvel Valency Lossangoye", "Kokou Missodey", "Bar Tzuf Botzer"];
var tdates=["20130819", "20130826", "20140818", "20140825", "20150824", "20150831"];
var vranks=["295", "562", "573", "699", "941", "1063", "1399", "1870"];
playernews = [];
var upcoming = "";
var matchmx = [["20130819", "Gabon F1", "Hard", "S", "L", "UNR", "", "WC", "R32", "6-0 6-0", "3", "Bar Tzuf Botzer", "699", "6", "", "R", "19940302", "", "ISR", "1", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2013-M-FU-GAB-01A-2013-009", "", "1", "1"],
          ["20130826", "Gabon F2", "Hard", "S", "L", "UNR", "", "WC", "R32", "6-2 6-2", "3", "Kokou Missodey", "UNR", "", "Q", "U", "19901111", "", "TOG", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2013-M-FU-GAB-02A-2013-003", "", "1", "1"],
          ["20140818", "Gabon F1", "Hard", "S", "L", "UNR", "", "Q", "QF", "6-1 6-1", "3", "Jeevan Nedunchezhiyan", "295", "1", "", "L", "19881020", "", "IND", "1", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2014-M-FU-GAB-01A-2014-025", "", "3", "3"],
          ["20140818", "Gabon F1", "Hard", "S", "W", "UNR", "", "Q", "R16", "6-3 6-3", "3", "Karim Kadry", "1399", "", "", "R", "19911001", "", "EGY", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2014-M-FU-GAB-01A-2014-018", "", "2", "2"],
          ["20140818", "Gabon F1", "Hard", "S", "W", "UNR", "", "Q", "R32", "7-5 2-6 6-4", "3", "Matias Castro", "1063", "8", "", "U", "19871021", "", "ARG", "1", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2014-M-FU-GAB-01A-2014-004", "", "1", "1"],
          ["20140825", "Gabon F2", "Hard", "S", "L", "UNR", "", "WC", "R32", "6-1 6-1", "3", "Hassan Ndayishimiye", "941", "5", "", "R", "19940812", "", "BDI", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2014-M-FU-GAB-02A-2014-008", "", "1", "1"],
          ["20150824", "Gabon F1", "Hard", "S", "L", "1399", "", "WC", "R16", "6-2 6-3", "3", "Nicolaas Scholtz", "562", "4", "Q", "R", "19910205", "", "RSA", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2015-M-FU-GAB-01A-2015-022", "", "2", "2"],
          ["20150824", "Gabon F1", "Hard", "S", "W", "1399", "", "WC", "R32", "6-1 6-3", "3", "Darvel Valency Lossangoye", "1870", "", "", "U", "19960921", "", "GAB", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2015-M-FU-GAB-01A-2015-011", "", "1", "1"],
          ["20150831", "Gabon F2", "Hard", "S", "L", "1410", "", "WC", "R32", "6-0 6-2", "3", "Nicolaas Scholtz", "573", "4", "", "R", "19910205", "", "RSA", "0", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "2015-M-FU-GAB-02A-2015-005", "", "1", "1"]
          ];
