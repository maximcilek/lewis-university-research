
    var fullname = 'Bianca Jolie Fernandez';
    var lastname = 'Fernandez';
    var currentrank=1425;
    var peakrank=606;
    var peakfirst=20230911;
    var peaklast=20230911;
    var dob=20040224;
    
    var hand='R';
    var backhand='';
    var country='CAN';
    var shortlist=5;
    var careerjs=1;
    var active=1;
    var lastdate=0;
    var twitter='';
    var current_dubs="UNR";
    var peak_dubs="UNR";
    var peakfirst_dubs="";
    var liverank="";
    var chartagg=0;
    var photog='';
    var photog_credit='';
    var photog_link='';
    var itf_id='100334957';
    var wta_id='';
    var fc_id='';
    var wiki_id='';
    var blast_link='';
    var more_link='';
    var death_date="";
    var dob_approx="";
    var elo_rating='';
    var elo_rank='';
    var ychoices=["Time Span", "Last 52", "Career", "2025", "2024", "2023", "2022", "2021", "2020", "2019"];
var tchoices=["Event", "All", "Charleston", "Granby", "Monterrey", "Montreal", "Tampico", "Vancouver 125", "W100 Granby", "W15 Cancun", "W15 Don Benito (Badajoz)", "W15 Fort-de-France (Martinique)", "W15 Guayaquil", "W15 Huamantla", "W15 Lima", "W15 Monastir", "W15 Montemor O Novo", "W15 Naples FL", "W15 Prokuplje", "W15 San Diego", "W15 Santa Margarita de Montbui", "W15 Santo Domingo", "W15 Sharm El Sheikh", "W25 Anapoima", "W25 Cancun", "W25 Corroios-Seixal", "W25 Daytona Beach FL", "W25 Florence SC", "W25 Frydek Mistek", "W25 Guayaquil", "W25 Guimaraes", "W25 Jablonec nad Nisou", "W25 Marbella", "W25 Medellin", "W25 Orlando FL", "W25 Ourense", "W25 Petit-Bourg (Guadeloupe)", "W25 Platja D'Aro", "W25 Redding CA", "W25 Roehampton", "W25 Santa Margherita di Pula", "W25 Santo Domingo", "W25 Valladolid", "W25 Vero Beach FL", "W25 Vienna", "W25 Vigo", "W25 Waco TX", "W25+H Figueira Da Foz", "W35 Leiria", "W35 Santarem", "W40 Montemor-O-Novo", "W40 Palma del Rio", "W50 Saskatoon", "W60 Asuncion", "W60 Charlottesville VA", "W60 Macon GA", "W60 Rancho Santa Fe CA", "W60 Saskatoon", "W75+H Granby", "W80 Macon GA", "W80 Rancho Santa Fe CA"];
var cchoices=["vs Country", "All", "AND", "ARG", "AUS", "AUT", "BEL", "BIH", "BLR", "BRA", "BUL", "CAN", "CHN", "COL", "CRO", "CUB", "CZE", "DEN", "ECU", "EGY", "ESP", "FRA", "GBR", "GER", "GRE", "GRN", "HUN", "IND", "ITA", "JPN", "MEX", "PAR", "POL", "POR", "RUS", "SRB", "SUI", "SVK", "SWE", "THA", "TUR", "UKR", "USA", "ZIM"];
var rchoices=["as Rank", "All"];
var ochoices=["Stacey Fung", "Mia Kupres", "Jenna Defalco", "Dea Herdzelas", "Anna Ulyashchenko", "Sophie Suh", "Sara Borkop", "Maria Fernanda Navarro", "Christasha Mcneil", "Antonia Ruzic", "Anna Kubareva", "Analu Freitas", "Victoria Jimenez Kasintseva", "Taylor Marie Gales", "Stefania Rubini", "Savanna Ly Nguyen", "Sarah Iliev", "Sachely Carrera", "Nahia Berecoechea", "Nadia Echeverria Alam", "Meisha Kendall Woseley", "Matilde Mariani", "Matilde Jorge", "Marina Stakusic", "Maria Andrienko", "Lucia Llinares Domingo", "Lia Karatancheva", "Lesia Tsurenko", "Kolie Allen", "Kayla Day", "Karman Thandi", "Kajsa Rinaldo Persson", "Julita Saner", "Julie Belgraver", "Johanne Christine Svendsen", "Jaeda Daniel", "Georgina Garcia Perez", "Fangran Tian", "Esther Vyrlan", "Ellen Perez", "Elia Rozanes", "Eleni Kordolaimi", "Elena Giessler", "Cristina Rodriguez Duenas", "Carmen Lopez Martinez", "Beatrice Ricci", "Basant Kaur", "Anna Makhorkina", "Alice Gubertini", "Zoe Hitt", "Zeynep Sonmez", "Ye Xin Ma", "Victoria Hu", "Veronika Bokor", "Vanda Lukacs", "Theadora Rabman", "Tessah Andrianjafitrimo", "Teliana Pereira", "Tatum Evans", "Tara Malik", "Tamara Curovic", "Sofia Nami Samavati", "Sofia Milatova", "Shuqian Xu", "Shatoo Mohamad", "Sara Gvozdenovic", "Rutuja Bhosale", "Rhiann Newborn", "Rebecca Lynn", "Rasheeda Mcadoo", "Polina Iatcenko", "Paris Corley", "Ozlem Uslu", "Norhan Hesham", "Nevena Kolarevic", "Natasha Sengphrachanh", "Milla Sequeira", "Mia Yamakita", "Mercedes Aristegui", "Melody Hefti", "Matilde Agra", "Martha Matoula", "Marina Benito", "Maria Kononova", "Margaux Komano", "Maraia Paula Manrique", "Malkia Menguene", "Magda Linette", "Lucie Petruzelova", "Lisa Zaar", "Lara Escauriza", "Kurumi Nara", "Klara Hajkova", "Kimberly Mpukusa", "Kelly Loana Vargas Gonzalez", "Katharine Fahey", "Karolina Berankova", "Karin Handiakova", "Jule Niemeier", "Jovana Peric", "Jessie Aney", "Janet Imbo Nloga", "Jana Bojovic", "Jacqueline Cabaj Awad", "Ivonne Cavalle Reimers", "Isabelle Bahr", "Ingrid Gamarra Martins", "Hind Abdelouahid", "Helene Scholsen", "Hanna Chang", "Greta Schieroni", "Francisca Jorge", "Fernanda Contreras Gomez", "Erin Routliffe", "Elisa Andrea Camerano", "Elena Micic", "Chloe Compson", "Chieh Yu Hsu", "Chiara Semmelmeyer", "Chelsea Fontenel", "Celia Cervino Ruiz", "Catherine Harrison", "Carlota Martinez Cirez", "Camila Romero", "Berta Bonardi", "Astrid Cirotte", "Anoushka Wooller", "Anna Brogan", "Anita Bertoloni", "Anastasia Sysoeva", "Ana M Becerra", "Amy Zhu", "Amelie Smejkalova", "Amelia Rajecki", "Amarissa Kiara Toth", "Allura Zamarripa", "Alicia Barnett", "Alexa Pitt", "Akilah James", "Akasha Urhobo"];
var tdates=["20190415", "20190527", "20190708", "20190715", "20190909", "20190916", "20190923", "20191014", "20191028", "20201012", "20201019", "20201026", "20201102", "20210524", "20210531", "20210607", "20210628", "20210705", "20210719", "20210816", "20210830", "20211004", "20211025", "20220110", "20220117", "20220124", "20220207", "20220228", "20220307", "20220314", "20220321", "20220404", "20220418", "20220502", "20220704", "20220711", "20220718", "20220815", "20220822", "20220829", "20220905", "20220912", "20221003", "20221010", "20221017", "20221024", "20221121", "20221128", "20230109", "20230116", "20230123", "20230213", "20230220", "20230403", "20230410", "20230417", "20230424", "20230501", "20230508", "20230529", "20230626", "20230710", "20230717", "20230807", "20230821", "20230828", "20231009", "20231016", "20240715", "20240902", "20240909", "20250707", "20250714", "20250811", "20250818"];
var vranks=["46", "55", "89", "110", "125", "175", "177", "214", "233", "236", "271", "312", "324", "388", "400", "410", "417", "451", "452", "475", "480", "506", "523", "524", "527", "540", "559", "574", "590", "591", "609", "618", "633", "659", "662", "671", "675", "695", "697", "707", "708", "713", "719", "725", "740", "748", "750", "774", "775", "778", "781", "802", "827", "850", "868", "874", "915", "930", "964", "1003", "1007", "1029", "1048", "1080", "1118", "1125", "1166", "1169", "1175", "1176", "1198", "1204", "1210", "1224", "1250", "1254", "1269", "1270", "1329", "1387", "1427", "1553"];
playernews = [];
var upcoming = "";
var matchmx = [["20250707", "W15 San Diego", "Hard", "15", "L", "", "", "", "R16", "6-3 6-1", "3", "Christasha Mcneil", "802", "", "", "R", "20061003", "", "USA", "0", "77", "0", "11", "56", "30", "14", "9", "8", "1", "7", "2", "1", "45", "26", "15", "13", "8", "1", "3", "", "", "", "", "2025-W-ITF-USA-2025-038-206"],
          ["20250707", "W15 San Diego", "Hard", "15", "W", "", "", "", "R32", "6-4 6-2", "3", "Sophie Suh", "1427", "", "", "U", "", "", "USA", "0", "109", "0", "4", "60", "35", "23", "14", "9", "1", "3", "2", "2", "61", "31", "18", "12", "9", "3", "8", "", "", "", "", "2025-W-ITF-USA-2025-038-111"],
          ["20250714", "W15 Huamantla", "Hard", "15", "W", "", "", "", "R32", "6-1 4-6 6-3", "3", "Maria Fernanda Navarro", "", "", "", "U", "19960622", "", "MEX", "0", "142", "0", "18", "92", "45", "30", "22", "13", "4", "8", "2", "4", "82", "53", "30", "13", "13", "2", "9", "", "", "", "", "2025-W-ITF-MEX-2025-004-104"],
          ["20250811", "W50 Saskatoon", "Hard", "50", "L", "", "", "", "R32", "6-4 6-4", "3", "Mia Kupres", "850", "", "", "R", "20040112", "", "CAN", "0", "95", "1", "5", "55", "37", "23", "7", "10", "3", "7", "2", "4", "63", "36", "26", "14", "10", "3", "5", "", "", "", "", "2025-W-ITF-CAN-2025-003-107"],
          ["20250818", "Monterrey", "Hard", "P", "L", "1451", "", "WC", "Q1", "6-3 6-1", "3", "Antonia Ruzic", "89", "1", "", "R", "20030120", "", "CRO", "0", "69", "2", "6", "55", "30", "16", "7", "8", "5", "11", "3", "3", "39", "24", "19", "8", "8", "2", "4", "", "", "", "", "2025-1039-265"]
          ];
